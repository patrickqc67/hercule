// Intégration de CodePhantom dans le système existant
// Remplace le streaming basique par les capacités avancées

import { CodePhantom, PhantomMessage } from './code-phantom';
import { storage } from './storage';

export class PhantomIntegration {
  private phantom: CodePhantom;
  private onStreamMessage: (message: any) => void;

  constructor(onStreamMessage: (message: any) => void) {
    this.onStreamMessage = onStreamMessage;
    this.phantom = new CodePhantom((message: PhantomMessage) => {
      this.handlePhantomMessage(message);
    });
  }

  private handlePhantomMessage(message: PhantomMessage): void {
    // Conversion des messages CodePhantom vers le format existant
    const streamMessage = {
      type: message.type,
      content: message.content,
      filename: message.filename,
      language: message.language,
      step: message.step,
      metadata: {
        confidence: message.confidence,
        suggestions: message.suggestions,
        canCancel: message.canCancel
      }
    };

    this.onStreamMessage(streamMessage);
  }

  // Génération avancée avec CodePhantom
  async generateAdvanced(
    prompt: string,
    language: string,
    projectId: number,
    options: {
      existingCode?: string;
      context?: string;
      files?: any[];
    } = {}
  ): Promise<string> {
    // Récupération du contexte projet complet si pas fourni
    const projectFiles = options.files || await storage.getFilesByProjectId(projectId);
    
    // Utilisation de CodePhantom pour génération avancée
    const result = await this.phantom.generateWithAdvancedStreaming(
      prompt,
      language,
      options.existingCode || "",
      projectFiles
    );

    return result;
  }

  // Debug intelligent avec logs
  async debugWithLogs(
    errorLogs: string[],
    projectId: number,
    environment: string = 'development'
  ): Promise<string> {
    const projectFiles = await storage.getFilesByProjectId(projectId);
    
    return await this.phantom.debugFromLogs(
      errorLogs,
      projectFiles,
      environment
    );
  }

  // Configuration du style de code
  setCodeStyle(style: any): void {
    this.phantom.setCodeStyle(style);
  }

  // Configuration des modèles IA
  setAIModels(primary: 'gpt4' | 'claude' | 'mistral', fallback: string[] = []): void {
    this.phantom.setAIModels(primary, fallback);
  }

  // Annulation de génération
  cancelGeneration(): void {
    this.phantom.cancelGeneration();
  }
}