import express from 'express';
import { Server } from 'http';
import path from 'path';
import fs from 'fs/promises';
import { codeExecutor } from './code-executor';

interface PreviewServer {
  port: number;
  server: Server;
  projectId: number;
  language: string;
}

class PreviewServerManager {
  private servers: Map<number, PreviewServer> = new Map();
  private usedPorts: Set<number> = new Set();
  private basePort = 3001;

  private getAvailablePort(): number {
    while (this.usedPorts.has(this.basePort)) {
      this.basePort++;
    }
    this.usedPorts.add(this.basePort);
    return this.basePort++;
  }

  private async createProjectDirectory(projectId: number): Promise<string> {
    const projectDir = path.join(process.cwd(), 'preview-projects', projectId.toString());
    await fs.mkdir(projectDir, { recursive: true });
    return projectDir;
  }

  async startPreviewServer(projectId: number, files: any[], language: string): Promise<string> {
    // Arrêter le serveur existant s'il y en a un
    await this.stopPreviewServer(projectId);

    const port = this.getAvailablePort();
    const projectDir = await this.createProjectDirectory(projectId);

    // Écrire tous les fichiers dans le répertoire du projet
    for (const file of files) {
      const filePath = path.join(projectDir, file.name);
      
      // Nettoyer le contenu du fichier (supprimer les balises markdown si présentes)
      let cleanContent = file.content;
      
      if (cleanContent.includes('```')) {
        cleanContent = cleanContent.replace(/```[a-z]*\s*\n?/g, '').replace(/\n?```$/g, '');
      }
      
      await fs.writeFile(filePath, cleanContent.trim(), 'utf8');
    }

    // Créer le serveur Express pour ce projet
    const app = express();
    app.use(express.json());
    app.use(express.static(projectDir));

    // Route pour exécuter du code avec Judge0
    app.post('/api/execute', async (req, res) => {
      try {
        const { code, language: execLang, input } = req.body;
        
        if (codeExecutor.isLanguageSupported(execLang)) {
          const result = await codeExecutor.executeCode(code, execLang, input);
          res.json(result);
        } else {
          res.status(400).json({ 
            error: 'Langage non supporté',
            supportedLanguages: codeExecutor.getSupportedLanguages()
          });
        }
      } catch (error) {
        res.status(500).json({ 
          error: error instanceof Error ? error.message : 'Erreur d\'exécution'
        });
      }
    });

    // Route pour exécuter un fichier spécifique du projet
    app.post('/api/execute-file', async (req, res) => {
      try {
        const { filename, language: execLang, input } = req.body;
        
        const file = files.find(f => f.name === filename);
        if (!file) {
          return res.status(404).json({ error: 'Fichier non trouvé' });
        }

        if (codeExecutor.isLanguageSupported(execLang)) {
          const result = await codeExecutor.executeCode(file.content, execLang, input);
          res.json(result);
        } else {
          res.status(400).json({ 
            error: 'Langage non supporté',
            supportedLanguages: codeExecutor.getSupportedLanguages()
          });
        }
      } catch (error) {
        res.status(500).json({ 
          error: error instanceof Error ? error.message : 'Erreur d\'exécution'
        });
      }
    });

    // Route pour obtenir la liste des fichiers
    app.get('/api/files', (req, res) => {
      res.json(files.map(f => ({ name: f.name, language: this.detectLanguage(f.name) })));
    });

    // Route principale - Interface d'exécution unifiée
    app.get('*', async (req, res) => {
      const isWebProject = language === 'html' || language === 'javascript' || language === 'css';
      
      if (isWebProject) {
        // Pour les projets web, servir directement les fichiers
        try {
          const indexPath = path.join(projectDir, 'index.html');
          const indexExists = await fs.access(indexPath).then(() => true).catch(() => false);
          
          if (indexExists) {
            res.sendFile(indexPath);
          } else {
            const htmlFiles = files.filter(f => f.name.endsWith('.html'));
            if (htmlFiles.length > 0) {
              res.sendFile(path.join(projectDir, htmlFiles[0].name));
            } else {
              res.send(this.generateExecutionInterface(files, language));
            }
          }
        } catch (error) {
          res.send(this.generateExecutionInterface(files, language));
        }
      } else {
        // Pour les autres langages, interface d'exécution
        res.send(this.generateExecutionInterface(files, language));
      }
    });

    const server = app.listen(port);

    // Stocker les informations du serveur
    this.servers.set(projectId, {
      port,
      server,
      projectId,
      language
    });

    this.usedPorts.add(port);

    return `http://localhost:${port}`;
  }

  private detectLanguage(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const langMap: { [key: string]: string } = {
      '.py': 'python',
      '.js': 'javascript',
      '.java': 'java',
      '.cpp': 'cpp',
      '.c': 'c',
      '.php': 'php',
      '.rb': 'ruby',
      '.go': 'go',
      '.rs': 'rust',
      '.swift': 'swift',
      '.kt': 'kotlin',
      '.cs': 'csharp',
      '.ts': 'typescript'
    };
    return langMap[ext] || 'text';
  }

  private generateExecutionInterface(files: any[], language: string): string {
    const fileOptions = files.map(f => 
      `<option value="${f.name}">${f.name}</option>`
    ).join('');

    return `
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Exécution de Code - ${language}</title>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                margin: 0;
                padding: 20px;
                background: #1a1a1a;
                color: #e0e0e0;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
            }
            .header {
                background: #2d2d2d;
                padding: 20px;
                border-radius: 8px;
                margin-bottom: 20px;
            }
            .controls {
                display: flex;
                gap: 10px;
                margin-bottom: 20px;
            }
            select, button {
                padding: 10px;
                border: none;
                border-radius: 4px;
                background: #404040;
                color: #e0e0e0;
                cursor: pointer;
            }
            button {
                background: #007acc;
            }
            button:hover {
                background: #005a9e;
            }
            .code-section {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
                margin-bottom: 20px;
            }
            .code-area, .output-area {
                background: #2d2d2d;
                border-radius: 8px;
                padding: 15px;
            }
            textarea {
                width: 100%;
                height: 300px;
                background: #1e1e1e;
                color: #e0e0e0;
                border: 1px solid #404040;
                border-radius: 4px;
                padding: 10px;
                font-family: 'Courier New', monospace;
                resize: vertical;
            }
            .output {
                background: #1e1e1e;
                border: 1px solid #404040;
                border-radius: 4px;
                padding: 10px;
                height: 300px;
                overflow-y: auto;
                font-family: 'Courier New', monospace;
                white-space: pre-wrap;
            }
            .success { color: #4caf50; }
            .error { color: #f44336; }
            .loading {
                color: #ff9800;
                animation: pulse 1s infinite;
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 Exécuteur de Code - ${language.toUpperCase()}</h1>
                <p>Sélectionnez un fichier et cliquez sur "Exécuter" pour voir le résultat</p>
            </div>
            
            <div class="controls">
                <select id="fileSelect">
                    ${fileOptions}
                </select>
                <button onclick="executeCode()">▶ Exécuter</button>
                <button onclick="loadFileContent()">📂 Charger fichier</button>
            </div>
            
            <div class="code-section">
                <div class="code-area">
                    <h3>Code</h3>
                    <textarea id="codeInput" placeholder="Le code du fichier sélectionné apparaîtra ici..."></textarea>
                    <h3>Entrée (optionnel)</h3>
                    <textarea id="inputData" rows="3" placeholder="Données d'entrée pour le programme..."></textarea>
                </div>
                
                <div class="output-area">
                    <h3>Sortie</h3>
                    <div id="output" class="output">Cliquez sur "Exécuter" pour voir le résultat...</div>
                </div>
            </div>
        </div>

        <script>
            async function loadFileContent() {
                const select = document.getElementById('fileSelect');
                const filename = select.value;
                const codeInput = document.getElementById('codeInput');
                
                try {
                    const response = await fetch('/' + filename);
                    const content = await response.text();
                    codeInput.value = content;
                } catch (error) {
                    document.getElementById('output').innerHTML = 
                        '<span class="error">Erreur lors du chargement du fichier: ' + error.message + '</span>';
                }
            }

            async function executeCode() {
                const codeInput = document.getElementById('codeInput');
                const inputData = document.getElementById('inputData');
                const output = document.getElementById('output');
                const fileSelect = document.getElementById('fileSelect');
                
                const code = codeInput.value.trim();
                if (!code) {
                    output.innerHTML = '<span class="error">Veuillez charger ou saisir du code à exécuter</span>';
                    return;
                }
                
                output.innerHTML = '<span class="loading">Exécution en cours...</span>';
                
                try {
                    const response = await fetch('/api/execute', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            code: code,
                            language: '${language}',
                            input: inputData.value
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.error) {
                        output.innerHTML = '<span class="error">Erreur: ' + result.error + '</span>';
                    } else {
                        let outputText = '';
                        
                        if (result.stdout) {
                            outputText += '<span class="success">Sortie:\\n' + result.stdout + '</span>\\n';
                        }
                        
                        if (result.stderr) {
                            outputText += '<span class="error">Erreurs:\\n' + result.stderr + '</span>\\n';
                        }
                        
                        if (result.compile_output) {
                            outputText += '<span class="error">Compilation:\\n' + result.compile_output + '</span>\\n';
                        }
                        
                        if (result.status) {
                            outputText += '\\nStatut: ' + result.status.description;
                        }
                        
                        if (result.time) {
                            outputText += '\\nTemps: ' + result.time + 's';
                        }
                        
                        if (result.memory) {
                            outputText += '\\nMémoire: ' + result.memory + ' KB';
                        }
                        
                        output.innerHTML = outputText || '<span class="success">Exécution terminée sans sortie</span>';
                    }
                } catch (error) {
                    output.innerHTML = '<span class="error">Erreur de communication: ' + error.message + '</span>';
                }
            }

            // Charger automatiquement le premier fichier
            window.onload = function() {
                loadFileContent();
            };
        </script>
    </body>
    </html>
    `;
  }

  async updatePreviewFiles(projectId: number, files: any[]): Promise<void> {
    const serverInfo = this.servers.get(projectId);
    if (!serverInfo) return;

    const projectDir = path.join(process.cwd(), 'preview-projects', projectId.toString());
    
    // Supprimer les anciens fichiers et réécrire les nouveaux
    try {
      await fs.rm(projectDir, { recursive: true, force: true });
      await fs.mkdir(projectDir, { recursive: true });
      
      for (const file of files) {
        const filePath = path.join(projectDir, file.name);
        let cleanContent = file.content;
        
        if (cleanContent.includes('```')) {
          cleanContent = cleanContent.replace(/```[a-z]*\s*\n?/g, '').replace(/\n?```$/g, '');
        }
        
        await fs.writeFile(filePath, cleanContent.trim(), 'utf8');
      }
    } catch (error) {
      console.error('Erreur lors de la mise à jour des fichiers:', error);
    }
  }

  async stopPreviewServer(projectId: number): Promise<void> {
    const serverInfo = this.servers.get(projectId);
    
    if (serverInfo) {
      serverInfo.server.close();
      this.usedPorts.delete(serverInfo.port);
      this.servers.delete(projectId);
    }
  }

  getPreviewUrl(projectId: number): string | null {
    const serverInfo = this.servers.get(projectId);
    return serverInfo ? `http://localhost:${serverInfo.port}` : null;
  }

  async stopAllServers(): Promise<void> {
    const promises = Array.from(this.servers.keys()).map(id => this.stopPreviewServer(id));
    await Promise.all(promises);
  }
}

export const previewServerManager = new PreviewServerManager();

// Nettoyer les serveurs à l'arrêt du processus
process.on('SIGTERM', () => previewServerManager.stopAllServers());
process.on('SIGINT', () => previewServerManager.stopAllServers());