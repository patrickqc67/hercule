import OpenAI from "openai";

// Configuration conditionnelle pour xAI Grok
let xai: OpenAI | null = null;

function initializeXAI(): OpenAI | null {
  if (!xai && process.env.XAI_API_KEY) {
    xai = new OpenAI({ 
      baseURL: "https://api.x.ai/v1", 
      apiKey: process.env.XAI_API_KEY,
      timeout: 20000, // 20 secondes
      maxRetries: 2,
      defaultHeaders: {
        'User-Agent': 'CodePhantom/1.0',
        'Accept': 'application/json'
      }
    });
  }
  return xai;
}

interface CodeGenerationResult {
  code: string;
  language: string;
}

/**
 * Génère du code en utilisant xAI Grok
 * @param prompt Le prompt de l'utilisateur
 * @param language Le langage de programmation cible
 * @param existingCode Code existant (optionnel)
 * @param context Contexte additionnel (optionnel)
 * @returns Le code généré
 */
export async function generateCodeWithXAI(
  prompt: string,
  language: string,
  existingCode: string = "",
  context: string = ""
): Promise<CodeGenerationResult> {
  try {
    const client = initializeXAI();
    if (!client) {
      throw new Error("XAI API key not configured");
    }
    const systemPrompt = `You are Grok, xAI's AI assistant. Generate clean, functional ${language} code that follows modern best practices and conventions.

Focus on creating practical, well-structured solutions that meet the user's requirements.`;

    // Construire le prompt utilisateur
    let userPrompt = prompt;
    if (existingCode) {
      userPrompt += `\n\nCode existant à améliorer ou modifier :\n${existingCode}`;
    }

    console.log("Génération de code avec xAI Grok pour le langage:", language);

    const response = await client.chat.completions.create({
      model: "grok-2-1212", // Utilise un modèle plus stable
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
      ],
      max_tokens: 4000,
      temperature: 0.7,
    });

    console.log("Réponse reçue de l'API xAI Grok");

    const generatedCode = response.choices[0]?.message?.content || "";
    
    if (!generatedCode) {
      throw new Error("Aucun code généré par xAI Grok");
    }

    return {
      code: generatedCode.trim(),
      language: language
    };
  } catch (error) {
    console.error("Erreur lors de la génération avec xAI Grok:", error);
    throw new Error(`Erreur xAI Grok: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
  }
}

/**
 * Analyse du code avec xAI Grok
 * @param code Le code à analyser
 * @param language Le langage de programmation
 * @param projectContext Contexte du projet
 * @returns L'analyse du code
 */
export async function analyzeCodeWithXAI(
  code: string,
  language: string,
  projectContext: string = ""
) {
  try {
    const systemPrompt = `Tu es un expert en analyse de code qui fournit des évaluations techniques détaillées.
Analyse le code fourni et identifie :
- Les problèmes potentiels et erreurs
- Les améliorations possibles
- Les bonnes pratiques respectées ou manquées
- La sécurité et les performances
- La lisibilité et la maintenabilité

Retourne ton analyse sous format JSON avec cette structure :
{
  "issues": [
    {
      "line": numero_ligne,
      "issue": "description_du_probleme",
      "severity": "error|warning|info",
      "suggestion": "suggestion_d_amelioration"
    }
  ],
  "summary": "resume_general_de_l_analyse",
  "improvement_suggestions": ["suggestion1", "suggestion2", ...]
}`;

    const response = await client.chat.completions.create({
      model: "grok-3-latest",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Analyse ce code ${language} :\n\n${code}\n\n${projectContext ? `Contexte du projet : ${projectContext}` : ''}` }
      ],
      max_tokens: 2000,
      temperature: 0.3,
      response_format: { type: "json_object" }
    });

    const analysis = JSON.parse(response.choices[0]?.message?.content || "{}");
    return analysis;
  } catch (error) {
    console.error("Erreur lors de l'analyse avec xAI Grok:", error);
    throw new Error(`Erreur d'analyse xAI Grok: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
  }
}

/**
 * Correction de code avec xAI Grok
 * @param code Le code contenant des erreurs
 * @param language Le langage de programmation
 * @param error La description de l'erreur
 * @returns Le code corrigé
 */
export async function fixCodeWithXAI(
  code: string,
  language: string,
  error: string
): Promise<CodeGenerationResult> {
  try {
    const systemPrompt = `Tu es un expert en débogage et correction de code.
Corrige le code fourni en résolvant l'erreur spécifiée tout en maintenant la fonctionnalité originale.
Retourne UNIQUEMENT le code corrigé sans explications.`;

    const response = await client.chat.completions.create({
      model: "grok-3-latest",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Corrige ce code ${language} qui a l'erreur suivante : ${error}\n\nCode :\n${code}` }
      ],
      max_tokens: 3000,
      temperature: 0.3,
    });

    const fixedCode = response.choices[0]?.message?.content || "";
    
    return {
      code: fixedCode.trim(),
      language: language
    };
  } catch (error) {
    console.error("Erreur lors de la correction avec xAI Grok:", error);
    throw new Error(`Erreur de correction xAI Grok: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
  }
}