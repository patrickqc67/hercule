import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as schema from '../shared/schema.js';
import path from 'path';
import fs from 'fs';

// Configuration pour SQLite en mode portable
const dbPath = process.env.DATABASE_URL?.replace('sqlite:', '') || './data/codephantom.db';

// Créer le répertoire si nécessaire
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Créer la connexion SQLite
const sqlite = new Database(dbPath);

// Optimisations SQLite
sqlite.pragma('journal_mode = WAL');
sqlite.pragma('foreign_keys = ON');
sqlite.pragma('synchronous = NORMAL');
sqlite.pragma('cache_size = 1000000');
sqlite.pragma('temp_store = memory');

// Créer l'instance Drizzle
export const db = drizzle(sqlite, { schema });
