import axios from 'axios';

interface ExecutionResult {
  stdout?: string;
  stderr?: string;
  compile_output?: string;
  status: {
    id: number;
    description: string;
  };
  time?: string;
  memory?: number;
}

// Mapping des langages vers les IDs Judge0
const LANGUAGE_IDS = {
  'javascript': 63, // Node.js
  'python': 71,     // Python 3
  'java': 62,       // Java
  'cpp': 54,        // C++
  'c': 50,          // C
  'php': 68,        // PHP
  'ruby': 72,       // Ruby
  'go': 60,         // Go
  'rust': 73,       // Rust
  'swift': 83,      // Swift
  'kotlin': 78,     // Kotlin
  'csharp': 51,     // C#
  'typescript': 74  // TypeScript
};

export class CodeExecutor {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.JUDGE0_API_KEY || '3c613bb578msh3cbf26b406e8f22p1f55a8jsn5e1ae99cf4b2';
    this.baseUrl = 'https://judge0-ce.p.rapidapi.com';
  }

  private getLanguageId(language: string): number {
    const normalizedLang = language.toLowerCase();
    return LANGUAGE_IDS[normalizedLang as keyof typeof LANGUAGE_IDS] || 71; // Default to Python
  }

  async executeCode(code: string, language: string, input?: string): Promise<ExecutionResult> {
    if (!this.apiKey) {
      throw new Error('Judge0 API key not configured');
    }

    try {
      // Étape 1: Soumettre le code pour exécution
      const submissionResponse = await axios.post(
        `${this.baseUrl}/submissions?base64_encoded=true&wait=false`,
        {
          source_code: Buffer.from(code).toString('base64'),
          language_id: this.getLanguageId(language),
          stdin: input ? Buffer.from(input).toString('base64') : undefined
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'X-RapidAPI-Key': this.apiKey,
            'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com'
          }
        }
      );

      const token = submissionResponse.data.token;

      // Étape 2: Attendre et récupérer le résultat
      let result: ExecutionResult;
      let attempts = 0;
      const maxAttempts = 10;

      do {
        await new Promise(resolve => setTimeout(resolve, 1000)); // Attendre 1 seconde
        
        const resultResponse = await axios.get(
          `${this.baseUrl}/submissions/${token}`,
          {
            headers: {
              'X-RapidAPI-Key': this.apiKey,
              'X-RapidAPI-Host': 'judge0-ce.p.rapidapi.com'
            }
          }
        );

        result = resultResponse.data;
        attempts++;
      } while (result.status.id <= 2 && attempts < maxAttempts); // Status 1-2 = En cours

      // Décoder les résultats base64 seulement s'ils existent et ne sont pas null
      if (result.stdout && result.stdout !== null) {
        try {
          result.stdout = Buffer.from(result.stdout, 'base64').toString('utf8');
        } catch (e) {
          console.log('Erreur décodage stdout:', e);
        }
      }
      if (result.stderr && result.stderr !== null) {
        try {
          result.stderr = Buffer.from(result.stderr, 'base64').toString('utf8');
        } catch (e) {
          console.log('Erreur décodage stderr:', e);
          result.stderr = undefined; // Éviter l'affichage de caractères corrompus
        }
      }
      if (result.compile_output && result.compile_output !== null) {
        try {
          result.compile_output = Buffer.from(result.compile_output, 'base64').toString('utf8');
        } catch (e) {
          console.log('Erreur décodage compile_output:', e);
        }
      }

      return result;
    } catch (error) {
      console.error('Erreur Judge0:', error);
      throw new Error('Erreur lors de l\'exécution du code');
    }
  }

  async executeProject(files: any[], mainFile: string, language: string): Promise<ExecutionResult> {
    // Pour les projets multi-fichiers, on exécute le fichier principal
    const mainFileContent = files.find(f => f.name === mainFile)?.content;
    
    if (!mainFileContent) {
      throw new Error(`Fichier principal ${mainFile} non trouvé`);
    }

    return this.executeCode(mainFileContent, language);
  }

  getSupportedLanguages(): string[] {
    return Object.keys(LANGUAGE_IDS);
  }

  isLanguageSupported(language: string): boolean {
    return language.toLowerCase() in LANGUAGE_IDS;
  }
}

export const codeExecutor = new CodeExecutor();