import {
  users, projects, files, versions, codeExecutions,
  type User, type InsertUser,
  type Project, type InsertProject,
  type File, type InsertFile,
  type Version, type InsertVersion,
  type CodeExecution, type InsertCodeExecution
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export class DatabaseStorage {
  private now() {
    return new Date().toISOString(); // Conversion explicite
  }

  // ==== Utilisateurs ====
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      createdAt: this.now(),
      updatedAt: this.now()
    }).returning();
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(users).set({
      ...data,
      updatedAt: this.now()
    }).where(eq(users.id, id)).returning();
    return user;
  }

  async deleteUser(id: number): Promise<boolean> {
    await db.delete(users).where(eq(users.id, id));
    return true;
  }

  // ==== Projets ====
  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values({
      ...insertProject,
      createdAt: this.now(),
      updatedAt: this.now(),
      lastOpenedAt: this.now()
    }).returning();
    return project;
  }

  async updateProject(id: number, data: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db.update(projects).set({
      ...data,
      updatedAt: this.now()
    }).where(eq(projects.id, id)).returning();
    return project;
  }

  async deleteProject(id: number): Promise<boolean> {
    await db.delete(projects).where(eq(projects.id, id));
    return true;
  }

  // ==== Fichiers ====
  async getFilesByProjectId(projectId: number): Promise<File[]> {
    return await db.select().from(files).where(eq(files.projectId, projectId));
  }

  async getFile(id: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const [file] = await db.insert(files).values({
      ...insertFile,
      isMain: insertFile.isMain || false,
      createdAt: this.now(),
      updatedAt: this.now()
    }).returning();
    return file;
  }

  async updateFile(id: number, data: Partial<InsertFile>): Promise<File | undefined> {
    const [file] = await db.update(files).set({
      ...data,
      updatedAt: this.now()
    }).where(eq(files.id, id)).returning();
    return file;
  }

  async deleteFile(id: number): Promise<boolean> {
    try {
      await db.delete(versions).where(eq(versions.fileId, id));
      await db.delete(codeExecutions).where(eq(codeExecutions.fileId, id));
      await db.delete(files).where(eq(files.id, id));
      return true;
    } catch (error) {
      console.error("Erreur suppression fichier:", error);
      return false;
    }
  }

  // ==== Versions ====
  async getVersionsByFileId(fileId: number): Promise<Version[]> {
    return await db.select().from(versions).where(eq(versions.fileId, fileId));
  }

  async getVersion(id: number): Promise<Version | undefined> {
    const [version] = await db.select().from(versions).where(eq(versions.id, id));
    return version;
  }

  async createVersion(insertVersion: InsertVersion): Promise<Version> {
    const [version] = await db.insert(versions).values({
      ...insertVersion,
      timestamp: this.now()
    }).returning();
    return version;
  }

  // ==== Exécutions ====
  async createCodeExecution(insertExecution: InsertCodeExecution): Promise<CodeExecution> {
    const [exec] = await db.insert(codeExecutions).values({
      ...insertExecution,
      timestamp: this.now()
    }).returning();
    return exec;
  }

  async getCodeExecutionsByFileId(fileId: number): Promise<CodeExecution[]> {
    return await db.select().from(codeExecutions).where(eq(codeExecutions.fileId, fileId));
  }
}

// Export de l'instance
export const storage = new DatabaseStorage();
