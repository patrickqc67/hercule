// CodePhantom - Agent IA avancé pour développement
// Plus performant que Replit Ghostwriter avec analyse multi-fichier et auto-fix

import OpenAI from "openai";
import { generateCodeWithOpenAI } from './openai';
import { generateCodeWithAnthropic } from './anthropic';
import * as fs from 'fs';
import * as path from 'path';

// Types pour CodePhantom
export interface PhantomMessage {
  type: 'thinking' | 'working' | 'analyzing' | 'code' | 'complete' | 'file' | 'debug' | 'refactor';
  content: string;
  step?: number;
  filename?: string;
  filePath?: string;
  language?: string;
  confidence?: number;
  suggestions?: string[];
  canCancel?: boolean;
  metadata?: any;
}

interface ProjectContext {
  files: Map<string, string>;
  dependencies: string[];
  errors: string[];
  gitHistory: string[];
  codeStyle: CodeStyle;
}

interface CodeStyle {
  indentation: 'spaces' | 'tabs';
  spacesCount: number;
  semicolons: boolean;
  quotes: 'single' | 'double';
  trailingComma: boolean;
  language: string;
}

interface DebugContext {
  errorLogs: string[];
  stackTrace: string[];
  environment: string;
  lastModifiedFiles: string[];
}

export class CodePhantom {
  private onMessage: (message: PhantomMessage) => void;
  private projectContext: ProjectContext;
  private aiModels: {
    primary: 'gpt4' | 'claude' | 'mistral';
    fallback: string[];
  };
  private cancelToken: { cancelled: boolean } = { cancelled: false };
  private vectorStore: Map<string, number[]> = new Map(); // Simulation vector DB
  
  constructor(onMessage: (message: PhantomMessage) => void) {
    this.onMessage = onMessage;
    this.projectContext = {
      files: new Map(),
      dependencies: [],
      errors: [],
      gitHistory: [],
      codeStyle: {
        indentation: 'spaces',
        spacesCount: 2,
        semicolons: true,
        quotes: 'single',
        trailingComma: true,
        language: 'javascript'
      }
    };
    this.aiModels = {
      primary: 'gpt4',
      fallback: ['claude', 'mistral']
    };
  }

  // 1. Streaming intelligent avec étapes et possibilité d'annulation
  async generateWithAdvancedStreaming(
    prompt: string,
    language: string,
    existingCode: string = "",
    projectFiles: any[] = []
  ): Promise<string> {
    this.cancelToken.cancelled = false;
    
    try {
      // ÉTAPE 1: Analyse du contexte projet
      this.onMessage({
        type: 'thinking',
        content: `🔍 Analyse de ${projectFiles.length} fichiers du projet...`,
        step: 1,
        canCancel: true
      });
      
      const projectAnalysis = await this.analyzeProjectContext(projectFiles);
      if (this.cancelToken.cancelled) return '';
      
      // ÉTAPE 2: Détection des problèmes multi-fichier
      this.onMessage({
        type: 'analyzing',
        content: `🔧 Détection des dépendances et problèmes inter-fichiers...`,
        step: 2,
        canCancel: true
      });
      
      const crossFileIssues = await this.detectCrossFileIssues(projectFiles);
      if (this.cancelToken.cancelled) return '';
      
      // ÉTAPE 3: Recherche de documentation automatique
      this.onMessage({
        type: 'working',
        content: `📚 Recherche des meilleures pratiques pour ${language}...`,
        step: 3,
        canCancel: true
      });
      
      const docSuggestions = await this.searchRelevantDocumentation(prompt, language);
      if (this.cancelToken.cancelled) return '';
      
      // ÉTAPE 4: Génération avec IA contextuelle
      this.onMessage({
        type: 'code',
        content: `⚡ Génération du code ${language} avec contexte intelligent...`,
        step: 4,
        canCancel: true
      });
      
      const enhancedPrompt = this.buildContextualPrompt(
        prompt, 
        language, 
        existingCode, 
        projectAnalysis, 
        crossFileIssues,
        docSuggestions
      );
      
      const result = await this.generateWithMultipleModels(enhancedPrompt, language, existingCode);
      if (this.cancelToken.cancelled) return '';
      
      // ÉTAPE 5: Auto-fix et refactorisation
      this.onMessage({
        type: 'refactor',
        content: `🔧 Optimisation et validation du code ${language}...`,
        step: 5,
        canCancel: true
      });
      
      const optimizedResult = await this.applyAutoFixAndRefactor(result, language);
      if (this.cancelToken.cancelled) return '';
      
      // Message final avec détails du code généré
      const codeStats = this.analyzeGeneratedCode(optimizedResult, language);
      const statsMessage = codeStats.type === 'web' 
        ? `${codeStats.lines} lignes, ${codeStats.tags} éléments HTML`
        : `${codeStats.lines} lignes, ${codeStats.functions} fonctions`;
        
      this.onMessage({
        type: 'complete',
        content: `Code ${language} généré avec succès - ${statsMessage}`,
        confidence: 0.95,
        suggestions: this.generateImprovementSuggestions(optimizedResult),
        metadata: codeStats
      });
      
      return optimizedResult;
      
    } catch (error) {
      this.onMessage({
        type: 'debug',
        content: `Erreur CodePhantom: ${error}`,
        suggestions: ['Réessayer avec un prompt simplifié', 'Vérifier la connexion IA']
      });
      return '';
    }
  }

  // 2. Analyse de contexte de projet étendu
  private async analyzeProjectContext(files: any[]): Promise<string> {
    const analysis = {
      totalFiles: files.length,
      languages: new Set<string>(),
      frameworks: new Set<string>(),
      dependencies: new Set<string>(),
      patterns: new Set<string>()
    };
    
    for (const file of files) {
      // Détection du langage
      const lang = this.detectLanguageFromFilename(file.name);
      analysis.languages.add(lang);
      
      // Détection des frameworks/librairies
      const frameworks = this.detectFrameworks(file.content);
      frameworks.forEach(fw => analysis.frameworks.add(fw));
      
      // Extraction des imports/requires
      const deps = this.extractDependencies(file.content, lang);
      deps.forEach(dep => analysis.dependencies.add(dep));
      
      // Détection des patterns architecturaux
      const patterns = this.detectArchitecturalPatterns(file.content, file.name);
      patterns.forEach(pattern => analysis.patterns.add(pattern));
    }
    
    return `Projet: ${analysis.totalFiles} fichiers, Langages: ${Array.from(analysis.languages).join(', ')}, Frameworks: ${Array.from(analysis.frameworks).join(', ')}, Dépendances: ${Array.from(analysis.dependencies).join(', ')}, Patterns: ${Array.from(analysis.patterns).join(', ')}`;
  }

  // 3. Détection des problèmes inter-fichiers
  private async detectCrossFileIssues(files: any[]): Promise<string> {
    const issues = [];
    
    // Analyse des imports/exports
    const exports = new Map<string, string[]>();
    const imports = new Map<string, string[]>();
    
    files.forEach(file => {
      const fileExports = this.extractExports(file.content);
      const fileImports = this.extractImports(file.content);
      
      exports.set(file.name, fileExports);
      imports.set(file.name, fileImports);
    });
    
    // Détection des imports manquants
    imports.forEach((fileImports, filename) => {
      fileImports.forEach(importName => {
        let found = false;
        exports.forEach((fileExports, exportFilename) => {
          if (fileExports.includes(importName)) {
            found = true;
          }
        });
        if (!found) {
          issues.push(`Import manquant: ${importName} dans ${filename}`);
        }
      });
    });
    
    // Détection des variables non définies cross-file
    const globalVars = this.extractGlobalVariables(files);
    const undefinedVars = this.findUndefinedVariables(files, globalVars);
    issues.push(...undefinedVars);
    
    return issues.length > 0 ? `Problèmes détectés: ${issues.join(', ')}` : 'Aucun problème inter-fichier détecté';
  }

  // 4. Recherche de documentation automatique
  private async searchRelevantDocumentation(prompt: string, language: string): Promise<string> {
    const keywords = this.extractTechnicalKeywords(prompt);
    const docSuggestions: string[] = [];
    
    // Base de données de documentation courante
    const docDatabase: Record<string, string> = {
      'express.Router': 'Express.js Router permet de créer des routes modulaires',
      'React.useState': 'Hook React pour gérer l\'état local d\'un composant',
      'async/await': 'Syntaxe moderne pour gérer les promesses JavaScript',
      'CSS Grid': 'Système de layout CSS bidimensionnel',
      'SQL JOIN': 'Clause pour combiner des données de plusieurs tables'
    };
    
    keywords.forEach(keyword => {
      if (docDatabase[keyword]) {
        docSuggestions.push(`${keyword}: ${docDatabase[keyword]}`);
      }
    });
    
    return docSuggestions.length > 0 ? 
      `Documentation suggérée: ${docSuggestions.join(' | ')}` : 
      'Aucune documentation spécifique trouvée';
  }

  // 5. Génération avec multiple modèles IA
  private async generateWithMultipleModels(
    prompt: string, 
    language: string, 
    existingCode: string
  ): Promise<string> {
    
    try {
      // Tentative avec le modèle principal
      switch (this.aiModels.primary) {
        case 'gpt4':
          const gptResult = await generateCodeWithOpenAI(prompt, language, existingCode, '');
          return typeof gptResult === 'string' ? gptResult : gptResult.code || '';
        case 'claude':
          const claudeResult = await generateCodeWithAnthropic(prompt, language, existingCode, '');
          return typeof claudeResult === 'string' ? claudeResult : claudeResult.code || '';
        default:
          const defaultResult = await generateCodeWithOpenAI(prompt, language, existingCode, '');
          return typeof defaultResult === 'string' ? defaultResult : defaultResult.code || '';
      }
    } catch (error) {
      // Fallback vers autres modèles
      for (const fallbackModel of this.aiModels.fallback) {
        try {
          if (fallbackModel === 'claude') {
            const result = await generateCodeWithAnthropic(prompt, language, existingCode, '');
            return typeof result === 'string' ? result : result.code || '';
          } else {
            const result = await generateCodeWithOpenAI(prompt, language, existingCode, '');
            return typeof result === 'string' ? result : result.code || '';
          }
        } catch (fallbackError) {
          continue;
        }
      }
      throw new Error('Tous les modèles IA ont échoué');
    }
  }

  // 6. Auto-fix et refactorisation
  private async applyAutoFixAndRefactor(code: string, language: string): Promise<string> {
    let optimizedCode = code;
    
    // Application du style de code défini
    optimizedCode = this.applyCodeStyle(optimizedCode, language);
    
    // Corrections automatiques communes
    optimizedCode = this.applyCommonFixes(optimizedCode, language);
    
    // Optimisations de performance
    optimizedCode = this.applyPerformanceOptimizations(optimizedCode, language);
    
    return optimizedCode;
  }

  // 7. Debugger IA pour logs d'erreur
  async debugFromLogs(
    errorLogs: string[], 
    projectFiles: any[], 
    environment: string = 'development'
  ): Promise<string> {
    
    this.onMessage({
      type: 'debug',
      content: 'Analyse des logs d\'erreur...',
      step: 1
    });
    
    const debugContext: DebugContext = {
      errorLogs,
      stackTrace: this.extractStackTrace(errorLogs),
      environment,
      lastModifiedFiles: this.getRecentlyModifiedFiles(projectFiles)
    };
    
    const debugPrompt = this.buildDebugPrompt(debugContext, projectFiles);
    
    this.onMessage({
      type: 'analyzing',
      content: 'Recherche de la cause racine...',
      step: 2
    });
    
    const debugSolution = await this.generateWithMultipleModels(
      debugPrompt, 
      'debug', 
      this.getRelevantCode(debugContext, projectFiles)
    );
    
    this.onMessage({
      type: 'complete',
      content: 'Solution de debug générée',
      suggestions: ['Appliquer le fix', 'Voir les détails', 'Essayer une autre approche']
    });
    
    return debugSolution;
  }

  // Méthodes utilitaires
  private detectLanguageFromFilename(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const langMap: Record<string, string> = {
      '.js': 'javascript',
      '.ts': 'typescript',
      '.py': 'python',
      '.html': 'html',
      '.css': 'css',
      '.php': 'php',
      '.java': 'java',
      '.cpp': 'cpp',
      '.c': 'c',
      '.go': 'go',
      '.rs': 'rust'
    };
    return langMap[ext] || 'text';
  }

  private detectFrameworks(content: string): string[] {
    const frameworks: string[] = [];
    const patterns: Record<string, RegExp> = {
      'React': /import.*react|from ['"]react['"]/i,
      'Vue': /import.*vue|from ['"]vue['"]/i,
      'Angular': /@angular|import.*@angular/i,
      'Express': /require\(['"]express['"]\)|import.*express/i,
      'Django': /from django|import django/i,
      'Flask': /from flask|import flask/i,
      'Spring': /@SpringBootApplication|import org\.springframework/i,
      'Laravel': /use Illuminate|namespace App/i
    };
    
    Object.entries(patterns).forEach(([framework, pattern]) => {
      if (pattern.test(content)) {
        frameworks.push(framework);
      }
    });
    
    return frameworks;
  }

  private extractDependencies(content: string, language: string): string[] {
    const deps = [];
    
    if (language === 'javascript' || language === 'typescript') {
      const importPattern = /import.*from ['"]([^'"]+)['"]/g;
      const requirePattern = /require\(['"]([^'"]+)['"]\)/g;
      
      let match;
      while ((match = importPattern.exec(content)) !== null) {
        deps.push(match[1]);
      }
      while ((match = requirePattern.exec(content)) !== null) {
        deps.push(match[1]);
      }
    }
    
    if (language === 'python') {
      const importPattern = /(?:from|import)\s+([a-zA-Z_][a-zA-Z0-9_]*)/g;
      let match;
      while ((match = importPattern.exec(content)) !== null) {
        deps.push(match[1]);
      }
    }
    
    return deps;
  }

  private detectArchitecturalPatterns(content: string, filename: string): string[] {
    const patterns = [];
    
    // Détection MVC
    if (filename.includes('controller') || content.includes('Controller')) {
      patterns.push('MVC-Controller');
    }
    if (filename.includes('model') || content.includes('Model')) {
      patterns.push('MVC-Model');
    }
    if (filename.includes('view') || content.includes('View')) {
      patterns.push('MVC-View');
    }
    
    // Détection Repository Pattern
    if (filename.includes('repository') || content.includes('Repository')) {
      patterns.push('Repository');
    }
    
    // Détection Service Layer
    if (filename.includes('service') || content.includes('Service')) {
      patterns.push('Service-Layer');
    }
    
    return patterns;
  }

  private extractExports(content: string): string[] {
    const exports: string[] = [];
    const patterns = [
      /export\s+(?:const|let|var|function|class)\s+([a-zA-Z_][a-zA-Z0-9_]*)/g,
      /module\.exports\s*=\s*\{([^}]+)\}/g,
      /exports\.([a-zA-Z_][a-zA-Z0-9_]*)/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        exports.push(match[1]);
      }
    });
    
    return exports;
  }

  private extractImports(content: string): string[] {
    const imports: string[] = [];
    const patterns = [
      /import\s+\{([^}]+)\}/g,
      /import\s+([a-zA-Z_][a-zA-Z0-9_]*)/g,
      /require\(['"]([^'"]+)['"]\)/g
    ];
    
    patterns.forEach(pattern => {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        if (match[1].includes(',')) {
          match[1].split(',').forEach(imp => imports.push(imp.trim()));
        } else {
          imports.push(match[1]);
        }
      }
    });
    
    return imports;
  }

  private extractGlobalVariables(files: any[]): string[] {
    const globals: string[] = [];
    files.forEach(file => {
      const varPattern = /(?:var|let|const)\s+([a-zA-Z_][a-zA-Z0-9_]*)/g;
      let match;
      while ((match = varPattern.exec(file.content)) !== null) {
        globals.push(match[1]);
      }
    });
    return globals;
  }

  private findUndefinedVariables(files: any[], globalVars: string[]): string[] {
    const undefinedVars: string[] = [];
    files.forEach(file => {
      const usedVars = file.content.match(/[a-zA-Z_][a-zA-Z0-9_]*/g) || [];
      usedVars.forEach((varName: string) => {
        if (!globalVars.includes(varName) && !this.isBuiltinOrKeyword(varName)) {
          undefinedVars.push(`${varName} dans ${file.name}`);
        }
      });
    });
    return undefinedVars;
  }

  private isBuiltinOrKeyword(varName: string): boolean {
    const builtins = ['console', 'window', 'document', 'process', 'global', 'require', 'module', 'exports'];
    const keywords = ['function', 'return', 'if', 'else', 'for', 'while', 'const', 'let', 'var'];
    return builtins.includes(varName) || keywords.includes(varName);
  }

  private extractTechnicalKeywords(prompt: string): string[] {
    const techKeywords = [
      'express.Router', 'React.useState', 'async/await', 'CSS Grid', 'SQL JOIN',
      'MongoDB', 'PostgreSQL', 'Firebase', 'API REST', 'GraphQL',
      'Docker', 'Kubernetes', 'AWS', 'Azure', 'Heroku'
    ];
    
    return techKeywords.filter(keyword => 
      prompt.toLowerCase().includes(keyword.toLowerCase())
    );
  }

  private buildContextualPrompt(
    prompt: string,
    language: string,
    existingCode: string,
    projectAnalysis: string,
    crossFileIssues: string,
    docSuggestions: string
  ): string {
    // Spécialisation par type de langage pour forcer la génération de code
    let codeInstructions = '';
    
    if (language === 'html' || prompt.toLowerCase().includes('boutique') || prompt.toLowerCase().includes('site') || prompt.toLowerCase().includes('page')) {
      codeInstructions = `
IMPORTANT: Tu dois générer du code HTML complet et fonctionnel, pas du texte descriptif.

FORMAT REQUIS:
- Commence directement par <!DOCTYPE html>
- Inclus CSS inline dans <style>
- Inclus JavaScript inline dans <script> si nécessaire
- Code complet et prêt à être utilisé
- Structure sémantique HTML5
- Design responsive et moderne

EXEMPLE DE STRUCTURE ATTENDUE:
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nom du projet</title>
    <style>
        /* CSS complet ici */
    </style>
</head>
<body>
    <!-- HTML structuré ici -->
    <script>
        // JavaScript si nécessaire
    </script>
</body>
</html>`;
    } else {
      codeInstructions = `
IMPORTANT: Génère du code ${language} complet et fonctionnel, pas d'explications.
- Code directement utilisable
- Syntaxe correcte
- Bonnes pratiques appliquées
- Commentaires techniques pertinents`;
    }

    return `Tu es CodePhantom, un agent IA de développement avancé.

DEMANDE: ${prompt}

CONTEXTE PROJET: ${projectAnalysis}

PROBLÈMES DÉTECTÉS: ${crossFileIssues}

DOCUMENTATION: ${docSuggestions}

CODE EXISTANT:
\`\`\`${language}
${existingCode}
\`\`\`

${codeInstructions}

TÂCHE: Génère immédiatement le code ${language} complet pour: ${prompt}`;
  }

  private applyCodeStyle(code: string, language: string): string {
    let styled = code;
    
    // Application du style d'indentation
    if (this.projectContext.codeStyle.indentation === 'spaces') {
      const spaces = ' '.repeat(this.projectContext.codeStyle.spacesCount);
      styled = styled.replace(/\t/g, spaces);
    }
    
    // Application des quotes
    if (this.projectContext.codeStyle.quotes === 'single') {
      styled = styled.replace(/"/g, "'");
    } else {
      styled = styled.replace(/'/g, '"');
    }
    
    return styled;
  }

  private applyCommonFixes(code: string, language: string): string {
    let fixed = code;
    
    if (language === 'javascript' || language === 'typescript') {
      // Correction des points-virgules manquants
      fixed = fixed.replace(/([^;])\n/g, '$1;\n');
      
      // Correction des console.log en développement
      if (process.env.NODE_ENV === 'production') {
        fixed = fixed.replace(/console\.log\([^)]*\);?\n?/g, '');
      }
    }
    
    return fixed;
  }

  private applyPerformanceOptimizations(code: string, language: string): string {
    let optimized = code;
    
    if (language === 'javascript') {
      // Optimisation des boucles
      optimized = optimized.replace(
        /for\s*\(\s*let\s+i\s*=\s*0;\s*i\s*<\s*([^.]+)\.length;\s*i\+\+\s*\)/g,
        'for (let i = 0, len = $1.length; i < len; i++)'
      );
    }
    
    return optimized;
  }

  private extractStackTrace(errorLogs: string[]): string[] {
    const stackTrace: string[] = [];
    errorLogs.forEach(log => {
      const lines = log.split('\n');
      lines.forEach(line => {
        if (line.includes('at ') && (line.includes('.js:') || line.includes('.ts:'))) {
          stackTrace.push(line.trim());
        }
      });
    });
    return stackTrace;
  }

  private getRecentlyModifiedFiles(files: any[]): string[] {
    // Simulation - en réalité on utiliserait fs.stat pour les timestamps
    return files.slice(-3).map(f => f.name);
  }

  private buildDebugPrompt(debugContext: DebugContext, files: any[]): string {
    return `Tu es CodePhantom en mode Debug Expert.

ERREURS DÉTECTÉES:
${debugContext.errorLogs.join('\n')}

STACK TRACE:
${debugContext.stackTrace.join('\n')}

ENVIRONNEMENT: ${debugContext.environment}

FICHIERS RÉCEMMENT MODIFIÉS: ${debugContext.lastModifiedFiles.join(', ')}

ANALYSE ET PROPOSE:
1. La cause racine exacte de l'erreur
2. La solution step-by-step
3. Le code corrigé
4. Les mesures préventives

Génère une solution de debug complète:`;
  }

  private getRelevantCode(debugContext: DebugContext, files: any[]): string {
    // Retourne le code des fichiers mentionnés dans la stack trace
    const relevantFiles = files.filter(file => 
      debugContext.stackTrace.some(trace => trace.includes(file.name))
    );
    
    return relevantFiles.map(file => `// ${file.name}\n${file.content}`).join('\n\n');
  }

  private analyzeGeneratedCode(code: string, language: string): any {
    const lines = code.split('\n').length;
    let functions = 0;
    let classes = 0;
    
    if (language === 'javascript' || language === 'typescript') {
      functions = (code.match(/function\s+\w+|=>\s*{|const\s+\w+\s*=\s*\(/g) || []).length;
      classes = (code.match(/class\s+\w+/g) || []).length;
    } else if (language === 'html') {
      const tags = (code.match(/<\w+/g) || []).length;
      const styles = (code.match(/style\s*{[^}]*}/g) || []).length;
      return { lines, tags, styles, type: 'web' };
    }
    
    return { lines, functions, classes, type: 'code' };
  }

  private generateImprovementSuggestions(code: string): string[] {
    const suggestions = [];
    
    if (code.includes('console.log')) {
      suggestions.push('Remplacer console.log par un système de logging professionnel');
    }
    
    if (code.includes('var ')) {
      suggestions.push('Utiliser const/let au lieu de var');
    }
    
    if (code.includes('function(')) {
      suggestions.push('Considérer les arrow functions pour plus de clarté');
    }
    
    if (!code.includes('try') && !code.includes('catch')) {
      suggestions.push('Ajouter la gestion d\'erreurs');
    }
    
    return suggestions.slice(0, 3);
  }

  // Méthode pour annuler la génération en cours
  public cancelGeneration(): void {
    this.cancelToken.cancelled = true;
    this.onMessage({
      type: 'complete',
      content: 'Génération annulée par l\'utilisateur'
    });
  }

  // Configuration du style de code
  public setCodeStyle(style: Partial<CodeStyle>): void {
    this.projectContext.codeStyle = { ...this.projectContext.codeStyle, ...style };
  }

  // Configuration des modèles IA
  public setAIModels(primary: 'gpt4' | 'claude' | 'mistral', fallback: string[] = []): void {
    this.aiModels.primary = primary;
    this.aiModels.fallback = fallback;
  }
}