import { exec } from "child_process";
import fs from "fs/promises";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import util from "util";

const execPromise = util.promisify(exec);

// Function to execute code
export async function executeCode(code: string, language: string) {
  const tempDir = path.join(process.cwd(), "temp");
  
  try {
    // Ensure temp directory exists
    await fs.mkdir(tempDir, { recursive: true });
    
    const uniqueId = uuidv4();
    let filePath, command, result, error;
    
    // Configure execution based on language
    switch (language.toLowerCase()) {
      case "python":
        filePath = path.join(tempDir, `${uniqueId}.py`);
        await fs.writeFile(filePath, code);
        command = `python ${filePath}`;
        break;
        
      case "javascript":
      case "js":
        filePath = path.join(tempDir, `${uniqueId}.js`);
        await fs.writeFile(filePath, code);
        command = `node ${filePath}`;
        break;
        
      case "html":
        // For HTML, we just return the code to be rendered in the preview
        return { output: code, error: null };
        
      case "css":
        // For CSS, we just return the code to be applied in the preview
        return { output: code, error: null };
        
      case "c++":
      case "cpp":
        filePath = path.join(tempDir, `${uniqueId}.cpp`);
        const outputPath = path.join(tempDir, uniqueId);
        await fs.writeFile(filePath, code);
        
        // First compile, then execute
        try {
          await execPromise(`g++ ${filePath} -o ${outputPath}`);
          command = outputPath;
        } catch (compileError) {
          return { output: null, error: compileError.stderr };
        }
        break;
        
      default:
        throw new Error(`Unsupported language: ${language}`);
    }
    
    // Execute the code with a timeout
    try {
      const { stdout, stderr } = await execPromise(command, { timeout: 5000 });
      result = stdout;
      error = stderr;
    } catch (executionError) {
      error = executionError.message || "Execution error";
    }
    
    // Clean up
    try {
      if (filePath) await fs.unlink(filePath);
      if (language.toLowerCase() === "cpp" || language.toLowerCase() === "c++") {
        const outputPath = path.join(tempDir, uniqueId);
        await fs.unlink(outputPath);
      }
    } catch (cleanupError) {
      console.error("Cleanup error:", cleanupError);
    }
    
    return { output: result, error };
  } catch (error) {
    console.error("Error executing code:", error);
    return { output: null, error: error.message || "Unknown error" };
  }
}
