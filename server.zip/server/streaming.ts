// Module pour la communication en temps réel de l'agent Replit
import OpenAI from "openai";

const xai = new OpenAI({ 
  baseURL: "https://api.x.ai/v1", 
  apiKey: process.env.XAI_API_KEY 
});

interface StreamingMessage {
  type: 'thinking' | 'working' | 'code' | 'complete' | 'file' | 'conversation';
  content: string;
  step?: number;
  filename?: string;
  filePath?: string;
  language?: string;
  isConversational?: boolean;
}

export class ReplitAgentStreaming {
  private onMessage: (message: StreamingMessage) => void;
  private generatedFiles: Map<string, string> = new Map(); // Stockage des fichiers générés
  
  constructor(onMessage: (message: StreamingMessage) => void) {
    this.onMessage = onMessage;
  }

  // Parser le nom de fichier pour séparer le chemin du nom
  private parseFilePath(fullPath: string): { fileName: string; filePath: string } {
    if (fullPath.includes('/')) {
      const lastSlashIndex = fullPath.lastIndexOf('/');
      const filePath = fullPath.substring(0, lastSlashIndex + 1);
      const fileName = fullPath.substring(lastSlashIndex + 1);
      return { fileName, filePath };
    }
    return { fileName: fullPath, filePath: '' };
  }

  // Détecter si le prompt nécessite une correction d'erreur
  private isErrorCorrectionPrompt(prompt: string): boolean {
    const lowerPrompt = prompt.toLowerCase();
    
    const errorIndicators = [
      'erreur', 'error', 'bug', 'problème', 'problem',
      'ne fonctionne pas', 'doesn\'t work', 'not working',
      'corrige', 'corriger', 'fix', 'répare', 'repair',
      'il y a une erreur', 'there is an error',
      'ça ne marche pas', 'it doesn\'t work',
      'debug', 'débogage', 'incorrect', 'wrong',
      'regarde pourquoi', 'regarder pourquoi', 'see why',
      'pourquoi ça', 'why does', 'why doesn\'t',
      'marche pas', 'doesn\'t work', 'not work'
    ];
    
    return errorIndicators.some(indicator => lowerPrompt.includes(indicator));
  }

  // Détecter si le prompt nécessite une modification du code existant
  private isCodeModificationPrompt(prompt: string): boolean {
    const lowerPrompt = prompt.toLowerCase();
    
    const modificationIndicators = [
      'ajoute', 'ajouter', 'add', 'ajout',
      'modifie', 'modifier', 'modify', 'change',
      'enlève', 'enlever', 'remove', 'supprime',
      'remplace', 'replace', 'substitue',
      'améliore', 'améliorer', 'improve',
      'peux tu ajouter', 'can you add',
      'peux tu modifier', 'can you modify',
      'il faut ajouter', 'need to add',
      'intègre', 'intégrer', 'integrate',
      'inclus', 'inclure', 'include'
    ];
    
    // Détecter les patterns spécifiques comme "ajoute X", "modifie Y"
    const modificationPatterns = [
      /ajoute\s+\w+/,
      /ajouter\s+\w+/,
      /modifie\s+\w+/,
      /modifier\s+\w+/,
      /add\s+\w+/,
      /change\s+\w+/,
      /include\s+\w+/
    ];
    
    return modificationIndicators.some(indicator => lowerPrompt.includes(indicator)) ||
           modificationPatterns.some(pattern => pattern.test(lowerPrompt));
  }

  // Détecter si le prompt nécessite une réponse conversationnelle
  private isConversationalPrompt(prompt: string): boolean {
    const lowerPrompt = prompt.toLowerCase();
    
    const conversationalIndicators = [
      'salut', 'bonjour', 'hello', 'hi', 'hey',
      'comment ça va', 'comment allez-vous', 'comment vas-tu',
      'merci', 'thanks', 'super', 'génial', 'parfait',
      'peux-tu', 'pourrais-tu', 'aide-moi',
      'qu\'est-ce que', 'pourquoi', 'comment',
      'explique', 'dis-moi', 'raconte',
      '?', 'que penses-tu', 'ton avis'
    ];
    
    return conversationalIndicators.some(indicator => lowerPrompt.includes(indicator)) ||
           lowerPrompt.length < 50 && (lowerPrompt.includes('?') || lowerPrompt.startsWith('comment'));
  }

  // Enrichir le prompt pour une correction d'erreur avec analyse intelligente
  private enhanceErrorCorrectionPrompt(prompt: string, language: string, existingCode: string): string {
    return `
Tu es un développeur expert en debugging ${language} avec une approche analytique rigoureuse. L'utilisateur signale un problème dans le code existant.

ÉTAPE 1 - ANALYSE APPROFONDIE DU CODE:
Code actuel à analyser:
\`\`\`${language}
${existingCode}
\`\`\`

Problème signalé: ${prompt}

ÉTAPE 2 - DIAGNOSTIC INTELLIGENT:
Avant de proposer une solution, tu DOIS:
1. **Analyser ligne par ligne** le code existant
2. **Identifier les erreurs potentielles** (syntaxe, logique, références manquantes)
3. **Tester mentalement** le comportement attendu vs actuel
4. **Localiser précisément** où le code échoue
5. **Comprendre la cause racine** du problème

ÉTAPE 3 - SOLUTION CIBLÉE:
1. Explique d'abord ton diagnostic détaillé
2. Identifie exactement ce qui ne fonctionne pas et pourquoi
3. Propose la correction minimale et précise
4. Explique pourquoi cette correction résout le problème
5. Fournis UNIQUEMENT le code corrigé, pas un nouveau projet

APPROCHE REQUISE:
- Sois un détective du code, pas un générateur aveugle
- Analyse avant d'agir
- Corrige seulement ce qui est cassé
- Explique ton raisonnement

Concentre-toi sur l'analyse intelligente du problème avant toute correction.
`;
  }

  // Enrichir le prompt pour une modification du code existant
  private enhanceCodeModificationPrompt(prompt: string, language: string, existingCode: string): string {
    return `
Tu es un expert en développement ${language}. L'utilisateur veut modifier le code existant.

Code actuel:
\`\`\`${language}
${existingCode}
\`\`\`

Demande de modification: ${prompt}

IMPORTANT - Instructions spécifiques pour modification:
1. MODIFIE uniquement le fichier existant, ne crée PAS de nouveaux fichiers
2. Intègre la modification directement dans le code existant fourni
3. Préserve toute la structure et fonctionnalité existante
4. Ajoute uniquement les éléments demandés
5. Fournis le code modifié complet avec UNIQUEMENT les changements intégrés
6. Ne sépare PAS en plusieurs fichiers - tout doit être dans le même fichier

Format de réponse:
- Explique brièvement les modifications
- Fournis le code modifié en UN SEUL bloc
- Utilise le même nom de fichier que l'original

Concentre-toi sur l'intégration harmonieuse de la modification dans le code existant.
`;
  }

  // Enrichir le prompt pour une réponse conversationnelle
  private enhanceConversationalPrompt(prompt: string, language: string, context: string): string {
    return `
Tu es un assistant de programmation amical et conversationnel. Réponds de manière naturelle et conviviale.

Contexte: ${context}
Langage de programmation: ${language}

Instructions:
- Si la demande nécessite du code, génère-le avec des explications amicales
- Si c'est une question générale, réponds de manière conversationnelle
- Sois professionnel mais décontracté
- Adapte ton ton à la situation

Demande de l'utilisateur: ${prompt}
`;
  }

  // Parse et sépare les fichiers multiples (version robuste - amélioration ChatGPT)
  private parseMultipleFiles(content: string): Array<{filename: string, content: string, language: string}> {
    const files: Array<{filename: string, content: string, language: string}> = [];
    
    // Nouveau pattern pour détecter les noms de fichiers avec extensions dans les blocs de code
    const codeBlockWithFilenameRegex = /```(\w+):([^\n\r]+)\n([\s\S]*?)```/g;
    let match;
    
    // Recherche des blocs avec nom de fichier explicite (ex: ```html:member.html)
    while ((match = codeBlockWithFilenameRegex.exec(content)) !== null) {
      const language = match[1];
      const filename = match[2].trim();
      const fileContent = match[3];
      
      if (fileContent && fileContent.trim()) {
        files.push({
          filename: filename,
          content: fileContent.trim(),
          language: language
        });
      }
    }
    
    // Si pas de noms explicites, utiliser l'ancien pattern
    if (files.length === 0) {
      const codeBlockRegex = /```(\w+)(?:\s+filename=([^\n\r]+))?\n([\s\S]*?)```/g;
      
      while ((match = codeBlockRegex.exec(content)) !== null) {
        const language = match[1];
        const filename = match[2]?.trim() || this.getSmartFilename(language, match[3]);
        const fileContent = match[3];
        
        if (fileContent && fileContent.trim()) {
          files.push({
            filename: filename,
            content: fileContent.trim(),
            language: language
          });
        }
      }
    }
    
    // Détection alternative si pas de blocs markdown classiques
    if (files.length === 0) {
      // Recherche de commentaires avec noms de fichiers
      const fileCommentRegex = /(?:\/\*|<!--|\#)\s*(?:File|Fichier):\s*([^\s\*\->]+)(?:\*\/|-->)?\s*\n([\s\S]*?)(?=(?:\/\*|<!--|\#)\s*(?:File|Fichier):|$)/gi;
      let commentMatch;
      
      while ((commentMatch = fileCommentRegex.exec(content)) !== null) {
        const filename = commentMatch[1].trim();
        const fileContent = commentMatch[2];
        const language = this.detectLanguageFromFilename(filename);
        
        if (fileContent && fileContent.trim()) {
          files.push({
            filename: filename,
            content: fileContent.trim(),
            language: language
          });
        }
      }
    }
    
    // Si toujours pas de fichiers détectés, créer un fichier unique
    if (files.length === 0) {
      const defaultLang = this.detectLanguageFromContent(content);
      files.push({
        filename: this.getSmartFilename(defaultLang, content),
        content: content.trim(),
        language: defaultLang
      });
    }
    
    return files;
  }
  
  private detectLanguageFromFilename(filename: string): string {
    const ext = filename.split('.').pop()?.toLowerCase();
    const langMap: Record<string, string> = {
      'html': 'html',
      'htm': 'html',
      'css': 'css',
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'php': 'php',
      'rb': 'ruby',
      'go': 'go'
    };
    return langMap[ext || ''] || 'text';
  }
  
  private getDefaultFilename(language: string): string {
    const extensions: Record<string, string> = {
      'html': 'index.html',
      'css': 'styles.css',
      'javascript': 'script.js',
      'js': 'script.js',
      'python': 'main.py',
      'java': 'Main.java',
      'cpp': 'main.cpp',
      'c': 'main.c'
    };
    return extensions[language.toLowerCase()] || `main.${language}`;
  }

  private getSmartFilename(language: string, content: string): string {
    // Analyser le contenu pour détecter des noms de pages spécifiques
    const lowerContent = content.toLowerCase();
    
    if (language === 'html') {
      // Détecter le type de page basé sur le contenu
      if (lowerContent.includes('admin') || lowerContent.includes('administration')) {
        return 'admin.html';
      }
      if (lowerContent.includes('membre') || lowerContent.includes('member') || lowerContent.includes('profil')) {
        return 'member.html';
      }
      if (lowerContent.includes('contact') || lowerContent.includes('contactez')) {
        return 'contact.html';
      }
      if (lowerContent.includes('produit') || lowerContent.includes('product') || lowerContent.includes('boutique')) {
        return 'boutique.html';
      }
      if (lowerContent.includes('portfolio')) {
        return 'portfolio.html';
      }
      if (lowerContent.includes('rejoindre') || lowerContent.includes('communau')) {
        return 'rejoindre.html';
      }
      if (lowerContent.includes('patrick')) {
        return 'patrick.html';
      }
      // Par défaut pour HTML
      return 'index.html';
    }
    
    if (language === 'css') {
      return 'styles.css';
    }
    
    if (language === 'javascript') {
      return 'script.js';
    }
    
    if (language === 'python') {
      if (lowerContent.includes('main') || lowerContent.includes('app')) {
        return 'main.py';
      }
      if (lowerContent.includes('config')) {
        return 'config.py';
      }
      if (lowerContent.includes('model')) {
        return 'models.py';
      }
      return 'app.py';
    }
    
    // Pour les autres langages, utiliser le nom par défaut
    return this.getDefaultFilename(language);
  }
  
  private detectLanguageFromContent(content: string): string {
    if (content.includes('<!DOCTYPE') || content.includes('<html')) return 'html';
    if (content.includes('{') && content.includes('color:')) return 'css';
    if (content.includes('function') || content.includes('const ')) return 'javascript';
    if (content.includes('def ') || content.includes('import ')) return 'python';
    return 'html';
  }

  // Méthodes pour édition post-génération (recommandation ChatGPT #3)
  public getGeneratedFile(filename: string): string | undefined {
    return this.generatedFiles.get(filename);
  }

  public updateGeneratedFile(filename: string, content: string): void {
    this.generatedFiles.set(filename, content);
    
    // Notification de mise à jour
    this.onMessage({
      type: 'file',
      content: content,
      filename: filename,
      language: this.detectLanguageFromContent(content)
    });
  }

  public getAllGeneratedFiles(): Map<string, string> {
    return new Map(this.generatedFiles);
  }

  public addFileToProject(filename: string, content: string): void {
    this.generatedFiles.set(filename, content);
    
    this.onMessage({
      type: 'file',
      content: content,
      filename: filename,
      language: this.detectLanguageFromContent(content)
    });
  }

  // Génération de preview HTML complet (version robuste - amélioration ChatGPT)
  public generatePreviewHTML(): string {
    const htmlFile = this.generatedFiles.get('index.html') || '';
    const cssFile = this.generatedFiles.get('styles.css') || '';
    const jsFile = this.generatedFiles.get('script.js') || '';

    // Si pas de HTML de base, créer une structure minimale
    if (!htmlFile) {
      return this.createMinimalHTML(cssFile, jsFile);
    }

    // Injection automatique du CSS et JS dans le HTML avec gestion robuste
    let previewHTML = htmlFile;
    
    // Injection du CSS si présent et pas déjà inclus
    if (cssFile && !this.hasStyleIncluded(previewHTML)) {
      previewHTML = this.injectCSS(previewHTML, cssFile);
    }
    
    // Injection du JavaScript si présent et pas déjà inclus
    if (jsFile && !this.hasScriptIncluded(previewHTML)) {
      previewHTML = this.injectJS(previewHTML, jsFile);
    }

    return previewHTML;
  }

  private createMinimalHTML(cssFile: string, jsFile: string): string {
    return `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview</title>
    ${cssFile ? `<style>\n${cssFile}\n</style>` : ''}
</head>
<body>
    <div class="container">
        <h1>Aucun contenu HTML généré</h1>
        <p>Demandez à l'agent de créer du contenu HTML pour voir la prévisualisation.</p>
    </div>
    ${jsFile ? `<script>\n${jsFile}\n</script>` : ''}
</body>
</html>`;
  }

  private hasStyleIncluded(html: string): boolean {
    return html.includes('<style>') || html.includes('<link') && html.includes('stylesheet');
  }

  private hasScriptIncluded(html: string): boolean {
    return html.includes('<script>') || html.includes('<script src=');
  }

  private injectCSS(html: string, css: string): string {
    const headCloseIndex = html.indexOf('</head>');
    if (headCloseIndex !== -1) {
      return html.substring(0, headCloseIndex) + 
             `\n    <style>\n${css}\n    </style>\n` + 
             html.substring(headCloseIndex);
    }
    
    // Fallback: si pas de </head>, injecter au début
    const bodyIndex = html.indexOf('<body');
    if (bodyIndex !== -1) {
      return html.substring(0, bodyIndex) + 
             `<style>\n${css}\n</style>\n` + 
             html.substring(bodyIndex);
    }
    
    // Fallback ultime: ajouter au début du contenu
    return `<style>\n${css}\n</style>\n${html}`;
  }

  private injectJS(html: string, js: string): string {
    const bodyCloseIndex = html.lastIndexOf('</body>');
    if (bodyCloseIndex !== -1) {
      return html.substring(0, bodyCloseIndex) + 
             `\n    <script>\n${js}\n    </script>\n` + 
             html.substring(bodyCloseIndex);
    }
    
    // Fallback: si pas de </body>, ajouter à la fin
    const htmlCloseIndex = html.lastIndexOf('</html>');
    if (htmlCloseIndex !== -1) {
      return html.substring(0, htmlCloseIndex) + 
             `<script>\n${js}\n</script>\n` + 
             html.substring(htmlCloseIndex);
    }
    
    // Fallback ultime: ajouter à la fin du contenu
    return `${html}\n<script>\n${js}\n</script>`;
  }

  // Mode Ghostwriter - streaming token-par-token comme Replit avec système intelligent
  async generateWithGhostwriterMode(
    prompt: string, 
    language: string, 
    existingCode: string = "", 
    context: string = ""
  ): Promise<string> {
    
    // Détecter le type de demande avec prise en compte du contexte
    const isErrorCorrection = this.isErrorCorrectionPrompt(prompt);
    const isCodeModification = this.isCodeModificationPrompt(prompt);
    const isConversational = this.isConversationalPrompt(prompt);
    
    // Si on a du code existant et que la demande semble être une modification même courte
    const hasExistingCode = existingCode && existingCode.trim().length > 50;
    const isLikelyModification = hasExistingCode && (
      isCodeModification || 
      prompt.trim().length < 100 || // Demandes courtes avec code existant = probablement modification
      /^(ajoute|ajouter|modifie|modifier|enlève|enlever|change|add|remove)\b/i.test(prompt.trim())
    );
    
    let enhancedPrompt: string;
    if (isErrorCorrection && hasExistingCode) {
      // Mode correction d'erreur
      enhancedPrompt = this.enhanceErrorCorrectionPrompt(prompt, language, existingCode);
      this.onMessage({
        type: 'working',
        content: 'Analyse du code pour identifier l\'erreur...'
      });
    } else if (isLikelyModification) {
      // Mode modification du code existant
      enhancedPrompt = this.enhanceCodeModificationPrompt(prompt, language, existingCode);
      this.onMessage({
        type: 'working',
        content: 'Modification du code existant...'
      });
    } else if (isConversational) {
      // Utiliser le mode conversationnel
      enhancedPrompt = this.enhanceConversationalPrompt(prompt, language, context);
      this.onMessage({
        type: 'conversation',
        content: 'Mode conversation activé...',
        isConversational: true
      });
    } else {
      // Mode génération simple et direct
      enhancedPrompt = `Crée ${prompt}. Génère du code HTML complet avec CSS et JavaScript intégrés. Code fonctionnel prêt à utiliser.`;
    }
    
    let fallbackReason = "";
    
    try {
      // Tentative avec l'agent principal (xAI Grok)
      console.log("🤖 Ghostwriter: Tentative avec agent principal (xAI)");
      
      let systemPrompt = `Tu es Replit Ghostwriter. Génère du code directement sans trop d'explications.

INSTRUCTIONS CRITIQUES:
- Génère UNIQUEMENT du code fonctionnel
- Pour une boutique: HTML, CSS et JavaScript purs avec fonctionnalités complètes
- Pas de frameworks complexes, code simple et direct
- Inclus toutes les fonctionnalités demandées dans le code
- Code prêt à être utilisé immédiatement`;
      
      if (isErrorCorrection) {
        systemPrompt = `Analyse le code et corrige l'erreur spécifique. Fournis uniquement le code corrigé.`;
      } else if (isLikelyModification) {
        systemPrompt = `Modifie le code existant selon la demande. Fournis le code modifié complet.`;
      }

      this.onMessage({
        type: 'working',
        content: 'Génération du code en cours...'
      });

      const stream = await xai.chat.completions.create({
        model: "grok-2-1212",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: enhancedPrompt }
        ],
        stream: true,
        temperature: 0.7,
        max_tokens: 4000
      });

      let accumulatedContent = "";
      
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        if (delta) {
          accumulatedContent += delta;
          
          // Streaming immédiat comme Replit original
          this.onMessage({
            type: 'code',
            content: accumulatedContent
          });
        }
      }
      
      // Post-traitement pour créer les fichiers séparés
      this.finalizeGhostwriterFiles(accumulatedContent);
      
      // Message de completion
      this.onMessage({
        type: 'complete',
        content: 'Code généré avec succès!'
      });
      
      console.log("✅ Ghostwriter: Réponse principale réussie");
      return accumulatedContent;
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      console.log(`🔄 Ghostwriter: Fallback vers OpenAI (${errorMessage})`);
      
      // Fallback intelligent vers OpenAI
      return this.generateWithOpenAIFallback(prompt, language, existingCode, context);
    }
  }

  // Analyse avancée du code pour détecter les erreurs spécifiques
  private analyzeCodeForIssues(code: string, prompt: string): string {
    const issues = [];
    const lowerPrompt = prompt.toLowerCase();
    
    if (code) {
      // Détection d'erreurs JavaScript communes
      if (code.includes('onclick') && !code.includes('function') && !code.includes('=>')) {
        issues.push("Fonction onclick référencée mais non définie");
      }
      
      if (code.includes('getElementById') && !code.includes('<script>')) {
        issues.push("Manipulation DOM sans balise script");
      }
      
      // Détection d'erreurs de syntaxe courantes
      const openBraces = (code.match(/\{/g) || []).length;
      const closeBraces = (code.match(/\}/g) || []).length;
      if (openBraces !== closeBraces) {
        issues.push(`Accolades non équilibrées: ${openBraces} ouvertes, ${closeBraces} fermées`);
      }
      
      const openParens = (code.match(/\(/g) || []).length;
      const closeParens = (code.match(/\)/g) || []).length;
      if (openParens !== closeParens) {
        issues.push(`Parenthèses non équilibrées: ${openParens} ouvertes, ${closeParens} fermées`);
      }
      
      // Détection d'erreurs HTML
      if (code.includes('<') && code.includes('>')) {
        const unclosedTags = this.detectUnclosedHTMLTags(code);
        if (unclosedTags.length > 0) {
          issues.push(`Balises HTML non fermées: ${unclosedTags.join(', ')}`);
        }
      }
      
      // Détection d'erreurs CSS
      if (code.includes('style=') || code.includes('<style>')) {
        const cssErrors = this.detectCSSErrors(code);
        issues.push(...cssErrors);
      }
      
      // Détection de variables non définies
      const undefinedVars = this.detectUndefinedVariables(code);
      if (undefinedVars.length > 0) {
        issues.push(`Variables potentiellement non définies: ${undefinedVars.join(', ')}`);
      }
    }
    
    // Analyse des problèmes signalés par l'utilisateur
    if (lowerPrompt.includes('ne marche pas') || lowerPrompt.includes('erreur') || 
        lowerPrompt.includes('bug') || lowerPrompt.includes('problème')) {
      issues.push("Problème explicitement signalé par l'utilisateur");
    }
    
    return issues.length > 0 ? `Erreurs détectées: ${issues.join(' | ')}` : "Code analysé - aucune erreur évidente détectée";
  }

  // Détecter les balises HTML non fermées
  private detectUnclosedHTMLTags(code: string): string[] {
    const unclosed = [];
    const tagPattern = /<(\w+)(?:\s[^>]*)?>/g;
    const closingTagPattern = /<\/(\w+)>/g;
    
    const openTags = [];
    let match;
    
    // Collecter les balises ouvrantes
    while ((match = tagPattern.exec(code)) !== null) {
      const tag = match[1].toLowerCase();
      if (!['img', 'br', 'hr', 'input', 'meta', 'link'].includes(tag)) {
        openTags.push(tag);
      }
    }
    
    // Supprimer les balises fermantes
    while ((match = closingTagPattern.exec(code)) !== null) {
      const tag = match[1].toLowerCase();
      const index = openTags.lastIndexOf(tag);
      if (index !== -1) {
        openTags.splice(index, 1);
      }
    }
    
    return openTags;
  }

  // Détecter les erreurs CSS courantes
  private detectCSSErrors(code: string): string[] {
    const errors = [];
    
    // Propriétés CSS malformées
    if (code.includes(':;') || code.includes(';;')) {
      errors.push("Propriétés CSS malformées détectées");
    }
    
    // Accolades CSS non équilibrées dans les styles
    const styleContent = code.match(/<style[^>]*>([\s\S]*?)<\/style>/gi);
    if (styleContent) {
      styleContent.forEach(style => {
        const openBraces = (style.match(/\{/g) || []).length;
        const closeBraces = (style.match(/\}/g) || []).length;
        if (openBraces !== closeBraces) {
          errors.push("Accolades CSS non équilibrées");
        }
      });
    }
    
    return errors;
  }

  // Détecter les variables JavaScript potentiellement non définies
  private detectUndefinedVariables(code: string): string[] {
    const undefinedVars: string[] = [];
    
    // Chercher les variables utilisées sans déclaration visible
    const varUsagePattern = /(?:^|[^a-zA-Z0-9_$])([a-zA-Z_$][a-zA-Z0-9_$]*)\s*\(/g;
    const functionCalls: string[] = [];
    let match;
    
    while ((match = varUsagePattern.exec(code)) !== null) {
      const varName = match[1];
      if (!['console', 'document', 'window', 'alert', 'parseInt', 'parseFloat'].includes(varName)) {
        functionCalls.push(varName);
      }
    }
    
    // Vérifier si ces fonctions sont définies dans le code
    functionCalls.forEach(func => {
      if (!code.includes(`function ${func}`) && !code.includes(`${func} =`) && 
          !code.includes(`const ${func}`) && !code.includes(`let ${func}`) && 
          !code.includes(`var ${func}`)) {
        if (!undefinedVars.includes(func)) {
          undefinedVars.push(func);
        }
      }
    });
    
    return undefinedVars;
  }

  // Évaluation de la qualité de la réponse en temps réel
  private evaluateResponseQuality(content: string, quality: any): void {
    quality.length = content.length;
    quality.hasCode = content.includes('```') || content.includes('<') || content.includes('function');
    quality.hasExplanation = content.includes('Je') || content.includes('voici') || content.includes('solution');
  }

  // Vérification si la réponse est suffisante
  private isResponseSufficient(content: string, quality: any): boolean {
    return quality.length > 100 && (quality.hasCode || quality.hasExplanation);
  }

  // Fallback OpenAI avec système intelligent (comme Replit)
  async generateWithOpenAIFallback(
    prompt: string, 
    language: string, 
    existingCode: string = "", 
    context: string = ""
  ): Promise<string> {
    
    const { generateCodeWithOpenAI } = await import('./openai');
    
    try {
      console.log("🔄 Fallback OpenAI activé avec analyse intelligente");
      
      // Prompt enrichi avec analyse de code comme Replit
      const intelligentPrompt = this.buildIntelligentGhostwriterPrompt(prompt, language, existingCode, context);
      
      const result = await generateCodeWithOpenAI(intelligentPrompt, language, existingCode, context);
      
      // Extraction du contenu avec gestion de type
      let content: string;
      if (typeof result === 'string') {
        content = result;
      } else if (result && typeof result === 'object' && 'code' in result) {
        content = String(result.code || "");
      } else {
        content = String(result || "");
      }
      
      if (!content || content.length < 50) {
        throw new Error("Réponse OpenAI insuffisante");
      }
      
      // Simulation streaming pour UX fluide
      const chunks = content.match(/.{1,50}/g) || [content];
      let accumulated = "";
      
      for (const chunk of chunks) {
        accumulated += chunk;
        this.onMessage({
          type: 'code',
          content: accumulated
        });
        await this.delay(30);
      }
      
      // Traitement final des fichiers
      this.finalizeGhostwriterFiles(accumulated);
      
      console.log("✅ Fallback OpenAI réussi");
      return accumulated;
      
    } catch (fallbackError) {
      console.error("Fallback OpenAI échoué:", fallbackError);
      
      // Message d'erreur pédagogique comme Replit
      const errorMessage = `Je rencontre des difficultés techniques pour traiter votre demande "${prompt}". 

Voici ce que vous pouvez essayer :
1. Vérifiez votre connexion internet
2. Réessayez avec une demande plus simple
3. Contactez le support si le problème persiste`;
      
      this.onMessage({
        type: 'code',
        content: errorMessage
      });
      
      return errorMessage;
    }
  }

  // Construction de prompt intelligent avec analyse (comme Replit Ghostwriter)
  private buildIntelligentGhostwriterPrompt(prompt: string, language: string, existingCode: string, context: string, codeAnalysis: string = ""): string {
    // Analyser le code existant pour détecter les problèmes
    const analysisResult = existingCode ? this.analyzeCodeForIssues(existingCode, prompt) : "";
    
    return `Tu es un développeur expert avec une approche analytique rigoureuse comme Replit Ghostwriter.

DEMANDE UTILISATEUR: "${prompt}"

${existingCode ? `
ANALYSE DU CODE EXISTANT:
\`\`\`${language}
${existingCode}
\`\`\`

DIAGNOSTIC AUTOMATIQUE: ${analysisResult}

INSTRUCTIONS SPÉCIALISÉES:
1. ANALYSE d'abord le code existant ligne par ligne
2. IDENTIFIE précisément les erreurs ou problèmes
3. EXPLIQUE ce qui ne fonctionne pas et pourquoi
4. CORRIGE uniquement les problèmes identifiés
5. FOURNIS le code modifié avec explications

Approche de débogage expert:
- Détecte les erreurs de syntaxe, logique, références manquantes
- Vérifie la cohérence des balises, parenthèses, accolades
- Contrôle les fonctions appelées vs définies
- Analyse le flux d'exécution attendu vs réel
` : `
INSTRUCTIONS GÉNÉRATION:
- CHOISIS automatiquement le meilleur langage/technologie
- GÉNÈRE directement une solution complète et fonctionnelle
- CRÉE tous les fichiers nécessaires (format \`\`\`langage:nomfichier.ext)
- SOIS autonome: ne demande rien, génère tout

Exemples de choix automatiques:
- Site web/boutique → HTML, CSS, JavaScript
- API/serveur → Python (Flask/FastAPI), PHP, ou Node.js
- Application mobile → React Native, Flutter
- Base de données → SQL, Python avec SQLite
- Analyse de données → Python avec pandas
- Game → JavaScript, Python, ou Java
`}

${existingCode ? 'Concentre-toi sur l\'analyse et la correction précise.' : 'Génère immédiatement le code complet:'}`;
  }

  private buildGhostwriterPrompt(prompt: string, language: string, existingCode: string, context: string): string {
    return `Tu es Replit Ghostwriter, un assistant autonome qui génère du code directement.

DEMANDE: "${prompt}"

INSTRUCTIONS:
- CHOISIS automatiquement le meilleur langage pour cette demande (HTML/CSS/JS, Python, PHP, Java, etc.)
- GÉNÈRE immédiatement une solution complète et fonctionnelle
- NE DEMANDE PAS d'informations supplémentaires
- NE FAIS PAS d'analyse préalable, va droit au but
- CRÉE tous les fichiers nécessaires avec noms appropriés

Si c'est un site web: utilise HTML/CSS/JavaScript
Si c'est une API/backend: choisis Python, PHP ou Node.js
Si c'est une application: choisis Java, Python ou autre selon le besoin

Génère directement le code complet:`;
  }

  private processedFiles: Set<string> = new Set(); // Eviter les doublons

  private processTokenForFileDetection(token: string, accumulated: string): void {
    // Détection en temps réel des marqueurs de fichiers
    if (token.includes('```') || token.includes('<!-- ') || token.includes('/*')) {
      // Traitement différé pour éviter les faux positifs
      setTimeout(() => this.detectAndCreateFiles(accumulated), 100);
    }
  }

  private detectAndCreateFilesImmediately(content: string): void {
    // Détecter les blocs de code complets et les créer immédiatement
    const codePattern = /```(\w+)?\n([\s\S]*?)```/g;
    let match;
    
    while ((match = codePattern.exec(content)) !== null) {
      const language = match[1] || 'text';
      const codeContent = match[2].trim();
      
      if (codeContent.length > 20) { // Ignorer les petits snippets
        const filename = this.getSmartFilename(language, codeContent);
        const fileKey = `${filename}_${codeContent.substring(0, 50)}`; // Clé unique
        
        if (!this.processedFiles.has(fileKey)) {
          this.processedFiles.add(fileKey);
          
          // Stocker le fichier
          this.generatedFiles.set(filename, codeContent);
          
          // Envoyer immédiatement le fichier au client
          this.onMessage({
            type: 'file',
            content: codeContent,
            filename: filename,
            language: language
          });
          
          console.log(`📁 Fichier créé progressivement: ${filename}`);
        }
      }
    }
    
    // Détecter les fichiers HTML complets (sans ````)
    if (content.includes('<!DOCTYPE html') && content.includes('</html>')) {
      const htmlMatch = content.match(/(<!DOCTYPE[\s\S]*?<\/html>)/);
      if (htmlMatch) {
        const htmlContent = htmlMatch[1];
        const fileKey = `index.html_${htmlContent.substring(0, 50)}`;
        
        if (!this.processedFiles.has(fileKey)) {
          this.processedFiles.add(fileKey);
          
          // Extraire et séparer automatiquement CSS et JS inline
          this.extractAndCreateSeparateFiles(htmlContent);
        }
      }
    }
  }

  private extractAndCreateSeparateFiles(htmlContent: string): void {
    // Extraire CSS inline
    const cssMatch = htmlContent.match(/<style[^>]*>([\s\S]*?)<\/style>/);
    if (cssMatch && cssMatch[1].trim().length > 20) {
      const cssContent = cssMatch[1].trim();
      const cssKey = `styles.css_${cssContent.substring(0, 50)}`;
      
      if (!this.processedFiles.has(cssKey)) {
        this.processedFiles.add(cssKey);
        this.generatedFiles.set('styles.css', cssContent);
        this.onMessage({
          type: 'file',
          content: cssContent,
          filename: 'styles.css',
          language: 'css'
        });
        console.log(`📁 CSS extrait et créé: styles.css`);
      }
    }

    // Extraire JS inline
    const jsMatch = htmlContent.match(/<script[^>]*>([\s\S]*?)<\/script>/);
    if (jsMatch && jsMatch[1].trim().length > 20) {
      const jsContent = jsMatch[1].trim();
      const jsKey = `script.js_${jsContent.substring(0, 50)}`;
      
      if (!this.processedFiles.has(jsKey)) {
        this.processedFiles.add(jsKey);
        this.generatedFiles.set('script.js', jsContent);
        this.onMessage({
          type: 'file',
          content: jsContent,
          filename: 'script.js',
          language: 'javascript'
        });
        console.log(`📁 JavaScript extrait et créé: script.js`);
      }
    }

    // HTML nettoyé (sans inline CSS/JS)
    let cleanHtml = htmlContent;
    if (cssMatch) {
      cleanHtml = cleanHtml.replace(/<style[^>]*>[\s\S]*?<\/style>/, '<link rel="stylesheet" href="styles.css">');
    }
    if (jsMatch) {
      cleanHtml = cleanHtml.replace(/<script[^>]*>[\s\S]*?<\/script>/, '<script src="script.js"></script>');
    }

    const htmlKey = `index.html_${cleanHtml.substring(0, 50)}`;
    if (!this.processedFiles.has(htmlKey)) {
      this.processedFiles.add(htmlKey);
      this.generatedFiles.set('index.html', cleanHtml);
      this.onMessage({
        type: 'file',
        content: cleanHtml,
        filename: 'index.html',
        language: 'html'
      });
      console.log(`📁 HTML nettoyé créé: index.html`);
    }
  }

  private detectAndCreateFiles(content: string): void {
    // Séparer les explications du code
    const codeBlocks = content.match(/```[\s\S]*?```/g) || [];
    const htmlBlocks = content.match(/<!DOCTYPE[\s\S]*?<\/html>/gi) || [];
    
    // Si on a du code, le traiter séparément
    if (codeBlocks.length > 0 || htmlBlocks.length > 0) {
      const files = this.parseMultipleFiles(content);
      
      files.forEach(file => {
        if (!this.generatedFiles.has(file.filename)) {
          this.generatedFiles.set(file.filename, file.content);
          
          // Parser le nom de fichier pour séparer le chemin du nom
          const { fileName, filePath } = this.parseFilePath(file.filename);
          
          this.onMessage({
            type: 'file',
            content: file.content,
            filename: fileName,
            language: file.language
          });
        }
      });
      
      // Extraire les explications (tout ce qui n'est pas du code)
      let explanations = content;
      codeBlocks.forEach(block => {
        explanations = explanations.replace(block, '');
      });
      htmlBlocks.forEach(block => {
        explanations = explanations.replace(block, '');
      });
      
      // Envoyer les explications comme réponse de l'agent
      if (explanations.trim().length > 50) {
        this.onMessage({
          type: 'working',
          content: explanations.trim()
        });
      }
    }
  }

  private finalizeGhostwriterFiles(content: string): void {
    // Analyse finale pour s'assurer que tous les fichiers sont créés
    const files = this.parseMultipleFiles(content);
    
    if (files.length === 0 && content.includes('<!DOCTYPE html>')) {
      // Fichier HTML unique - le séparer automatiquement
      this.extractAndSeparateFiles(content);
    }
    
    // Marquer comme terminé avec délai pour garantir la réception
    setTimeout(() => {
      this.onMessage({
        type: 'complete',
        content: 'Code généré avec succès'
      });
    }, 100);
  }

  private extractAndSeparateFiles(htmlContent: string): void {
    // Extraire CSS inline
    const cssMatch = htmlContent.match(/<style[^>]*>([\s\S]*?)<\/style>/);
    if (cssMatch) {
      this.generatedFiles.set('styles.css', cssMatch[1].trim());
      this.onMessage({
        type: 'file',
        content: cssMatch[1].trim(),
        filename: 'styles.css',
        language: 'css'
      });
    }

    // Extraire JS inline
    const jsMatch = htmlContent.match(/<script[^>]*>([\s\S]*?)<\/script>/);
    if (jsMatch) {
      this.generatedFiles.set('script.js', jsMatch[1].trim());
      this.onMessage({
        type: 'file',
        content: jsMatch[1].trim(),
        filename: 'script.js',
        language: 'javascript'
      });
    }

    // HTML nettoyé
    let cleanHtml = htmlContent;
    if (cssMatch) {
      cleanHtml = cleanHtml.replace(/<style[^>]*>[\s\S]*?<\/style>/, '<link rel="stylesheet" href="styles.css">');
    }
    if (jsMatch) {
      cleanHtml = cleanHtml.replace(/<script[^>]*>[\s\S]*?<\/script>/, '<script src="script.js"></script>');
    }

    this.generatedFiles.set('index.html', cleanHtml);
    this.onMessage({
      type: 'file',
      content: cleanHtml,
      filename: 'index.html',
      language: 'html'
    });
  }



  private analyzeUserPrompt(prompt: string, language: string): { initialAnalysis: string, featuresIdentified: string, technicalApproach: string } {
    const lowerPrompt = prompt.toLowerCase();
    
    // Analyse intelligente multi-niveaux (recommandations ChatGPT)
    let initialAnalysis = "";
    let featuresIdentified = "";
    let technicalApproach = "";
    
    // Détection précise par contexte métier
    if (lowerPrompt.includes('météo') || lowerPrompt.includes('weather')) {
      if (lowerPrompt.includes('disparu') || lowerPrompt.includes('disparue') || lowerPrompt.includes('restaurer')) {
        initialAnalysis = `Votre page météo semble avoir été supprimée ou corrompue. Je vais reconstruire une application météo complète avec toutes les fonctionnalités essentielles.`;
        featuresIdentified = `Restauration complète : widget température, prévisions détaillées, géolocalisation automatique, recherche par ville, icônes animées.`;
        technicalApproach = `Reconstruction avec API météo fiable, interface responsive, stockage local des préférences utilisateur.`;
      } else {
        initialAnalysis = `Création d'une application météo moderne avec données en temps réel et interface intuitive.`;
        featuresIdentified = `Affichage température actuelle, prévisions 7 jours, géolocalisation, recherche ville, alertes météo, graphiques tendances.`;
        technicalApproach = `Intégration API OpenWeatherMap, geolocation HTML5, animations CSS3, stockage localStorage.`;
      }
    } else if (lowerPrompt.includes('boutique') || lowerPrompt.includes('shop') || lowerPrompt.includes('ecommerce') || lowerPrompt.includes('vente')) {
      initialAnalysis = `Développement d'une plateforme e-commerce complète avec gestion des produits et processus d'achat optimisé.`;
      featuresIdentified = `Catalogue produits filtrable, panier persistant, checkout sécurisé, gestion stock, système avis clients, dashboard admin.`;
      technicalApproach = `Architecture multi-pages, JavaScript pour interactions, CSS Grid/Flexbox, localStorage pour panier, formulaires validés.`;
    } else if (lowerPrompt.includes('rendez-vous') || lowerPrompt.includes('rdv') || lowerPrompt.includes('réservation') || lowerPrompt.includes('planning')) {
      initialAnalysis = `Système de gestion de rendez-vous avec fonctionnalités avancées de réservation et annulation.`;
      featuresIdentified = `Calendrier interactif, créneaux disponibles, gestion annulations, liste d'attente, notifications automatiques, historique.`;
      technicalApproach = `Interface calendrier dynamique, gestion état temps réel, validation côté client, persistance données locale.`;
    } else if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('cv') || lowerPrompt.includes('présentation')) {
      initialAnalysis = `Portfolio professionnel avec présentation élégante des compétences et réalisations.`;
      featuresIdentified = `Sections bio, compétences techniques, projets avec captures, expérience, contact, téléchargement CV.`;
      technicalApproach = `Design moderne responsive, animations fluides, optimisation mobile, navigation smooth scroll.`;
    } else if (lowerPrompt.includes('jeu') || lowerPrompt.includes('game') || lowerPrompt.includes('interactif')) {
      initialAnalysis = `Jeu web interactif avec mécaniques engageantes et système de progression.`;
      featuresIdentified = `Gameplay principal, système score, niveaux progression, contrôles intuitifs, effets visuels, sauvegarde.`;
      technicalApproach = `JavaScript orienté objet, Canvas ou CSS animations, gestion événements, requestAnimationFrame.`;
    } else if (lowerPrompt.includes('formulaire') || lowerPrompt.includes('contact') || lowerPrompt.includes('inscription')) {
      initialAnalysis = `Formulaire intelligent avec validation avancée et expérience utilisateur optimisée.`;
      featuresIdentified = `Validation temps réel, messages erreur contextuels, auto-complétion, protection spam, confirmation visuelle.`;
      technicalApproach = `HTML5 sémantique, validation JavaScript native, regex patterns, feedback utilisateur immédiat.`;
    } else if (lowerPrompt.includes('dashboard') || lowerPrompt.includes('admin') || lowerPrompt.includes('gestion')) {
      initialAnalysis = `Interface d'administration avec tableau de bord et outils de gestion avancés.`;
      featuresIdentified = `Métriques temps réel, graphiques interactifs, gestion utilisateurs, exports données, système permissions.`;
      technicalApproach = `Layout dashboard responsive, bibliothèques graphiques, tables dynamiques, filtres avancés.`;
    } else {
      // Analyse contextuelle basée sur le contenu exact du prompt
      const promptWords = prompt.split(' ');
      const keyTerms = promptWords.filter(word => word.length > 3).slice(0, 3).join(', ');
      
      initialAnalysis = `Analyse de votre demande "${prompt}" - Création d'une solution ${language} sur mesure.`;
      featuresIdentified = `Fonctionnalités adaptées aux termes clés identifiés : ${keyTerms}. Architecture modulaire et extensible.`;
      technicalApproach = `Implémentation ${language} avec meilleures pratiques modernes, code maintenable et performant.`;
    }
    
    return { initialAnalysis, featuresIdentified, technicalApproach };
  }

  async generateCodeWithStreaming(
    prompt: string,
    language: string,
    existingCode: string = "",
    context: string = "",
    agent: string = "replit"
  ) {
    
    // Mode Ghostwriter par défaut - streaming token par token comme Replit
    if (agent === "replit" || agent === "ghostwriter") {
      return this.generateWithGhostwriterMode(prompt, language, existingCode, context);
    }
    try {
      // Reset du texte accumulé au début de chaque génération (amélioration ChatGPT)
      this.resetAccumulatedText();
      
      // Analyse réelle de la demande utilisateur
      const realAnalysis = this.analyzeUserPrompt(prompt, language);
      
      // Étape 1: Analyse spécifique de la demande
      await this.sendTypingMessage('thinking', realAnalysis.initialAnalysis, 1);

      await this.delay(300);

      // Étape 2: Identification des fonctionnalités
      await this.sendTypingMessage('thinking', realAnalysis.featuresIdentified, 2);

      await this.delay(250);

      // Étape 3: Approche technique
      await this.sendTypingMessage('thinking', realAnalysis.technicalApproach, 3);

      await this.delay(200);

      // Déterminer le type de projet selon la demande
      let isMultiPageProject = false;
      let projectType = 'simple';
      
      if (prompt.toLowerCase().includes('boutique') || prompt.toLowerCase().includes('shop') || 
          prompt.toLowerCase().includes('plusieur') || prompt.toLowerCase().includes('multiple') ||
          prompt.toLowerCase().includes('pages') || prompt.toLowerCase().includes('site web')) {
        isMultiPageProject = true;
        projectType = 'multi-page';
      }

      // Cette étape a déjà été faite dans analyzeUserPrompt - pas de duplication

      await this.delay(200);

      // Message de travail spécifique
      await this.sendTypingMessage('working', `Je commence maintenant à développer la solution pour votre demande "${prompt}".`, 5);

      await this.delay(150);

      // Générer le code avec une approche analytique
      let systemPrompt = `Tu es un assistant IA intelligent et analytique. Tu dois créer du code ${language} qui répond précisément aux besoins exprimés dans la demande.

APPROCHE ANALYTIQUE REQUISE:
1. Comprends la demande dans son contexte métier
2. Identifie les fonctionnalités essentielles
3. Implémente une solution complète et fonctionnelle
4. Utilise les meilleures pratiques techniques

Crée du code qui résout le problème spécifique décrit, pas un template générique.`;

      if (isMultiPageProject) {
        systemPrompt += `

IMPORTANT - PROJET MULTI-PAGES DÉTECTÉ :
Tu dois créer une structure complète avec plusieurs fichiers séparés. Génère le code en utilisant cette structure EXACTE :

\`\`\`html
<!-- Contenu du fichier index.html avec navigation vers les autres pages -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ma Boutique</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <a href="index.html">Accueil</a>
        <a href="produits.html">Produits</a>
        <a href="contact.html">Contact</a>
        <a href="panier.html">Panier</a>
    </nav>
    <!-- Contenu de la page d'accueil -->
    <script src="script.js"></script>
</body>
</html>
\`\`\`

\`\`\`html
<!-- Contenu du fichier produits.html -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits - Ma Boutique</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <a href="index.html">Accueil</a>
        <a href="produits.html">Produits</a>
        <a href="contact.html">Contact</a>
        <a href="panier.html">Panier</a>
    </nav>
    <!-- Catalogue de produits -->
    <script src="script.js"></script>
</body>
</html>
\`\`\`

\`\`\`html
<!-- Contenu du fichier contact.html -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Contact - Ma Boutique</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <a href="index.html">Accueil</a>
        <a href="produits.html">Produits</a>
        <a href="contact.html">Contact</a>
        <a href="panier.html">Panier</a>
    </nav>
    <!-- Formulaire de contact -->
    <script src="script.js"></script>
</body>
</html>
\`\`\`

\`\`\`css
/* Styles CSS complets pour toutes les pages */
* { margin: 0; padding: 0; box-sizing: border-box; }
/* Styles de navigation, layout, produits, etc. */
\`\`\`

\`\`\`javascript
// JavaScript pour interactivité (panier, formulaires, etc.)
\`\`\`

Tu DOIS utiliser cette structure exacte avec les blocs de code séparés.`;
      } else {
        systemPrompt += `

Directives techniques :
- Génère du code complet et fonctionnel en ${language}
- Utilise les meilleures pratiques modernes pour ${language}
- Pour HTML, inclus toujours des styles CSS magnifiques et modernes avec des couleurs vives
- Pour JavaScript, utilise ES6+ et les patterns récents
- Pour Python, respecte les conventions PEP 8
- Crée des designs visuellement attractifs et interactifs
- Retourne UNIQUEMENT le code avec le commentaire d'introduction
- Ne wrappe pas le code dans des blocs markdown`;
      }

      systemPrompt += `

${context ? `Contexte supplémentaire : ${context}` : ''}`;

      let userPrompt = prompt;
      if (existingCode) {
        userPrompt += `\n\nCode existant à améliorer ou modifier :\n${existingCode}`;
      }

      // Étape finale: Génération du code avec frappe progressive
      await this.sendTypingMessage('working', `Génération du code en cours pour "${prompt}"...`, 6);

      const response = await xai.chat.completions.create({
        model: "grok-3-latest",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        max_tokens: 4000,
        temperature: 0.7,
        stream: true, // Activation du vrai streaming API
      });

      // Streaming token-par-token réel comme replit.com (recommandation ChatGPT #1)
      let fullGeneratedCode = '';
      let currentToken = '';
      
      try {
        for await (const chunk of response) {
          const deltaContent = chunk.choices?.[0]?.delta?.content;
          if (!deltaContent) continue;
          
          // Accumulation token par token (vrai streaming)
          fullGeneratedCode += deltaContent;
          currentToken += deltaContent;
          
          // Envoi immédiat de chaque token comme replit.com
          this.onMessage({
            type: 'code',
            content: fullGeneratedCode,
            step: 6
          });
          
          // Délai optimisé pour fluidité maximale (amélioration ChatGPT)
          await this.delay(4);
          
          // Reset du buffer token
          if (deltaContent.includes(' ') || deltaContent.includes('\n')) {
            currentToken = '';
          }
        }
      } catch (streamError) {
        console.log("Fallback vers génération non-streaming:", streamError);
        
        // Fallback robuste si streaming échoue
        const fallbackResponse = await xai.chat.completions.create({
          model: "grok-3-latest",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
          ],
          max_tokens: 4000,
          temperature: 0.7,
          stream: false,
        });
        
        if (fallbackResponse.choices?.[0]?.message?.content) {
          fullGeneratedCode = fallbackResponse.choices[0].message.content;
          
          // Simulation token par token en fallback
          for (let i = 0; i < fullGeneratedCode.length; i++) {
            this.onMessage({
              type: 'code',
              content: fullGeneratedCode.substring(0, i + 1),
              step: 6
            });
            await this.delay(12);
          }
        }
      }

      // Parse et envoie des fichiers séparés (recommandation ChatGPT #2)
      const parsedFiles = this.parseMultipleFiles(fullGeneratedCode);
      
      for (const file of parsedFiles) {
        // Stockage pour modification ultérieure (recommandation ChatGPT #3)
        this.generatedFiles.set(file.filename, file.content);
        
        // Envoi de chaque fichier séparément
        this.onMessage({
          type: 'file',
          content: file.content,
          filename: file.filename,
          language: file.language,
          step: 7
        });
        
        await this.delay(100);
      }

      // Message de finalisation
      await this.sendTypingMessage('complete', `Code généré avec ${parsedFiles.length} fichier(s). Prêt pour modification et prévisualisation.`);

      return {
        code: fullGeneratedCode.trim(),
        language: language,
        files: parsedFiles
      };

    } catch (error) {
      console.error("Erreur dans generateCodeWithStreaming:", error);
      this.onMessage({
        type: 'complete',
        content: `😅 Oups ! J'ai rencontré un petit problème technique. Pouvez-vous réessayer ? Je suis prêt à créer quelque chose d'incroyable pour vous !`,
        step: -1
      });
      throw error;
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Évaluation de la qualité en temps réel (amélioration ChatGPT)
  private evaluateResponseQuality(content: string, quality: any): void {
    quality.length = content.length;
    quality.hasCode = content.includes('```') || content.includes('<!DOCTYPE') || content.includes('function') || content.includes('class');
    quality.hasExplanation = content.length > 100 && !content.includes('```') || content.includes('voici') || content.includes('je vais');
  }

  // Détection de fichiers en temps réel (amélioration ChatGPT)
  private processTokenForFileDetection(delta: string, fullContent: string): void {
    // Détecter immédiatement les débuts de blocs de code
    if (delta.includes('```') && fullContent.includes('```')) {
      this.detectAndCreateFilesImmediately(fullContent);
    }
  }

  // Détection et création immédiate de fichiers (amélioration ChatGPT)
  private detectAndCreateFilesImmediately(content: string): void {
    const files = this.parseMultipleFiles(content);
    for (const file of files) {
      this.generatedFiles.set(file.filename, file.content);
    }
  }

  // Vérification de suffisance de réponse (amélioration ChatGPT)
  private isResponseSufficient(content: string, quality: any): boolean {
    if (content.length < 50) return false;
    if (!quality.hasCode && !quality.hasExplanation) return false;
    return true;
  }

  // Message de completion intelligent (amélioration ChatGPT)
  private generateCompletionMessage(content: string, quality: any): string {
    const fileCount = this.generatedFiles.size;
    if (fileCount > 1) {
      return `Code généré avec succès ! ${fileCount} fichiers créés. Prêt pour la prévisualisation.`;
    } else if (quality.hasCode) {
      return `Code généré avec succès ! Solution complète prête à utiliser.`;
    } else {
      return `Réponse générée. N'hésitez pas à demander du code si besoin.`;
    }
  }

  private accumulatedText = '';

  // Reset du texte accumulé (amélioration ChatGPT)
  public resetAccumulatedText(): void {
    this.accumulatedText = '';
  }

  // Streaming par token comme replit.com (version améliorée - ChatGPT)
  private async sendTypingMessage(type: 'thinking' | 'working' | 'code' | 'complete', content: string, step?: number) {
    // Gestion intelligente de l'accumulation
    if (type === 'thinking' && this.accumulatedText === '') {
      // Première étape de réflexion, reset complet
      this.accumulatedText = content;
    } else if (type === 'complete') {
      // Message de finalisation, pas d'accumulation
      this.accumulatedText = content;
    } else {
      // Accumulation normale pour les autres types
      this.accumulatedText += (this.accumulatedText ? '\n\n' : '') + content;
    }
    
    // Découpage par token/mot pour fluidité maximale (recommandation ChatGPT)
    const tokens = content.split(/(\s+)/);
    let currentText = this.accumulatedText.substring(0, this.accumulatedText.length - content.length);
    
    // Streaming token par token avec délais adaptatifs
    for (const token of tokens) {
      currentText += token;
      
      this.onMessage({
        type,
        content: currentText,
        step
      });
      
      // Délais adaptatifs optimisés pour la fluidité
      let delay = 8; // Délai de base très rapide
      
      if (token.trim() === '') {
        delay = 5; // Espaces ultra rapides
      } else if (token.length > 5) {
        delay = 15; // Mots longs un peu plus lents
      } else if (token.includes('.') || token.includes(',') || token.includes('!') || token.includes('?')) {
        delay = 30; // Pause après ponctuation
      }
      
      // Variabilité naturelle
      delay += Math.random() * 3;
      
      await this.delay(delay);
    }
    
    // Pause minimale entre messages
    await this.delay(50);
  }

  private analyzePromptIntelligently(prompt: string, language: string): { analysis: string, enhancedPrompt: string } {
    const lowerPrompt = prompt.toLowerCase();
    
    // Détecter les systèmes de rendez-vous
    const appointmentKeywords = ['rendez-vous', 'rdv', 'appointment', 'booking', 'réservation', 'créneau', 'planning', 'désistement', 'annulation', 'remplacement'];
    const isAppointmentSystem = appointmentKeywords.some(keyword => lowerPrompt.includes(keyword));
    
    if (isAppointmentSystem) {
      return {
        analysis: `D'après votre demande, je comprends que vous souhaitez créer un système de gestion de rendez-vous avec une fonctionnalité particulièrement intéressante : permettre à un client de prendre la place d'un autre qui se désiste. 

Cette approche nécessite plusieurs composants clés :
- Une interface pour visualiser les créneaux disponibles et ceux libérés par désistement
- Un système de gestion des clients et de leurs coordonnées
- Une logique de remplacement automatique ou manuelle
- Potentiellement un système de notifications

Je vais créer une solution complète qui intègre ces fonctionnalités de manière intuitive.`,
        enhancedPrompt: `${prompt}

SYSTÈME DE GESTION DE RENDEZ-VOUS AVEC REMPLACEMENT:
- Interface principale montrant les créneaux disponibles et annulés
- Formulaire de réservation pour nouveaux clients
- Système de liste d'attente pour les créneaux populaires  
- Gestion des annulations et attribution automatique des créneaux libérés
- Interface administrateur pour gérer les rendez-vous
- Stockage des informations clients et historique des rendez-vous`
      };
    }

    // Détecter les boutiques/e-commerce
    const ecommerceKeywords = ['boutique', 'shop', 'store', 'panier', 'cart', 'produit', 'achat'];
    const isEcommerce = ecommerceKeywords.some(keyword => lowerPrompt.includes(keyword));
    
    if (isEcommerce) {
      return {
        analysis: `Je vois que vous voulez créer une boutique en ligne. Je vais concevoir une interface e-commerce complète avec catalogue de produits, gestion du panier, et processus de commande optimisé pour l'expérience utilisateur.`,
        enhancedPrompt: `${prompt}

BOUTIQUE EN LIGNE COMPLÈTE:
- Catalogue de produits avec images et descriptions
- Système de panier d'achat avec calcul automatique
- Interface de recherche et filtrage
- Pages produit détaillées
- Processus de checkout simplifié`
      };
    }

    // Analyse générale
    return {
      analysis: `Je vais analyser votre demande pour créer une solution ${language} qui réponde précisément à vos besoins. Je m'assurerai que le code soit bien structuré et fonctionnel.`,
      enhancedPrompt: prompt
    };
  }
}