// Gestionnaire intelligent des fournisseurs IA avec fallback automatique
import { generateCodeWithXAI } from './xai';
import { generateCodeWithOpenAI, CodeGenerationResult } from './openai';

interface AIProvider {
  name: string;
  isAvailable: boolean;
  lastError?: string;
  lastCheck: Date;
  retryCount: number;
  maxRetries: number;
}

class AIProviderManager {
  private static instance: AIProviderManager;
  private providers: Map<string, AIProvider> = new Map();
  private preferredOrder = ['openai']; // OpenAI comme base fiable, xAI comme bonus quand disponible

  static getInstance(): AIProviderManager {
    if (!AIProviderManager.instance) {
      AIProviderManager.instance = new AIProviderManager();
    }
    return AIProviderManager.instance;
  }

  constructor() {
    this.initializeProviders();
  }

  private initializeProviders() {
    this.providers.set('xai', {
      name: 'xAI Grok',
      isAvailable: true,
      lastCheck: new Date(),
      retryCount: 0,
      maxRetries: 3
    });

    this.providers.set('openai', {
      name: 'OpenAI GPT',
      isAvailable: true,
      lastCheck: new Date(),
      retryCount: 0,
      maxRetries: 3
    });
  }

  private markProviderDown(providerId: string, error: string) {
    const provider = this.providers.get(providerId);
    if (provider) {
      provider.isAvailable = false;
      provider.lastError = error;
      provider.lastCheck = new Date();
      provider.retryCount += 1;

      console.log(`🔴 ${provider.name} marqué comme indisponible: ${error}`);
      
      // Réessayer après 5 minutes si pas trop d'échecs
      if (provider.retryCount <= provider.maxRetries) {
        setTimeout(() => {
          this.resetProvider(providerId);
        }, 5 * 60 * 1000); // 5 minutes
      }
    }
  }

  private resetProvider(providerId: string) {
    const provider = this.providers.get(providerId);
    if (provider) {
      provider.isAvailable = true;
      provider.lastError = undefined;
      provider.lastCheck = new Date();
      console.log(`🟢 ${provider.name} réactivé pour test`);
    }
  }

  private getAvailableProvider(): string | null {
    for (const providerId of this.preferredOrder) {
      const provider = this.providers.get(providerId);
      if (provider?.isAvailable) {
        return providerId;
      }
    }
    return null;
  }

  async generateCode(
    prompt: string,
    language: string = 'html',
    existingCode: string = '',
    context: string = ''
  ): Promise<{ code: string; provider: string; fallbackUsed: boolean }> {
    let fallbackUsed = false;

    for (const providerId of this.preferredOrder) {
      const provider = this.providers.get(providerId);
      
      if (!provider?.isAvailable) {
        console.log(`⏭️ ${provider?.name} ignoré (indisponible)`);
        continue;
      }

      try {
        console.log(`🔄 Tentative avec ${provider.name}...`);
        
        let result;
        if (providerId === 'xai') {
          const xaiResult = await generateCodeWithXAI(prompt, language, existingCode, context);
          result = typeof xaiResult === 'string' ? xaiResult : xaiResult.code;
        } else if (providerId === 'openai') {
          const openaiResult = await generateCodeWithOpenAI(prompt, language, existingCode);
          result = typeof openaiResult === 'string' ? openaiResult : openaiResult.code || openaiResult;
          fallbackUsed = providerId !== this.preferredOrder[0];
        }

        if (result) {
          console.log(`✅ Succès avec ${provider.name}`);
          // Réinitialiser le compteur d'erreurs en cas de succès
          provider.retryCount = 0;
          
          return {
            code: typeof result === 'string' ? result : result.code,
            provider: provider.name,
            fallbackUsed
          };
        }

      } catch (error: any) {
        console.error(`❌ ${provider.name} a échoué:`, error.message?.substring(0, 100));
        
        // Marquer comme indisponible si erreur serveur
        if (error.status === 500 || error.message?.includes('500')) {
          this.markProviderDown(providerId, 'Erreur serveur 500 (infrastructure)');
          fallbackUsed = true;
        } else if (error.status === 429) {
          this.markProviderDown(providerId, 'Quota dépassé');
          fallbackUsed = true;
        } else if (error.message?.includes('timeout')) {
          this.markProviderDown(providerId, 'Timeout réseau');
          fallbackUsed = true;
        }
        
        // Continuer avec le fournisseur suivant
        continue;
      }
    }

    throw new Error('Tous les fournisseurs IA sont indisponibles');
  }

  getStatus(): { [key: string]: AIProvider } {
    const status: { [key: string]: AIProvider } = {};
    this.providers.forEach((provider, id) => {
      status[id] = { ...provider };
    });
    return status;
  }

  getAvailableProviders(): string[] {
    return this.preferredOrder.filter(id => this.providers.get(id)?.isAvailable);
  }
}

export const aiProviderManager = AIProviderManager.getInstance();