import express from 'express';
import { Server } from 'http';
import path from 'path';
import fs from 'fs/promises';
import { spawn, ChildProcess } from 'child_process';
import { codeExecutor } from './code-executor';

interface PreviewServer {
  port: number;
  server: Server;
  process?: ChildProcess;
  projectId: number;
  language: string;
}

class PreviewServerManager {
  private servers: Map<number, PreviewServer> = new Map();
  private usedPorts: Set<number> = new Set();
  private basePort = 3001;

  private getAvailablePort(): number {
    while (this.usedPorts.has(this.basePort)) {
      this.basePort++;
    }
    this.usedPorts.add(this.basePort);
    return this.basePort++;
  }

  private async createProjectDirectory(projectId: number): Promise<string> {
    const projectDir = path.join(process.cwd(), 'preview-projects', projectId.toString());
    await fs.mkdir(projectDir, { recursive: true });
    return projectDir;
  }

  async startPreviewServer(projectId: number, files: any[], language: string): Promise<string> {
    // Arrêter le serveur existant s'il y en a un
    await this.stopPreviewServer(projectId);

    const port = this.getAvailablePort();
    const projectDir = await this.createProjectDirectory(projectId);

    // Écrire tous les fichiers dans le répertoire du projet
    for (const file of files) {
      const filePath = path.join(projectDir, file.name);
      
      // Nettoyer le contenu du fichier (supprimer les balises markdown si présentes)
      let cleanContent = file.content;
      
      // Supprimer les balises markdown ```html et ``` si présentes
      if (cleanContent.includes('```html')) {
        cleanContent = cleanContent.replace(/```html\s*\n?/, '').replace(/\n?```$/, '');
      } else if (cleanContent.includes('```')) {
        cleanContent = cleanContent.replace(/```[a-z]*\s*\n?/, '').replace(/\n?```$/, '');
      }
      
      await fs.writeFile(filePath, cleanContent.trim(), 'utf8');
    }

    // Créer le serveur Express pour ce projet
    const app = express();

    // Configuration selon le langage
    if (language === 'html' || language === 'javascript' || language === 'css') {
      // Serveur statique pour HTML/CSS/JS
      app.use(express.static(projectDir));
      
      // Route par défaut pour servir index.html
      app.get('*', async (req, res) => {
        try {
          const indexPath = path.join(projectDir, 'index.html');
          const indexExists = await fs.access(indexPath).then(() => true).catch(() => false);
          
          if (indexExists) {
            res.sendFile(indexPath);
          } else {
            // Chercher le premier fichier HTML
            const files = await fs.readdir(projectDir);
            const htmlFile = files.find(f => f.endsWith('.html'));
            
            if (htmlFile) {
              res.sendFile(path.join(projectDir, htmlFile));
            } else {
              res.status(404).send('Aucun fichier HTML trouvé');
            }
          }
        } catch (error) {
          res.status(500).send('Erreur du serveur');
        }
      });
    } else if (language === 'python') {
      // Pour Python, lancer un serveur Python
      const pythonFiles = files.filter(f => f.name.endsWith('.py'));
      if (pythonFiles.length > 0) {
        const mainFile = pythonFiles.find(f => f.name === 'app.py' || f.name === 'main.py') || pythonFiles[0];
        
        // Tenter de lancer le serveur Python
        const pythonProcess = spawn('python3', [mainFile.name], {
          cwd: projectDir,
          stdio: ['pipe', 'pipe', 'pipe']
        });
        
        if (pythonProcess) {
          this.servers.get(projectId)!.process = pythonProcess;
        }
      }
      
      // Serveur proxy pour rediriger vers le serveur Python
      app.get('*', (req, res) => {
        res.send(`
          <html>
            <head><title>Python Application</title></head>
            <body>
              <h2>Application Python</h2>
              <p>Serveur Python en cours d'exécution...</p>
              <pre>Fichiers disponibles: ${files.map(f => f.name).join(', ')}</pre>
            </body>
          </html>
        `);
      });
    } else if (language === 'php') {
      // Pour PHP, serveur avec support PHP
      app.get('*', (req, res) => {
        res.send(`
          <html>
            <head><title>Application PHP</title></head>
            <body>
              <h2>Application PHP</h2>
              <p>Serveur PHP nécessaire pour l'exécution</p>
              <pre>Fichiers disponibles: ${files.map(f => f.name).join(', ')}</pre>
            </body>
          </html>
        `);
      });
    } else if (language === 'java') {
      // Pour Java
      app.get('*', (req, res) => {
        res.send(`
          <html>
            <head><title>Application Java</title></head>
            <body>
              <h2>Application Java</h2>
              <p>Compilation et exécution Java nécessaires</p>
              <pre>Fichiers disponibles: ${files.map(f => f.name).join(', ')}</pre>
            </body>
          </html>
        `);
      });
    } else if (language === 'json') {
      // Pour les fichiers JSON, affichage formaté
      app.get('*', async (req, res) => {
        const jsonFiles = files.filter(f => f.name.endsWith('.json'));
        if (jsonFiles.length > 0) {
          res.send(`
            <html>
              <head><title>Données JSON</title></head>
              <body>
                <h2>Fichiers JSON</h2>
                ${jsonFiles.map(f => `
                  <h3>${f.name}</h3>
                  <pre style="background: #f5f5f5; padding: 10px; border-radius: 5px;">${JSON.stringify(JSON.parse(f.content), null, 2)}</pre>
                `).join('')}
              </body>
            </html>
          `);
        } else {
          res.send('<html><body><h2>Aucun fichier JSON trouvé</h2></body></html>');
        }
      });
    } else {
      // Serveur générique - affichage du code source
      app.use(express.static(projectDir));
      app.get('*', (req, res) => {
        res.send(`
          <html>
            <head><title>Code ${language.toUpperCase()}</title></head>
            <body>
              <h2>Projet ${language.toUpperCase()}</h2>
              <p>Fichiers générés:</p>
              <ul>
                ${files.map(f => `<li><strong>${f.name}</strong> (${f.language})</li>`).join('')}
              </ul>
              <p>Preview direct non disponible pour ce type de projet.</p>
            </body>
          </html>
        `);
      });
    }

    // Démarrer le serveur
    const server = app.listen(port, '0.0.0.0', () => {
      console.log(`Preview server started for project ${projectId} on port ${port}`);
    });

    // Stocker les informations du serveur
    this.servers.set(projectId, {
      port,
      server,
      projectId,
      language
    });

    // Retourner l'URL du preview
    return `http://localhost:${port}`;
  }

  async updatePreviewFiles(projectId: number, files: any[]): Promise<void> {
    const serverInfo = this.servers.get(projectId);
    if (!serverInfo) {
      throw new Error(`Aucun serveur de preview trouvé pour le projet ${projectId}`);
    }

    const projectDir = path.join(process.cwd(), 'preview-projects', projectId.toString());

    // Nettoyer le répertoire existant
    try {
      await fs.rm(projectDir, { recursive: true, force: true });
    } catch (error) {
      // Ignorer si le répertoire n'existe pas
    }

    // Recréer le répertoire
    await fs.mkdir(projectDir, { recursive: true });

    // Écrire les nouveaux fichiers
    for (const file of files) {
      const filePath = path.join(projectDir, file.name);
      await fs.writeFile(filePath, file.content, 'utf8');
    }
  }

  async stopPreviewServer(projectId: number): Promise<void> {
    const serverInfo = this.servers.get(projectId);
    if (!serverInfo) {
      return;
    }

    // Fermer le serveur HTTP
    serverInfo.server.close();

    // Arrêter le processus s'il y en a un
    if (serverInfo.process) {
      serverInfo.process.kill('SIGTERM');
    }

    // Libérer le port
    this.usedPorts.delete(serverInfo.port);

    // Nettoyer le répertoire du projet
    const projectDir = path.join(process.cwd(), 'preview-projects', projectId.toString());
    try {
      await fs.rm(projectDir, { recursive: true, force: true });
    } catch (error) {
      console.warn(`Impossible de nettoyer le répertoire ${projectDir}:`, error);
    }

    // Supprimer de la map
    this.servers.delete(projectId);

    console.log(`Preview server stopped for project ${projectId}`);
  }

  getPreviewUrl(projectId: number): string | null {
    const serverInfo = this.servers.get(projectId);
    return serverInfo ? `http://localhost:${serverInfo.port}` : null;
  }

  async stopAllServers(): Promise<void> {
    const promises = Array.from(this.servers.keys()).map(projectId => 
      this.stopPreviewServer(projectId)
    );
    await Promise.all(promises);
  }
}

// Instance singleton
export const previewServerManager = new PreviewServerManager();

// Nettoyer les serveurs à la fermeture de l'application
process.on('SIGINT', async () => {
  console.log('Arrêt des serveurs de preview...');
  await previewServerManager.stopAllServers();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('Arrêt des serveurs de preview...');
  await previewServerManager.stopAllServers();
  process.exit(0);
});