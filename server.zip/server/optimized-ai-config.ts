// Configuration optimisée: OpenAI principal, xAI bonus
import { generateCodeWithOpenAI } from './openai';
import { xaiManager } from './xai-comprehensive-manager';

export class OptimizedAIConfig {
  private static instance: OptimizedAIConfig;
  
  static getInstance(): OptimizedAIConfig {
    if (!OptimizedAIConfig.instance) {
      OptimizedAIConfig.instance = new OptimizedAIConfig();
    }
    return OptimizedAIConfig.instance;
  }

  async generateCode(
    prompt: string,
    language: string = 'html',
    existingCode: string = ''
  ): Promise<{ code: string; provider: string; style?: string }> {
    
    // Vérifier si xAI est disponible comme bonus
    const xaiStatus = xaiManager.getStatus();
    
    if (xaiStatus.isHealthy && !xaiStatus.isInBackoffPeriod) {
      // Tenter xAI comme bonus pour le style Grok
      try {
        const xaiAttempt = await xaiManager.attemptGeneration(prompt, language, existingCode);
        
        if (xaiAttempt.success && xaiAttempt.stream) {
          console.log('🎯 Utilisation xAI (style Grok disponible)');
          
          let accumulatedContent = "";
          for await (const chunk of xaiAttempt.stream) {
            const delta = chunk.choices[0]?.delta?.content || "";
            if (delta) {
              accumulatedContent += delta;
            }
          }
          
          if (accumulatedContent.trim()) {
            return {
              code: accumulatedContent,
              provider: 'xAI Grok',
              style: 'personnalité'
            };
          }
        }
      } catch (error) {
        console.log('⚡ xAI indisponible, basculement sur OpenAI');
      }
    }

    // OpenAI comme moteur principal fiable
    console.log('🔧 Utilisation OpenAI (moteur principal)');
    
    const openaiPrompt = existingCode 
      ? `${prompt}\n\nCode existant:\n${existingCode}`
      : prompt;
      
    const result = await generateCodeWithOpenAI(openaiPrompt, language, existingCode);
    
    let code: string;
    if (typeof result === 'string') {
      code = result;
    } else if (result && typeof result === 'object' && 'code' in result) {
      code = String(result.code || "");
    } else {
      code = String(result || "");
    }

    return {
      code,
      provider: 'OpenAI GPT-4',
      style: 'fiable'
    };
  }

  getProviderStatus(): {
    primary: { name: string; status: string };
    bonus: { name: string; status: string; available: boolean };
  } {
    const xaiStatus = xaiManager.getStatus();
    
    return {
      primary: {
        name: 'OpenAI GPT-4',
        status: 'opérationnel'
      },
      bonus: {
        name: 'xAI Grok',
        status: xaiStatus.isHealthy ? 'disponible' : 'indisponible',
        available: xaiStatus.isHealthy && !xaiStatus.isInBackoffPeriod
      }
    };
  }
}

export const optimizedAI = OptimizedAIConfig.getInstance();