import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User } from "@shared/schema";
import MemoryStore from "memorystore";
import { log } from "./viteHelper";

const scryptAsync = promisify(scrypt);
const MemorySessionStore = MemoryStore(session);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  // Configuration de la session
  app.use(session({
    store: new MemorySessionStore({ checkPeriod: 86400000 }),
    secret: process.env.SESSION_SECRET || "super-secret-code-assistant-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    }
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  // Stratégie locale
  passport.use(new LocalStrategy({
    usernameField: "email",
    passwordField: "password"
  }, async (email, password, done) => {
    try {
      let user = null;
      if (email.includes("@")) {
        user = await storage.getUserByEmail(email);
      }
      if (!user) {
        user = await storage.getUserByUsername(email);
      }
      if (!user) {
        return done(null, false, { message: "Utilisateur non trouvé" });
      }

      const valid = await comparePasswords(password, user.password);
      if (!valid) {
        return done(null, false, { message: "Mot de passe incorrect" });
      }

      return done(null, user);
    } catch (error) {
      console.error("Erreur d'authentification:", error);
      return done(error);
    }
  }));

  passport.serializeUser((user: Express.User, done) => {
    done(null, (user as User).id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      console.error("❌ Erreur lors du chargement de l'utilisateur:", error);
      log("Erreur lors de la désérialisation: " + (error as Error).message);
      done(error);
    }
  });

  // ROUTES

  app.post("/api/register", async (req, res) => {
    try {
      const { email, username, password } = req.body;

      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Cet email est déjà utilisé" });
      }

      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Ce nom d'utilisateur est déjà pris" });
      }

      const hashedPassword = await hashPassword(password);
      const newUser = await storage.createUser({
        email,
        username,
        password: hashedPassword,
        role: "user"
      });

      req.login(newUser, err => {
        if (err) {
          log("Erreur de login post-inscription: " + err.message);
          return res.status(500).json({ message: "Connexion automatique échouée" });
        }

        const { password, ...userInfo } = newUser;
        res.status(201).json(userInfo);
      });

    } catch (error) {
      console.error("❌ Erreur complète lors de l'inscription:", error);
      log("Erreur lors de l'inscription: " + (error as Error).message);
      res.status(500).json({ message: "Erreur lors de l'inscription" });
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) {
        log("Erreur d'authentification: " + err.message);
        return res.status(500).json({ message: "Erreur d'authentification" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Identifiants incorrects" });
      }

      req.login(user, err => {
        if (err) {
          log("Erreur lors de la connexion: " + err.message);
          return res.status(500).json({ message: "Connexion échouée" });
        }

        const { password, ...userInfo } = user;
        res.status(200).json(userInfo);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res) => {
    req.logout(err => {
      if (err) {
        log("Erreur de déconnexion: " + err.message);
        return res.status(500).json({ message: "Erreur de déconnexion" });
      }
      res.status(200).json({ message: "Déconnexion réussie" });
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Non authentifié" });
    }

    const { password, ...userInfo } = req.user as User;
    res.status(200).json(userInfo);
  });
}

export function isAuthenticated(req: any, res: any, next: any) {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ message: "Non authentifié" });
}
