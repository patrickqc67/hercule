import { generateCodeWithXAI } from './xai';
import OpenAI from "openai";

// Initialisation conditionnelle XAI pour replit-agent
function initializeXAI(): OpenAI | null {
  if (process.env.XAI_API_KEY) {
    return new OpenAI({ 
      baseURL: "https://api.x.ai/v1", 
      apiKey: process.env.XAI_API_KEY,
      timeout: 20000,
      maxRetries: 2,
      defaultHeaders: {
        'User-Agent': 'CodePhantom/1.0',
        'Accept': 'application/json'
      }
    });
  }
  return null;
}
import { VisualEnhancer } from './visual-enhancer';

interface StreamingMessage {
  type: 'thinking' | 'working' | 'code' | 'complete' | 'file' | 'console' | 'error-analysis' | 'history' | 'status' | 'system-log';
  content: string;
  filename?: string;
  language?: string;
  step?: number;
  level?: 'log' | 'error' | 'warn' | 'info';
  timestamp?: string;
  action?: string;
  id?: string;
}

export class ReplitAgent {
  private onMessage: (message: StreamingMessage) => void;
  private generatedFiles: Map<string, string> = new Map();
  private processedFiles: Set<string> = new Set();
  private fileHistory: Array<{filename: string, content: string, timestamp: string, prompt: string}> = [];
  private consoleCapture: boolean = true;
  private tone: 'natural' | 'technical' | 'friendly' = 'natural';
  private designStyle: 'ultra-modern' | 'minimal' | 'luxury' | 'fun' | 'dark' | 'colorful' | 'glassmorphism' | 'neomorphism' = 'ultra-modern';
  private theme: any = null;
  private template: 'ecommerce' | 'portfolio' | 'blog' | 'landing' | 'dashboard' | 'app' | null = null;
  private autoGenerateImages: boolean = true;

  private getDesignSystemPrompt(): string {
    return `Tu es un EXPERT DESIGNER WEB & DÉVELOPPEUR CRÉATIF de niveau ÉLITE. Réponds TOUJOURS en français. 

🎨 MISSION : Créer du code VISUELLEMENT ÉPOUSTOUFLANT avec un design ultra-moderne, élégant et professionnel de niveau agence premium.

📋 DIRECTIVES DESIGN OBLIGATOIRES :
• Interface ultra-moderne avec animations fluides et micro-interactions sophistiquées
• Palette de couleurs harmonieuse (gradients complexes, ombres multicouches)
• Typography moderne et hiérarchie visuelle parfaite (Google Fonts premium)
• Spacing millimétré, alignements parfaits, compositions géométriques
• Responsive design mobile-first avec breakpoints optimisés
• Effets visuels avancés : glassmorphism, neumorphism, parallax, morphing
• Icons SVG vectoriels et illustrations custom intégrées
• Loading states et transitions cinématographiques

🚀 TECHNOLOGIES MODERNES OBLIGATOIRES :
• CSS Grid & Flexbox pour layouts architecturaux
• CSS Variables pour theming dynamique et modes sombre/clair
• Animations CSS keyframes et transform 3D immersives
• Box-shadows multicouches et backdrop-filter blur
• Clip-path et mask pour formes géométriques créatives
• Modern web fonts (Inter, Poppins, Outfit) avec fallbacks
• CSS Container Queries pour composants adaptatifs
• CSS Scroll-driven animations pour parallax natif

💎 NIVEAU DE QUALITÉ : Production-ready premium, digne d'un portfolio d'agence web internationale.

Fournis du code HTML complet avec CSS et JavaScript intégrés, prêt à déployer immédiatement. Ajoute des commentaires techniques détaillés en français expliquant tes choix design avancés.`;
  }

  public setAutoGenerateImages(enabled: boolean): void {
    this.autoGenerateImages = enabled;
  }

  public getDesignSettings(): { designStyle: string, autoGenerateImages: boolean, theme: any, template: string | null } {
    return {
      designStyle: this.designStyle,
      autoGenerateImages: this.autoGenerateImages,
      theme: this.theme,
      template: this.template
    };
  }

  constructor(onMessage: (message: StreamingMessage) => void) {
    this.onMessage = onMessage;
  }

  private analyzeUserPrompt(prompt: string, language: string): { 
    requestType: 'creation' | 'correction' | 'image-fix' | 'modification' | 'repair' | 'optimization',
    initialAnalysis: string, 
    featuresIdentified: string, 
    technicalApproach: string,
    contextualResponse: string
  } {
    const lowerPrompt = prompt.toLowerCase();
    
    // Détection intelligente du type de demande selon conseils ChatGPT
    let requestType: 'creation' | 'correction' | 'image-fix' | 'modification' | 'repair' | 'optimization' = 'creation';
    
    // Détection corrections d'images (conseil ChatGPT spécifique)
    if (lowerPrompt.includes('images ne correspondent pas') || 
        lowerPrompt.includes('image ne correspond pas') ||
        lowerPrompt.includes('troisième image') ||
        lowerPrompt.includes('image est brisée') ||
        lowerPrompt.includes('image cassée') ||
        lowerPrompt.includes('image manquante') ||
        lowerPrompt.includes('images sont cassées')) {
      requestType = 'image-fix';
    }
    // Détection corrections générales
    else if (lowerPrompt.includes('corriger') || lowerPrompt.includes('réparer') || 
             lowerPrompt.includes('ne marche pas') || lowerPrompt.includes('ne fonctionne pas') ||
             lowerPrompt.includes('bug') || lowerPrompt.includes('erreur') ||
             lowerPrompt.includes('problème') || lowerPrompt.includes('casser')) {
      requestType = 'correction';
    }
    // Détection modifications
    else if (lowerPrompt.includes('modifier') || lowerPrompt.includes('changer') || 
             lowerPrompt.includes('améliorer') || lowerPrompt.includes('ajouter') ||
             lowerPrompt.includes('mettre à jour') || lowerPrompt.includes('ajuster')) {
      requestType = 'modification';
    }
    
    let initialAnalysis = "";
    let featuresIdentified = "";
    let technicalApproach = "";
    let contextualResponse = "";
    
    // Réponses contextuelles selon type de demande
    if (requestType === 'image-fix') {
      contextualResponse = "Mode Correction d'Images Activé\n\nJ'ai détecté un problème avec les images de votre projet. Je vais analyser et corriger automatiquement les images défaillantes.";
      initialAnalysis = "Diagnostic et correction des problèmes d'affichage d'images dans votre projet web.";
      featuresIdentified = "Vérification des chemins d'images, optimisation du format, génération d'images de remplacement, correction des attributs alt.";
      technicalApproach = "Analyse des balises img, correction des attributs src et alt, injection d'images optimisées avec lazy loading.";
    } else if (requestType === 'correction') {
      contextualResponse = "Mode Réparation Activé\n\nJ'ai identifié des dysfonctionnements dans votre code. Je vais diagnostiquer et corriger les problèmes spécifiques.";
      initialAnalysis = "Diagnostic et résolution des erreurs techniques dans votre application web.";
      featuresIdentified = "Analyse du code existant, identification des bugs, correction des erreurs JavaScript et CSS, optimisation des performances.";
      technicalApproach = "Debug méthodique, refactoring du code défaillant, tests de validation, logging des erreurs.";
    } else if (requestType === 'modification') {
      contextualResponse = "Mode Amélioration Activé\n\nJe vais apporter les modifications demandées à votre projet existant tout en préservant les fonctionnalités actuelles.";
      initialAnalysis = "Amélioration et modification de votre application web selon vos nouvelles spécifications.";
      featuresIdentified = "Intégration des nouvelles fonctionnalités, optimisation de l'existant, mise à jour du design, amélioration UX.";
      technicalApproach = "Modification incrémentale, préservation de la compatibilité, tests d'intégration, documentation des changements.";
    } else {
      // Mode création - analyse contextuelle métier
      if (lowerPrompt.includes('météo') || lowerPrompt.includes('weather')) {
        contextualResponse = "Application Météo Détectée\n\nJe vais créer une application météo complète avec données en temps réel et interface moderne.";
        initialAnalysis = "Création d'une application météo moderne avec données en temps réel et interface intuitive.";
        featuresIdentified = "Affichage température actuelle, prévisions 7 jours, géolocalisation, recherche ville, alertes météo, graphiques tendances.";
        technicalApproach = "Intégration API météo, geolocation HTML5, animations CSS3, stockage localStorage, responsive design.";
      } else if (lowerPrompt.includes('boutique') || lowerPrompt.includes('shop') || lowerPrompt.includes('ecommerce') || lowerPrompt.includes('vente')) {
        contextualResponse = "Boutique E-commerce Détectée\n\nJe vais développer une plateforme e-commerce complète avec toutes les fonctionnalités modernes.";
        initialAnalysis = "Développement d'une plateforme e-commerce complète avec gestion des produits et processus d'achat optimisé.";
        featuresIdentified = "Catalogue produits filtrable, panier persistant, checkout sécurisé, gestion stock, système avis clients, dashboard admin.";
        technicalApproach = "Architecture multi-pages, JavaScript pour interactions, CSS Grid/Flexbox, localStorage pour panier, formulaires validés.";
      } else if (lowerPrompt.includes('rendez-vous') || lowerPrompt.includes('rdv') || lowerPrompt.includes('réservation') || lowerPrompt.includes('planning')) {
        contextualResponse = "Système de Rendez-vous Détecté\n\nJe vais créer un système complet de gestion de rendez-vous avec fonctionnalités avancées.";
        initialAnalysis = "Système de gestion de rendez-vous avec fonctionnalités avancées de réservation et annulation.";
        featuresIdentified = "Calendrier interactif, créneaux disponibles, gestion annulations, liste d'attente, notifications automatiques, historique.";
        technicalApproach = "Interface calendrier dynamique, gestion état temps réel, validation côté client, persistance données locale.";
      } else if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('cv') || lowerPrompt.includes('présentation')) {
        contextualResponse = "Portfolio Professionnel Détecté\n\nJe vais créer un portfolio moderne avec présentation élégante des compétences et réalisations.";
        initialAnalysis = "Portfolio professionnel avec présentation élégante des compétences et réalisations.";
        featuresIdentified = "Sections bio, compétences techniques, projets avec captures, expérience, contact, téléchargement CV.";
        technicalApproach = "Design moderne responsive, animations fluides, optimisation mobile, navigation smooth scroll.";
      } else {
        // Analyse contextuelle basée sur le contenu exact du prompt
        const promptWords = prompt.split(' ');
        const keyTerms = promptWords.filter(word => word.length > 3).slice(0, 3).join(', ');
        
        contextualResponse = `Nouvelle Application ${language.toUpperCase()} Détectée\n\nJe vais créer une application web moderne selon vos spécifications.`;
        initialAnalysis = `Analyse de votre demande "${prompt}" - Création d'une solution ${language} sur mesure.`;
        featuresIdentified = `Fonctionnalités adaptées aux termes clés identifiés : ${keyTerms}. Architecture modulaire et extensible.`;
        technicalApproach = `Implémentation ${language} avec meilleures pratiques modernes, code maintenable et performant.`;
      }
    }
    
    return { requestType, initialAnalysis, featuresIdentified, technicalApproach, contextualResponse };
  }

  // Messages d'action technique comme Replit
  private logSystemEvent(action: string, filename?: string) {
    this.onMessage({
      type: 'system-log',
      content: `✓ ${action}`,
      filename,
      timestamp: new Date().toISOString(),
      id: `msg-system-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });
  }

  // Messages de statut avec icônes
  private emitStatus(content: string) {
    this.onMessage({
      type: 'status',
      content: `✓ ${content}`,
      timestamp: new Date().toISOString(),
      id: `msg-status-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });
  }

  private async sendTypingMessage(type: 'thinking' | 'working' | 'code' | 'complete', content: string, step?: number) {
    // Correction: ID unique et type correct pour chaque message
    const uniqueId = `msg-${type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Formater le contenu avec retours à la ligne appropriés (conseil ChatGPT)
    const formattedContent = content.replace(/\. /g, '.\n\n').replace(/\: /g, ':\n');
    
    this.onMessage({
      type: type, // Correction: utiliser le type exact au lieu de forcer 'working'
      content: formattedContent,
      step,
      timestamp: new Date().toISOString(),
      id: uniqueId
    });
    
    await this.delay(100);
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Analyse d'introspection du code pour détecter les erreurs (conseil ChatGPT)
  private analyzeCodeForErrors(code: string, prompt: string): string | null {
    const lowerPrompt = prompt.toLowerCase();
    
    // Détection spécifique pour les problèmes de boutons
    if (lowerPrompt.includes('bouton') || lowerPrompt.includes('button') || lowerPrompt.includes('caisse')) {
      if (code.includes('<button') && !code.includes('onclick') && !code.includes('addEventListener')) {
        return "Je vois le problème : le bouton est présent mais il n'a pas d'événement JavaScript associé. Il ne peut donc pas réagir aux clics.";
      }
      if (code.includes('onclick') && !code.includes('function')) {
        return "Le bouton a un onclick, mais la fonction appelée n'est pas définie dans le code.";
      }
    }
    
    // Détection pour les problèmes de formulaires
    if (lowerPrompt.includes('formulaire') || lowerPrompt.includes('form') || lowerPrompt.includes('submit')) {
      if (code.includes('<form') && !code.includes('onsubmit') && !code.includes('preventDefault')) {
        return "Le formulaire va recharger la page car il n'y a pas de gestion JavaScript pour empêcher le comportement par défaut.";
      }
    }
    
    // Détection pour les problèmes CSS
    if (lowerPrompt.includes('style') || lowerPrompt.includes('apparence') || lowerPrompt.includes('design')) {
      if (!code.includes('<style>') && !code.includes('class=')) {
        return "Aucun style CSS détecté. Les éléments vont apparaître avec le style par défaut du navigateur.";
      }
    }
    
    // Détection générale pour les erreurs JavaScript
    if (code.includes('document.getElementById') && !code.includes('DOMContentLoaded')) {
      return "Le code JavaScript accède aux éléments DOM mais ne vérifie pas si la page est chargée. Cela peut causer des erreurs.";
    }
    
    return null;
  }

  // Analyse automatique des erreurs dans le code généré (conseil ChatGPT nouveau)
  private analyzeGeneratedCodeForErrors(code: string): string[] {
    const errors: string[] = [];
    
    // Détection de boutons sans gestionnaires
    if (code.includes('<button') && !code.includes('onclick') && !code.includes('addEventListener')) {
      errors.push("Bouton détecté sans gestionnaire de clic - ne réagira pas aux interactions");
    }
    
    // Détection de fonctions appelées mais non définies
    const onclickMatches = code.match(/onclick="([^"]+)"/g);
    if (onclickMatches) {
      onclickMatches.forEach(match => {
        const funcName = match.match(/onclick="([^(]+)/)?.[1];
        if (funcName && !code.includes(`function ${funcName}`) && !code.includes(`const ${funcName}`)) {
          errors.push(`Fonction "${funcName}" appelée mais non définie`);
        }
      });
    }
    
    // Détection de getElementById sans vérification de chargement
    if (code.includes('document.getElementById') && !code.includes('DOMContentLoaded') && !code.includes('window.onload')) {
      errors.push("Accès au DOM sans attendre le chargement de la page");
    }
    
    // Détection de formulaires sans gestion
    if (code.includes('<form') && !code.includes('onsubmit') && !code.includes('preventDefault')) {
      errors.push("Formulaire sans gestion de soumission - rechargera la page");
    }
    
    return errors;
  }

  // Console interactive comme Replit.com (conseil ChatGPT nouveau)
  private injectConsoleCapture(htmlCode: string): string {
    if (!this.consoleCapture || !htmlCode.includes('<script>')) {
      return htmlCode;
    }
    
    const consoleScript = `
<script>
// Capture console pour interface comme Replit.com
(function() {
  const originalLog = console.log;
  const originalError = console.error;
  const originalWarn = console.warn;
  
  console.log = function(...args) {
    originalLog.apply(console, args);
    window.parent.postMessage({
      type: 'console',
      level: 'log',
      content: args.join(' '),
      timestamp: new Date().toISOString()
    }, '*');
  };
  
  console.error = function(...args) {
    originalError.apply(console, args);
    window.parent.postMessage({
      type: 'console',
      level: 'error',
      content: args.join(' '),
      timestamp: new Date().toISOString()
    }, '*');
  };
  
  console.warn = function(...args) {
    originalWarn.apply(console, args);
    window.parent.postMessage({
      type: 'console',
      level: 'warn',
      content: args.join(' '),
      timestamp: new Date().toISOString()
    }, '*');
  };
  
  // Capture des erreurs JavaScript
  window.addEventListener('error', function(e) {
    window.parent.postMessage({
      type: 'console',
      level: 'error',
      content: \`Erreur: \${e.message} à la ligne \${e.lineno}\`,
      timestamp: new Date().toISOString()
    }, '*');
  });
})();
</script>`;
    
    return htmlCode.replace('</head>', `${consoleScript}</head>`);
  }

  // Capture dynamique des erreurs JS de l'iframe (recommandation ChatGPT finale)
  private setupDynamicErrorCapture(htmlCode: string): void {
    // Envoyer un message de console setup pour l'interface
    this.onMessage({
      type: 'console',
      content: 'Console interactive activée - Les logs JavaScript apparaîtront ici',
      level: 'info',
      timestamp: new Date().toISOString(),
      id: `msg-console-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });

    // Analyser le code pour des erreurs potentielles et les signaler proactivement
    const potentialErrors = this.analyzeGeneratedCodeForErrors(htmlCode);
    if (potentialErrors.length > 0) {
      potentialErrors.forEach(error => {
        this.onMessage({
          type: 'console',
          content: `⚠️ Attention: ${error}`,
          level: 'warn',
          timestamp: new Date().toISOString(),
          id: `msg-warn-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        });
      });
    }
  }

  // Génération ciblée sur un seul fichier (conseil ChatGPT nouveau)
  public async generateSingleFile(filename: string, prompt: string, existingCode?: string): Promise<string> {
    try {
      await this.sendTypingMessage('thinking', `Je vais améliorer uniquement le fichier ${filename} selon votre demande.`, 1);
      
      const systemPrompt = `Tu es un développeur expert qui modifie précisément un fichier selon une demande.
Tu ne génères QUE le contenu du fichier demandé, rien d'autre.
Évite les explications, fournis directement le code amélioré.`;

      const userPrompt = `Améliore ce fichier: ${filename}
Demande: ${prompt}
${existingCode ? `\nCode actuel:\n${existingCode}` : ''}

Fournis UNIQUEMENT le contenu du fichier ${filename} amélioré.`;

      const xaiClient = initializeXAI();
      if (!xaiClient) {
        throw new Error("XAI API key not configured");
      }
      
      const stream = await xaiClient.chat.completions.create({
        model: "grok-2-1212",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        stream: true,
        temperature: 0.7,
        max_tokens: 1500
      });

      let accumulatedContent = "";
      
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        if (delta) {
          accumulatedContent += delta;
          
          this.onMessage({
            type: 'code',
            content: accumulatedContent
          });
          
          await this.delay(8);
        }
      }

      // Sauvegarder dans l'historique
      this.saveToHistory(filename, accumulatedContent, prompt);
      
      // Analyser les erreurs du fichier généré
      const errors = this.analyzeGeneratedCodeForErrors(accumulatedContent);
      if (errors.length > 0) {
        this.onMessage({
          type: 'error-analysis',
          content: `Attention: ${errors.join(', ')}`
        });
      }

      this.onMessage({
        type: 'complete',
        content: `Fichier ${filename} mis à jour avec succès!`
      });

      return accumulatedContent;

    } catch (error) {
      console.error('Erreur génération fichier unique:', error);
      
      try {
        const { generateCodeWithOpenAI } = await import('./openai');
        const fallbackResult = await generateCodeWithOpenAI(prompt, 'html', existingCode || '');
        
        let fallbackContent: string;
        if (typeof fallbackResult === 'string') {
          fallbackContent = fallbackResult;
        } else if (fallbackResult && typeof fallbackResult === 'object' && 'code' in fallbackResult) {
          fallbackContent = String(fallbackResult.code || "");
        } else {
          fallbackContent = String(fallbackResult || "");
        }
        
        this.saveToHistory(filename, fallbackContent, prompt);
        return fallbackContent;
      } catch (fallbackError) {
        throw new Error(`Impossible de générer le fichier ${filename}: ${fallbackError}`);
      }
    }
  }

  // Historique des versions (conseil ChatGPT nouveau)
  private saveToHistory(filename: string, content: string, prompt: string): void {
    this.fileHistory.push({
      filename,
      content,
      timestamp: new Date().toISOString(),
      prompt
    });
    
    // Limiter l'historique à 10 versions par fichier
    const fileVersions = this.fileHistory.filter(h => h.filename === filename);
    if (fileVersions.length > 10) {
      const toRemove = fileVersions.slice(0, fileVersions.length - 10);
      toRemove.forEach(version => {
        const index = this.fileHistory.indexOf(version);
        if (index > -1) this.fileHistory.splice(index, 1);
      });
    }
  }

  public getFileHistory(filename?: string): Array<{filename: string, content: string, timestamp: string, prompt: string}> {
    if (filename) {
      return this.fileHistory.filter(h => h.filename === filename);
    }
    return this.fileHistory;
  }

  public restoreFromHistory(filename: string, timestamp: string): string | null {
    const version = this.fileHistory.find(h => h.filename === filename && h.timestamp === timestamp);
    if (version) {
      this.generatedFiles.set(filename, version.content);
      this.onMessage({
        type: 'history',
        content: `Version de ${filename} restaurée depuis ${new Date(timestamp).toLocaleString()}`,
        id: `msg-history-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
      return version.content;
    }
    return null;
  }

  // Méthode publique pour analyser les erreurs (recommandation ChatGPT finale)
  public analyzeCodeErrors(code: string): string[] {
    return this.analyzeGeneratedCodeForErrors(code);
  }

  // Méthode publique pour envoyer des messages console (recommandation ChatGPT finale)
  public sendConsoleMessage(content: string, level: 'log' | 'error' | 'warn' | 'info' = 'log'): void {
    this.onMessage({
      type: 'console',
      content,
      level,
      timestamp: new Date().toISOString(),
      id: `msg-console-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });
  }

  // Personnalisation du ton (suggestion ChatGPT finale)
  public setTone(tone: 'natural' | 'technical' | 'friendly'): void {
    this.tone = tone;
  }

  public setDesignStyle(style: 'ultra-modern' | 'minimal' | 'luxury' | 'fun' | 'dark' | 'colorful' | 'glassmorphism' | 'neomorphism'): void {
    this.designStyle = style;
  }

  public setTheme(theme: { primary?: string; accent?: string; font?: string; background?: string }): void {
    this.theme = theme;
  }

  public setTemplate(template: 'ecommerce' | 'portfolio' | 'blog' | 'landing' | 'dashboard' | 'app'): void {
    this.template = template;
  }

  private getSecondaryDesignSystemPrompt(): string {
    let basePrompt = `Tu es un EXPERT DESIGNER UX/UI hyper-performant spécialisé dans les interfaces modernes 2024-2025.

🎯 MISSION : Créer des interfaces exceptionnelles qui rivalisent avec les meilleures applications du marché.

✨ STANDARDS DE QUALITÉ ÉLEVÉS :
- Design System cohérent avec composants réutilisables
- Hiérarchie visuelle parfaite (contraste, espacement, taille)
- Micro-interactions engageantes et purposeful
- Performance optimale (Core Web Vitals)
- Accessibilité WCAG 2.1 AA native
- Responsive design mobile-first intelligent

🎨 EXCELLENCE VISUELLE :
- Palette de couleurs harmonieuse avec variations automatiques
- Typographie expressive et hiérarchisée
- Espacement rythmé (échelle 8pt/4pt)
- Animations fluides avec easing naturel
- Ombres et profondeur subtiles mais impactantes
- États interactifs sophistiqués (hover, focus, active, disabled)

📱 COMPOSANTS INTELLIGENTS :
- Navigation adaptive avec états actifs
- Formulaires avec validation temps réel et feedback visuel
- Boutons avec loading states et success animations
- Cards avec hover elevations et reveal animations
- Modales avec backdrop blur et animations d'entrée/sortie
- Toast notifications avec auto-dismiss et actions
- Progress indicators contextuels
- Empty states avec illustrations et calls-to-action

🚀 TECHNOLOGIES MODERNES :
- CSS Grid/Flexbox avancé pour layouts complexes
- Custom Properties pour thématisation dynamique
- Animations CSS natives avec @keyframes
- JavaScript ES6+ pour interactions
- Observer APIs pour performance (Intersection, Resize)
- Touch gestures pour mobile

⚠️ OUTPUT : Code HTML complet avec CSS et JS intégrés, prêt à utiliser. Structure complète <!DOCTYPE html> avec <style> et <script> optimisés.`;

    // Ajout du thème personnalisé si défini
    if (this.theme) {
      basePrompt += `

🎨 Thème personnalisé :
- Couleur principale: ${this.theme.primary || '#4F46E5'}
- Couleur d'accent: ${this.theme.accent || '#F59E0B'}
- Police: ${this.theme.font || 'Inter, sans-serif'}
- Arrière-plan: ${this.theme.background || 'selon le style'}`;
    }

    // Ajout du template structurel si défini
    if (this.template) {
      basePrompt += this.getTemplateInstructions();
    }

    // Ajout du style spécifique selon la préférence
    switch (this.designStyle) {
      case 'ultra-modern':
        basePrompt += `

🎨 Style ULTRA-MODERNE (2024-2025) :
- Gradients dynamiques multi-couches avec mesh backgrounds
- Glassmorphism avancé (backdrop-filter: blur + saturate)
- Neumorphism subtil pour éléments interactifs
- Animations fluides avec spring physics
- Typographie variable (Inter, SF Pro, custom weights)
- Couleurs vibrantes avec mode sombre natif
- Micro-interactions context-aware
- Shadows complexes avec multiple layers
- Border radius organiques et variables
- États hover avec transformations 3D subtiles`;
        break;

      case 'minimal':
        basePrompt += `

🎨 Style demandé : MINIMALISTE
- Palette monochrome ou couleurs neutres
- Beaucoup d'espace blanc
- Typographie épurée
- Lignes fines et éléments subtils
- Pas d'animations excessives
- Focus sur la clarté et la simplicité`;
        break;

      case 'luxury':
        basePrompt += `

🎨 Style demandé : LUXUEUX
- Couleurs sombres avec accents dorés/argentés
- Typographie élégante et sophistiquée
- Textures riches et matériaux premium
- Animations fluides et raffinées
- Espacement généreux
- Détails soignés et finitions haut de gamme`;
        break;

      case 'fun':
        basePrompt += `

🎨 Style demandé : AMUSANT
- Couleurs vives et contrastées
- Animations ludiques et rebondissantes
- Formes organiques et asymétriques
- Éléments interactifs surprenants
- Typographie expressive
- Micro-interactions amusantes`;
        break;

      case 'dark':
        basePrompt += `

🎨 Style demandé : DARK MODE
- Fond noir/gris très sombre
- Texte blanc/gris clair
- Accents colorés lumineux (néon)
- Contrastes élevés
- Effets de lumière subtils
- Interface nocturne élégante`;
        break;

      case 'colorful':
        basePrompt += `

🎨 Style demandé : COLORÉ
- Palette riche et variée
- Gradients multicolores
- Sections aux couleurs distinctes
- Harmonie chromatique équilibrée
- Éléments vibrants mais lisibles
- Jeu de couleurs créatif`;
        break;

      case 'glassmorphism':
        basePrompt += `

🎨 Style demandé : GLASSMORPHISME
- Effets de verre translucide (backdrop-filter)
- Bordures subtiles et floues
- Superposition d'éléments semi-transparents
- Arrière-plans avec blur
- Reflets et réfractions
- Esthétique moderne et aérée`;
        break;

      case 'neomorphism':
        basePrompt += `

🎨 Style demandé : NÉOMORPHISME
- Ombres internes et externes douces
- Éléments qui semblent extrudés
- Couleurs neutres et douces
- Effets de relief subtils
- Boutons et cartes en relief
- Esthétique tactile et moderne`;
        break;
    }

    return basePrompt;
  }

  private getTemplateInstructions(): string {
    switch (this.template) {
      case 'ecommerce':
        return `

📋 Template E-COMMERCE :
- Header avec logo, navigation, panier
- Section hero avec produit vedette
- Grille de produits avec images, prix, boutons
- Section témoignages/avis clients
- Footer avec liens et infos légales
- Fonctionnalités : ajout panier, filtres, recherche`;

      case 'portfolio':
        return `

📋 Template PORTFOLIO :
- Header avec nom et navigation
- Section hero avec photo et présentation
- Section projets en grille/carousel
- Section compétences/services
- Section contact avec formulaire
- Design créatif et personnel`;

      case 'blog':
        return `

📋 Template BLOG :
- Header avec titre du blog et navigation
- Section articles en liste/grille
- Sidebar avec catégories et recherche
- Section article individuel avec commentaires
- Pagination et tags
- Design axé lecture et contenu`;

      case 'landing':
        return `

📋 Template LANDING PAGE :
- Section hero impactante avec CTA
- Section avantages/features (3-4 points)
- Section témoignages/preuves sociales
- Section pricing/offres
- CTA final et formulaire capture
- Design conversion-optimisé`;

      case 'dashboard':
        return `

📋 Template DASHBOARD :
- Sidebar de navigation avec icônes
- Header avec user profile et notifications
- Grille de widgets/cartes statistiques
- Tableaux de données et graphiques
- Interface admin/gestion
- Design fonctionnel et organisé`;

      case 'app':
        return `

📋 Template APPLICATION :
- Interface utilisateur intuitive
- Navigation principale claire
- Zones de contenu modulaires
- Interactions et états (loading, hover)
- Responsive mobile-first
- UX moderne et fluide`;

      default:
        return '';
    }
  }

  private getMessageWithTone(baseMessage: string, messageType: 'thinking' | 'working' | 'complete'): string {
    switch (this.tone) {
      case 'friendly':
        const friendlyPrefixes = {
          thinking: ['Je réfléchis à votre demande...', 'Analysons ça ensemble...', 'Voyons voir...'],
          working: ['Je code ça pour vous!', 'En train de créer quelque chose de sympa...', 'Magie en cours...'],
          complete: ['Et voilà! C\'est terminé.', 'Mission accomplie!', 'Parfait, tout est prêt!']
        };
        return friendlyPrefixes[messageType][Math.floor(Math.random() * friendlyPrefixes[messageType].length)] + ' ' + baseMessage;
      
      case 'technical':
        const technicalPrefixes = {
          thinking: ['Analyse du prompt:', 'Traitement de la requête:', 'Évaluation technique:'],
          working: ['Génération en cours:', 'Compilation du code:', 'Exécution de l\'algorithme:'],
          complete: ['Processus terminé.', 'Génération finalisée.', 'Output disponible.']
        };
        return technicalPrefixes[messageType][Math.floor(Math.random() * technicalPrefixes[messageType].length)] + ' ' + baseMessage;
      
      case 'natural':
      default:
        return baseMessage;
    }
  }

  private detectAndCreateFiles(content: string): void {
    // Détecter les blocs de code complets et les créer immédiatement
    const codePattern = /```(\w+)?\n([\s\S]*?)```/g;
    let match;
    
    while ((match = codePattern.exec(content)) !== null) {
      const language = match[1] || 'text';
      const codeContent = match[2].trim();
      
      if (codeContent.length > 20) {
        const filename = this.getSmartFilename(language, codeContent);
        
        this.generatedFiles.set(filename, codeContent);
        
        this.onMessage({
          type: 'file',
          content: codeContent,
          filename: filename,
          language: language
        });
      }
    }
    
    // Détecter les fichiers HTML complets
    if (content.includes('<!DOCTYPE html') && content.includes('</html>')) {
      const htmlMatch = content.match(/(<!DOCTYPE[\s\S]*?<\/html>)/);
      if (htmlMatch) {
        this.generatedFiles.set('index.html', htmlMatch[1]);
        
        this.onMessage({
          type: 'file',
          content: htmlMatch[1],
          filename: 'index.html',
          language: 'html'
        });
      }
    }
  }

  private getSmartFilename(language: string, content: string): string {
    if (language === 'html' || content.includes('<!DOCTYPE')) {
      return 'index.html';
    } else if (language === 'css' || content.includes('body {') || content.includes('.')) {
      return 'styles.css';
    } else if (language === 'javascript' || language === 'js' || content.includes('function') || content.includes('=>')) {
      return 'script.js';
    } else if (language === 'python' || language === 'py') {
      return 'main.py';
    }
    
    return `file.${language || 'txt'}`;
  }

  // Fonction logGhostwriterWorkflow corrigée selon ChatGPT
  private logGhostwriterWorkflow({
    intent,
    filesEdited = [],
    steps = [],
    restartApp = false,
    screenshot = false,
    finalInstruction = "Relancez une génération pour tester."
  }: {
    intent: string,
    filesEdited?: string[],
    steps?: string[],
    restartApp?: boolean,
    screenshot?: boolean,
    finalInstruction?: string
  }) {
    const timestamp = new Date().toISOString();

    // 🧠 Bulle de réflexion
    this.onMessage({
      type: "thinking",
      content: intent,
      timestamp,
      id: `msg-thinking-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });

    // 🛠️ Étapes techniques
    for (const file of filesEdited) {
      this.onMessage({
        type: "system-log",
        content: `✓ Edited ${file}`,
        timestamp,
        id: `msg-system-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    for (const step of steps) {
      this.onMessage({
        type: "working",
        content: `✓ ${step}`,
        timestamp,
        id: `msg-working-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    if (restartApp) {
      this.onMessage({
        type: "system-log",
        content: "✓ Restarted application",
        timestamp,
        id: `msg-restart-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    if (screenshot) {
      this.onMessage({
        type: "system-log",
        content: "✓ Took a screenshot",
        timestamp,
        id: `msg-screenshot-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    // ✅ Résumé final
    const summaryLines = [
      "**✅ Changements appliqués**",
      ...filesEdited.map(f => `- ✏️ Fichier modifié : \`${f}\``),
      ...steps.map(s => `- 🔧 ${s}`),
      restartApp ? "- 🔄 Application redémarrée" : null,
      "",
      `🎯 ${finalInstruction}`
    ].filter(Boolean).join('\n');

    this.onMessage({
      type: "complete",
      content: summaryLines,
      timestamp,
      id: `msg-complete-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });
  }

  // Générateur d'actions simples (conservé pour compatibilité)
  private logGhostwriterAction(options: {
    fileEdited?: string;
    action: string;
    restartApp?: boolean;
    screenshot?: boolean;
    explanation?: string;
  }) {
    const timestamp = new Date().toISOString();
    const intent = options.explanation || options.action;
    const filesEdited = options.fileEdited ? [options.fileEdited] : [];
    const finalInstruction = `Relancez une génération pour tester les améliorations de ${options.action}.`;

    // Bulle de réflexion
    this.onMessage({
      type: "thinking",
      content: intent,
      timestamp,
      id: `msg-thinking-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });

    // Actions techniques
    for (const file of filesEdited) {
      this.onMessage({
        type: "system-log",
        content: `✓ Edited ${file}`,
        timestamp,
        id: `msg-system-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    if (options.restartApp) {
      this.onMessage({
        type: "system-log",
        content: "✓ Restarted application",
        timestamp,
        id: `msg-restart-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    if (options.screenshot) {
      this.onMessage({
        type: "system-log",
        content: "✓ Took a screenshot",
        timestamp,
        id: `msg-screenshot-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      });
    }

    // Résumé final
    const summaryLines = [
      "**✅ Changements appliqués**",
      ...filesEdited.map(f => `- ✏️ Fichier modifié : \`${f}\``),
      options.restartApp ? "- 🔄 Application redémarrée" : null,
      options.screenshot ? "- 📸 Capture d'écran prise" : null,
      "",
      `🎯 ${finalInstruction}`
    ].filter(Boolean).join('\n');

    this.onMessage({
      type: "complete",
      content: summaryLines,
      timestamp,
      id: `msg-complete-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    });
  }

  async generateCode(prompt: string, language: string = 'html', existingCode: string = '') {
    try {
      console.log("Analyse d'entrée:", { prompt, language, existingCode: existingCode.length });
      
      // Analyse intelligente selon les conseils ChatGPT
      const analysis = this.analyzeUserPrompt(prompt, language);
      console.log("Type de demande détecté:", analysis.requestType);
      
      // Réponse contextuelle immédiate selon le type de demande
      await this.sendTypingMessage('thinking', analysis.contextualResponse);
      await this.delay(800);
      
      // Étapes spécifiques selon le type de demande
      this.logSystemEvent("Analysis completed", `Type: ${analysis.requestType}`);
      
      if (analysis.requestType === 'image-fix') {
        await this.sendTypingMessage('working', "Diagnostic des images en cours...");
        await this.delay(400);
        await this.sendTypingMessage('working', "Correction et optimisation des images...");
      } else if (analysis.requestType === 'correction') {
        await this.sendTypingMessage('working', "Analyse des erreurs en cours...");
        await this.delay(400);
        await this.sendTypingMessage('working', "Application des corrections...");
      } else if (analysis.requestType === 'modification') {
        await this.sendTypingMessage('working', "Analyse des modifications demandées...");
        await this.delay(400);
        await this.sendTypingMessage('working', "Implémentation des améliorations...");
      } else {
        await this.sendTypingMessage('working', analysis.initialAnalysis);
        await this.delay(400);
        await this.sendTypingMessage('working', "Génération du code selon vos spécifications...");
      }
      
      this.logSystemEvent("Code generation started");

      let systemPrompt;
      let userPrompt;
      
      // Construction des prompts selon le type de demande détecté
      if (analysis.requestType === 'image-fix' && existingCode) {
        systemPrompt = `Tu es un expert en correction d'images web. Analyse le code existant et corrige spécifiquement les problèmes d'images.

RÈGLES DE CORRECTION D'IMAGES:
1. Identifie les URLs d'images cassées ou inadéquates
2. Remplace par des images réelles d'Unsplash appropriées au contexte
3. Assure-toi que les images correspondent exactement au thème du projet
4. Optimise les balises alt descriptives et les dimensions
5. Maintiens la cohérence visuelle du design
6. Retourne le code HTML complet avec toutes les corrections appliquées

Réponds UNIQUEMENT avec le code HTML complet corrigé, sans explications supplémentaires.`;

        userPrompt = `CORRECTION D'IMAGES DEMANDÉE: "${prompt}"

CODE EXISTANT À CORRIGER:
${existingCode}

Corrige toutes les images défaillantes en utilisant des images Unsplash pertinentes au thème du projet.`;

      } else if (analysis.requestType === 'correction' && existingCode) {
        // Analyse du code pour identification des erreurs (conseil ChatGPT)
        const codeAnalysis = this.analyzeCodeForErrors(existingCode, prompt);
        if (codeAnalysis) {
          await this.sendTypingMessage('thinking', `Problème identifié: ${codeAnalysis}`, 3);
          await this.delay(400);
        }
        
        systemPrompt = `Tu es un développeur expert spécialisé dans le debug et la correction de code. Ton approche est méthodique et pédagogique comme sur Replit.

PROCESSUS DE CORRECTION:
1. Identifie précisément les erreurs dans le code
2. Explique brièvement ce qui ne fonctionne pas
3. Applique les corrections nécessaires
4. Ajoute des commentaires sur les parties critiques
5. Teste mentalement la logique corrigée
6. Retourne le code complet fonctionnel

Style de réponse: Direct et utile, sans formules inutiles.`;

        userPrompt = `PROBLÈME À CORRIGER: "${prompt}"

CODE AVEC ERREURS:
${existingCode}

Identifie et corrige tous les problèmes. Fournis le code complet corrigé avec des explications concises.`;

      } else if (analysis.requestType === 'modification' && existingCode) {
        systemPrompt = `Tu es un développeur qui améliore et modifie le code existant selon des demandes spécifiques.

RÈGLES DE MODIFICATION:
1. Comprends exactement les modifications demandées
2. Préserve tout le code existant qui fonctionne
3. Apporte uniquement les changements nécessaires
4. Maintiens la cohérence du style et de l'architecture
5. Optimise les nouvelles fonctionnalités ajoutées
6. Documente les changements importants dans des commentaires

Retourne le code complet avec les modifications intégrées harmonieusement.`;

        userPrompt = `MODIFICATIONS DEMANDÉES: "${prompt}"

CODE EXISTANT:
${existingCode}

Applique les modifications demandées en préservant l'intégrité du code existant.`;

      } else {
        // Mode génération standard avec agent designer hyper performant + VisualEnhancer
        await this.sendTypingMessage('working', `🎨 Application du design ${this.designStyle} et génération d'images automatiques...`, 4);
        
        // Intégration complète VisualEnhancer selon conseils ChatGPT
        const visualEnhancement = await VisualEnhancer.enhanceDesign(prompt, this.designStyle, language);
        
        let generatedImages: string[] = [];
        if (this.autoGenerateImages && visualEnhancement.imagePrompts.length > 0) {
          await this.sendTypingMessage('working', `🖼️ Génération d'images contextuelles automatiques...`, 5);
          
          // Toujours utiliser des images réelles pour une meilleure expérience
          generatedImages = VisualEnhancer.getFallbackImages(prompt, 3);
          
          await this.sendTypingMessage('working', `Génération en cours...`, 6);
        }

        // Prompt système enrichi avec direction design
        systemPrompt = `${this.getDesignSystemPrompt()}

🎯 DIRECTION DESIGN SPÉCIFIQUE : ${visualEnhancement.designDirection}

🎨 PALETTE OBLIGATOIRE :
- Couleur principale: ${visualEnhancement.theme.primary}
- Couleur secondaire: ${visualEnhancement.theme.secondary}
- Couleur accent: ${visualEnhancement.theme.accent}
- Police: ${visualEnhancement.theme.font}

🖼️ IMAGES DISPONIBLES :
${generatedImages.length > 0 ? generatedImages.map((img, i) => `- Image ${i+1}: ${img}`).join('\n') : '- Utilise des images de placeholder stylées'}

💫 DIRECTIVES TECHNIQUES AVANCÉES :
- Intègre les variables CSS fournies pour cohérence
- Utilise les images générées dans les sections appropriées
- Applique des animations modernes et micro-interactions
- Assure-toi que le design soit responsive et accessible`;

        userPrompt = existingCode 
          ? `Modifie ce code selon la demande: ${prompt}\n\nCode existant:\n${existingCode}`
          : `Voici ce que je veux: ${prompt}`;
      }

      const xaiClient = initializeXAI();
      if (!xaiClient) {
        throw new Error("XAI API key not configured");
      }
      
      const stream = await xaiClient.chat.completions.create({
        model: "grok-2-1212",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        stream: true,
        temperature: 0.7,
        max_tokens: 2000 // Réduit pour éviter timeout (conseil ChatGPT)
      });

      let accumulatedContent = "";
      let lineCount = 0;
      let previewSent = false;
      
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        if (delta) {
          accumulatedContent += delta;
          
          // Preview immédiat des premières lignes (conseil ChatGPT critique)
          if (!previewSent && delta.includes('\n')) {
            lineCount++;
            if (lineCount >= 3) {
              this.onMessage({
                type: 'code',
                content: accumulatedContent
              });
              previewSent = true;
              await this.delay(50); // Pause pour captiver l'utilisateur
            }
          }
          
          // Streaming token-par-token réel comme replit.com (conseil ChatGPT)
          this.onMessage({
            type: 'code',
            content: accumulatedContent
          });
          
          // Délai minimal pour fluidité comme Replit (conseil ChatGPT)
          await this.delay(8);
          
          // Détection et création de fichiers en temps réel
          this.detectAndCreateFiles(accumulatedContent);
        }
      }

      // Vérification robuste de la réponse API selon conseils ChatGPT
      if (!accumulatedContent || accumulatedContent.trim().length === 0) {
        console.error("Réponse vide de l'API xAI");
        throw new Error("Réponse vide de l'API x.ai");
      }

      // Analyse automatique des erreurs après génération
      const generatedErrors = this.analyzeGeneratedCodeForErrors(accumulatedContent);
      if (generatedErrors.length > 0) {
        console.log("Erreurs détectées dans le code généré:", generatedErrors);
        this.onMessage({
          type: 'error-analysis',
          content: `Analyse: ${generatedErrors.join('; ')}`,
          id: `msg-error-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        });
      }

      // Application des améliorations visuelles automatiques
      let processedContent = accumulatedContent;
      
      if (this.autoGenerateImages) {
        try {
          const visualEnhancement = await VisualEnhancer.enhanceDesign(prompt, this.designStyle, language);
          const generatedImages = await VisualEnhancer.generateContextualImages(
            prompt, 
            visualEnhancement.imagePrompts, 
            2
          );
          
          // Injection automatique des améliorations visuelles
          processedContent = VisualEnhancer.injectVisualEnhancements(
            accumulatedContent,
            visualEnhancement,
            generatedImages
          );
          
          // CORRECTION: Injection du CSS dans le fichier styles.css selon conseil ChatGPT
          if (visualEnhancement.cssVariables) {
            this.generatedFiles.set("styles.css", visualEnhancement.cssVariables);
            this.onMessage({
              type: 'system-log',
              content: `📄 Fichier styles.css créé avec le design personnalisé`,
              level: 'info',
              timestamp: new Date().toISOString(),
              id: `msg-css-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            });
          }
          
          // Injection manuelle des images selon conseil ChatGPT exact
          if (generatedImages.length > 0) {
            const html = this.generatedFiles.get("index.html") || processedContent;
            
            // Injection directe dans <body> comme recommandé par ChatGPT
            const htmlWithImages = html.replace(
              "<body>",
              `<body>
<div style="text-align: center; margin: 20px 0;">
  <img src="${generatedImages[0]}" alt="image auto" style="max-width: 100%; display: block; margin: auto; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
</div>`
            );
            
            // Sauvegarder le HTML mis à jour
            this.generatedFiles.set("index.html", htmlWithImages);
            processedContent = htmlWithImages;
            
            this.onMessage({
              type: "system-log",
              content: `🖼️ Image visuelle ajoutée automatiquement pour enrichir le design.`,
              timestamp: new Date().toISOString(),
              id: `msg-image-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
            });
          }
          
          this.onMessage({
            type: 'system-log',
            content: `✨ Améliorations visuelles automatiques appliquées`,
            level: 'info',
            timestamp: new Date().toISOString(),
            id: `msg-visual-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
          });
        } catch (error) {
          console.error('Erreur améliorations visuelles:', error);
          processedContent = accumulatedContent;
        }
      }
      
      // Injection de la console interactive (conseil ChatGPT nouveau)
      processedContent = this.injectConsoleCapture(processedContent);
      
      // Capture dynamique des erreurs JS de l'iframe (recommandation ChatGPT finale)
      this.setupDynamicErrorCapture(processedContent);
      
      // Sauvegarder dans l'historique
      this.saveToHistory('index.html', processedContent, prompt);

      // Message de fin simple et propre
      await this.sendTypingMessage('complete', `✅ Génération terminée.`);

      return processedContent;

    } catch (error) {
      console.error('Erreur xAI Grok détaillée:', {
        message: error instanceof Error ? error.message : 'Erreur inconnue',
        stack: error instanceof Error ? error.stack : undefined,
        errorType: typeof error,
        fullError: error
      });
      
      // Basculer sur OpenAI comme moteur de production
      this.onMessage({
        type: 'thinking',
        content: 'Génération en cours...'
      });
      
      try {
        const { generateCodeWithOpenAI } = await import('./openai');
        
        const fallbackPrompt = existingCode 
          ? `${prompt}\n\nCode existant:\n${existingCode}`
          : prompt;
          
        const fallbackResult = await generateCodeWithOpenAI(fallbackPrompt, language, existingCode);
        
        let fallbackContent: string;
        if (typeof fallbackResult === 'string') {
          fallbackContent = fallbackResult;
        } else if (fallbackResult && typeof fallbackResult === 'object' && 'code' in fallbackResult) {
          fallbackContent = String(fallbackResult.code || "");
        } else {
          fallbackContent = String(fallbackResult || "");
        }
        
        // Streaming simulé pour le fallback
        this.onMessage({
          type: 'code',
          content: fallbackContent
        });
        
        // Détection et création de fichiers
        this.detectAndCreateFiles(fallbackContent);
        
        // Actions techniques finales pour le fallback
        this.logSystemEvent("Fallback generation completed");
        this.logSystemEvent("Code generated via OpenAI");
        
        // Résumé final pour le fallback
        const fallbackSummary = `### ✅ Génération terminée via OpenAI
- Code HTML généré avec succès
- Fichier sauvegardé dans le projet
- Fallback automatique appliqué

✅ Testez une nouvelle génération pour vérifier le comportement.`;

        await this.sendTypingMessage('complete', fallbackSummary);
        
        return fallbackContent;
        
      } catch (fallbackError) {
        console.error('Erreur fallback OpenAI:', fallbackError);
        
        const errorSummary = `### ❌ Erreur de génération
- xAI et OpenAI ont échoué
- Vérifiez vos clés API dans les paramètres

🔧 Testez une nouvelle génération après avoir configuré les API.`;

        await this.sendTypingMessage('complete', errorSummary);
        
        return '';
      }
    }
  }

  // Parse et sépare les fichiers multiples (recommandation ChatGPT #2)
  private parseMultipleFiles(content: string): Array<{filename: string, content: string, language: string}> {
    const files: Array<{filename: string, content: string, language: string}> = [];
    
    // Détection des blocs de code avec noms de fichiers
    const fileBlocks = content.split(/```(\w+)\s*(?:filename=(.+?))?\n/);
    
    for (let i = 1; i < fileBlocks.length; i += 3) {
      const language = fileBlocks[i];
      const filename = fileBlocks[i + 1] || this.getDefaultFilename(language);
      const fileContent = fileBlocks[i + 2]?.split('```')[0] || '';
      
      if (fileContent.trim()) {
        files.push({
          filename: filename.trim(),
          content: fileContent.trim(),
          language
        });
      }
    }
    
    // Si pas de blocs détectés, créer un fichier unique
    if (files.length === 0) {
      const defaultLang = this.detectLanguageFromContent(content);
      files.push({
        filename: this.getDefaultFilename(defaultLang),
        content: content.trim(),
        language: defaultLang
      });
    }
    
    return files;
  }
  
  private getDefaultFilename(language: string): string {
    const extensions: Record<string, string> = {
      'html': 'index.html',
      'css': 'styles.css',
      'javascript': 'script.js',
      'js': 'script.js',
      'python': 'main.py',
      'java': 'Main.java',
      'cpp': 'main.cpp',
      'c': 'main.c'
    };
    return extensions[language.toLowerCase()] || `main.${language}`;
  }
  
  private detectLanguageFromContent(content: string): string {
    if (content.includes('<!DOCTYPE') || content.includes('<html')) return 'html';
    if (content.includes('{') && content.includes('color:')) return 'css';
    if (content.includes('function') || content.includes('const ')) return 'javascript';
    if (content.includes('def ') || content.includes('import ')) return 'python';
    return 'html';
  }

  // Méthodes pour édition post-génération (recommandation ChatGPT #3)
  public getGeneratedFile(filename: string): string | undefined {
    return this.generatedFiles.get(filename);
  }

  public updateGeneratedFile(filename: string, content: string): void {
    this.generatedFiles.set(filename, content);
    
    // Notification de mise à jour
    this.onMessage({
      type: 'file',
      content: content,
      filename: filename,
      language: this.detectLanguageFromContent(content)
    });
  }

  public getAllGeneratedFiles(): Map<string, string> {
    return new Map(this.generatedFiles);
  }

  public addFileToProject(filename: string, content: string): void {
    this.generatedFiles.set(filename, content);
    
    this.onMessage({
      type: 'file',
      content: content,
      filename: filename,
      language: this.detectLanguageFromContent(content)
    });
  }

  // Génération de preview HTML complet (recommandation ChatGPT #4)
  public generatePreviewHTML(): string {
    const htmlFile = this.generatedFiles.get('index.html') || '';
    const cssFile = this.generatedFiles.get('styles.css') || '';
    const jsFile = this.generatedFiles.get('script.js') || '';

    // Si pas de HTML de base, créer une structure minimale
    if (!htmlFile) {
      return `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preview</title>
    <style>${cssFile}</style>
</head>
<body>
    <div class="container">
        <h1>Aucun contenu HTML généré</h1>
        <p>Demandez à l'agent de créer du contenu HTML pour voir la prévisualisation.</p>
    </div>
    <script>${jsFile}</script>
</body>
</html>`;
    }

    // Injection automatique du CSS et JS dans le HTML
    let previewHTML = htmlFile;
    
    // Injection du CSS si présent
    if (cssFile && !previewHTML.includes('<style>')) {
      const headCloseIndex = previewHTML.indexOf('</head>');
      if (headCloseIndex !== -1) {
        previewHTML = previewHTML.substring(0, headCloseIndex) + 
                     `\n    <style>\n${cssFile}\n    </style>\n` + 
                     previewHTML.substring(headCloseIndex);
      }
    }
    
    // Injection du JavaScript si présent
    if (jsFile && !previewHTML.includes('<script>')) {
      const bodyCloseIndex = previewHTML.lastIndexOf('</body>');
      if (bodyCloseIndex !== -1) {
        previewHTML = previewHTML.substring(0, bodyCloseIndex) + 
                     `\n    <script>\n${jsFile}\n    </script>\n` + 
                     previewHTML.substring(bodyCloseIndex);
      }
    }

    return previewHTML;
  }

  getGeneratedFiles(): Map<string, string> {
    return this.generatedFiles;
  }
}

function logGhostwriterWorkflow({
  onMessage,
  intent,
  filesEdited = [],
  steps = [],
  restartApp = false,
  finalInstruction = "Relancez une génération pour tester."
}: {
  onMessage: (msg: { type: string; content: string; timestamp?: string }) => void,
  intent: string,
  filesEdited?: string[],
  steps?: string[],
  restartApp?: boolean,
  finalInstruction?: string
}) {
  const timestamp = new Date().toISOString();

  onMessage({
    type: "thinking",
    content: intent,
    timestamp
  });

  for (const file of filesEdited) {
    onMessage({
      type: "working",
      content: `✓ Edited ${file}`,
      timestamp
    });
  }

  for (const step of steps) {
    onMessage({
      type: "working",
      content: `✓ ${step}`,
      timestamp
    });
  }

  if (restartApp) {
    onMessage({
      type: "working",
      content: "✓ Restarted application",
      timestamp
    });
  }

  const summaryLines = [
    "**✅ Changements appliqués**",
    ...filesEdited.map(f => `- ✏️ Fichier modifié : \`${f}\``),
    ...steps.map(s => `- 🔧 ${s}`),
    restartApp ? "- 🔄 Application redémarrée" : null,
    "",
    `🎯 ${finalInstruction}`
  ].filter(Boolean).join('\n');

  onMessage({
    type: "complete",
    content: summaryLines,
    timestamp
  });
}