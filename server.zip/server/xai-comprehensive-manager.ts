// Gestionnaire complet xAI avec retry dynamique et surveillance automatique
import { xai } from './xai';

interface XAIHealthStatus {
  isHealthy: boolean;
  lastSuccessfulRequest: Date | null;
  consecutiveFailures: number;
  lastError: string | null;
  nextRetryAt: Date | null;
}

class XAIComprehensiveManager {
  private static instance: XAIComprehensiveManager;
  private status: XAIHealthStatus = {
    isHealthy: false,
    lastSuccessfulRequest: null,
    consecutiveFailures: 0,
    lastError: null,
    nextRetryAt: null
  };
  
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private readonly HEALTH_CHECK_INTERVAL = 5 * 60 * 1000; // 5 minutes
  private readonly MAX_CONSECUTIVE_FAILURES = 5;

  static getInstance(): XAIComprehensiveManager {
    if (!XAIComprehensiveManager.instance) {
      XAIComprehensiveManager.instance = new XAIComprehensiveManager();
    }
    return XAIComprehensiveManager.instance;
  }

  constructor() {
    this.startHealthMonitoring();
  }

  private async performHealthCheck(): Promise<boolean> {
    try {
      const response = await xai.chat.completions.create({
        model: "grok-2-1212",
        messages: [{ role: "user", content: "health check" }],
        max_tokens: 5,
        temperature: 0.1,
      });

      if (response.choices && response.choices.length > 0) {
        this.onHealthCheckSuccess();
        return true;
      }
      
      throw new Error('Invalid response structure');
    } catch (error: any) {
      this.onHealthCheckFailure(error);
      return false;
    }
  }

  private onHealthCheckSuccess(): void {
    const wasUnhealthy = !this.status.isHealthy;
    
    this.status.isHealthy = true;
    this.status.lastSuccessfulRequest = new Date();
    this.status.consecutiveFailures = 0;
    this.status.lastError = null;
    this.status.nextRetryAt = null;

    if (wasUnhealthy) {
      console.log('🟢 xAI redevient opérationnel après panne infrastructure');
    }
  }

  private onHealthCheckFailure(error: any): void {
    this.status.isHealthy = false;
    this.status.consecutiveFailures++;
    this.status.lastError = error.message || 'Erreur inconnue';

    const isInfrastructureError = error.status === 500 || error.message?.includes('500');
    
    if (isInfrastructureError) {
      console.log(`🔴 [source: xai/load-balancer] Panne infrastructure confirmée (tentative ${this.status.consecutiveFailures})`);
    }

    // Calcul du prochain retry avec backoff exponentiel
    const backoffMinutes = Math.min(5 * Math.pow(2, this.status.consecutiveFailures - 1), 60);
    this.status.nextRetryAt = new Date(Date.now() + backoffMinutes * 60 * 1000);
  }

  private startHealthMonitoring(): void {
    // Test initial
    this.performHealthCheck();

    // Tests périodiques
    this.healthCheckInterval = setInterval(() => {
      this.performHealthCheck();
    }, this.HEALTH_CHECK_INTERVAL);

    console.log('🔄 Surveillance automatique xAI démarrée (5min intervals)');
  }

  async attemptGeneration(
    prompt: string,
    language: string = 'html',
    existingCode: string = ''
  ): Promise<{ success: boolean; stream?: any; error?: string }> {
    // Si on sait que xAI est down, ne pas essayer
    if (!this.status.isHealthy && this.status.nextRetryAt && new Date() < this.status.nextRetryAt) {
      return {
        success: false,
        error: 'xAI temporarily unavailable (infrastructure issues)'
      };
    }

    try {
      const systemPrompt = `Tu es un développeur expert qui génère du code ${language} moderne, fonctionnel et optimisé.
Crée un code complet, bien structuré et prêt à utiliser.`;

      const userPrompt = existingCode 
        ? `${prompt}\n\nCode existant à améliorer:\n${existingCode}`
        : prompt;

      const stream = await xai.chat.completions.create({
        model: "grok-2-1212",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        stream: true,
        temperature: 0.7,
        max_tokens: 4000
      });

      this.onHealthCheckSuccess();
      return { success: true, stream };

    } catch (error: any) {
      this.onHealthCheckFailure(error);
      
      return {
        success: false,
        error: this.getErrorMessage(error)
      };
    }
  }

  private getErrorMessage(error: any): string {
    if (error.status === 500) {
      return 'Infrastructure xAI temporairement indisponible';
    } else if (error.status === 401) {
      return 'Authentification xAI échouée';
    } else if (error.status === 429) {
      return 'Quota xAI dépassé';
    } else if (error.message?.includes('timeout')) {
      return 'Timeout réseau xAI';
    }
    return 'Erreur xAI inconnue';
  }

  getStatus(): XAIHealthStatus & { 
    minutesUntilNextRetry?: number;
    isInBackoffPeriod: boolean;
  } {
    let minutesUntilNextRetry: number | undefined;
    let isInBackoffPeriod = false;

    if (this.status.nextRetryAt) {
      const msUntilRetry = this.status.nextRetryAt.getTime() - Date.now();
      if (msUntilRetry > 0) {
        minutesUntilNextRetry = Math.ceil(msUntilRetry / (60 * 1000));
        isInBackoffPeriod = true;
      }
    }

    return {
      ...this.status,
      minutesUntilNextRetry,
      isInBackoffPeriod
    };
  }

  stop(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
      console.log('⏹️ Surveillance xAI arrêtée');
    }
  }
}

export const xaiManager = XAIComprehensiveManager.getInstance();