import { EventEmitter } from 'events';

export interface ConnectivityStatus {
  online: boolean;
  apiAvailable: boolean;
  lastCheck: Date;
  errors: string[];
}

export class ConnectivityManager extends EventEmitter {
  private status: ConnectivityStatus = {
    online: false,
    apiAvailable: false,
    lastCheck: new Date(),
    errors: []
  };
  
  private checkInterval: NodeJS.Timeout | null = null;
  private readonly CHECK_INTERVAL = 30000; // 30 secondes

  constructor() {
    super();
    this.startMonitoring();
  }

  async checkConnectivity(): Promise<ConnectivityStatus> {
    const previousStatus = { ...this.status };
    this.status.errors = [];
    this.status.lastCheck = new Date();

    try {
      // Test de connectivité basique
      const response = await fetch('https://8.8.8.8', { 
        method: 'HEAD',
        signal: AbortSignal.timeout(5000)
      });
      this.status.online = response.ok;
    } catch (error) {
      this.status.online = false;
      this.status.errors.push(`Connectivité réseau: ${error.message}`);
    }

    if (this.status.online) {
      // Test des APIs IA si connecté
      await this.checkAIAPIs();
    } else {
      this.status.apiAvailable = false;
    }

    // Émettre un événement si le statut a changé
    if (previousStatus.online !== this.status.online || 
        previousStatus.apiAvailable !== this.status.apiAvailable) {
      this.emit('statusChanged', this.status);
    }

    return { ...this.status };
  }

  private async checkAIAPIs(): Promise<void> {
    const apis = [
      { name: 'OpenAI', key: process.env.OPENAI_API_KEY, url: 'https://api.openai.com/v1/models' },
      { name: 'Anthropic', key: process.env.ANTHROPIC_API_KEY, url: 'https://api.anthropic.com/v1/messages' }
    ];

    let anyApiAvailable = false;

    for (const api of apis) {
      if (!api.key) {
        this.status.errors.push(`${api.name}: Clé API manquante`);
        continue;
      }

      try {
        const response = await fetch(api.url, {
          method: 'HEAD',
          headers: {
            'Authorization': api.name === 'OpenAI' ? `Bearer ${api.key}` : `x-api-key: ${api.key}`
          },
          signal: AbortSignal.timeout(10000)
        });

        if (response.status === 200 || response.status === 401) {
          // 401 signifie que l'API répond (clé peut être invalide mais service accessible)
          anyApiAvailable = true;
        }
      } catch (error) {
        this.status.errors.push(`${api.name}: ${error.message}`);
      }
    }

    this.status.apiAvailable = anyApiAvailable;
  }

  startMonitoring(): void {
    // Vérification initiale
    this.checkConnectivity();

    // Vérifications périodiques
    this.checkInterval = setInterval(() => {
      this.checkConnectivity();
    }, this.CHECK_INTERVAL);
  }

  stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }

  getStatus(): ConnectivityStatus {
    return { ...this.status };
  }

  isOnline(): boolean {
    return this.status.online;
  }

  isAIAvailable(): boolean {
    return this.status.online && this.status.apiAvailable;
  }

  getOfflineCapabilities(): string[] {
    return [
      'Édition de code avec coloration syntaxique',
      'Gestionnaire de fichiers et projets',
      'Base de données locale (lecture/écriture)',
      'Serveur de preview local',
      'Historique et versions des fichiers',
      'Interface utilisateur complète',
      'Outils de développement intégrés'
    ];
  }

  getOnlineCapabilities(): string[] {
    return [
      'Agents IA (CodePhantom)',
      'Génération de code assistée',
      'Analyse de code avancée',
      'Corrections automatiques',
      'Optimisations suggérées',
      'Documentation automatique',
      'Explication de code'
    ];
  }
}

export const connectivityManager = new ConnectivityManager();