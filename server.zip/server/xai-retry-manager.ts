// Système de retry dynamique pour xAI avec backoff exponentiel
import { xai } from './xai';

interface RetryConfig {
  maxRetries: number;
  baseDelay: number; // ms
  maxDelay: number; // ms
  backoffMultiplier: number;
}

class XAIRetryManager {
  private static instance: XAIRetryManager;
  private config: RetryConfig = {
    maxRetries: 3,
    baseDelay: 2000, // 2 secondes
    maxDelay: 20000, // 20 secondes max
    backoffMultiplier: 2
  };

  static getInstance(): XAIRetryManager {
    if (!XAIRetryManager.instance) {
      XAIRetryManager.instance = new XAIRetryManager();
    }
    return XAIRetryManager.instance;
  }

  private calculateDelay(attempt: number): number {
    const delay = this.config.baseDelay * Math.pow(this.config.backoffMultiplier, attempt);
    return Math.min(delay, this.config.maxDelay);
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async executeWithRetry<T>(
    operation: () => Promise<T>,
    context: string = 'xAI operation'
  ): Promise<T> {
    let lastError: Error | null = null;

    for (let attempt = 0; attempt <= this.config.maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          const delayMs = this.calculateDelay(attempt - 1);
          console.log(`🔄 Retry ${attempt}/${this.config.maxRetries} pour ${context} dans ${delayMs}ms`);
          await this.delay(delayMs);
        }

        const result = await operation();
        
        if (attempt > 0) {
          console.log(`✅ ${context} réussi après ${attempt} tentative(s)`);
        }
        
        return result;

      } catch (error: any) {
        lastError = error;
        
        // Ne pas retenter pour certaines erreurs
        if (error.status === 401 || error.status === 403) {
          console.log(`🛑 Arrêt retry pour ${context}: erreur auth (${error.status})`);
          throw error;
        }

        if (error.status === 400) {
          console.log(`🛑 Arrêt retry pour ${context}: requête invalide (400)`);
          throw error;
        }

        console.log(`❌ Tentative ${attempt + 1}/${this.config.maxRetries + 1} échouée pour ${context}:`, {
          status: error.status,
          message: error.message?.substring(0, 100)
        });

        // Si c'est la dernière tentative, abandonner
        if (attempt === this.config.maxRetries) {
          console.log(`🔴 Abandon après ${this.config.maxRetries} tentatives pour ${context}`);
          break;
        }
      }
    }

    throw lastError || new Error(`${context} failed after ${this.config.maxRetries} retries`);
  }

  // Méthode spécialisée pour xAI streaming
  async generateCodeWithRetry(
    prompt: string,
    language: string = 'html',
    existingCode: string = ''
  ): Promise<any> {
    return this.executeWithRetry(async () => {
      const stream = await xai.chat.completions.create({
        model: "grok-2-1212",
        messages: [
          { 
            role: "system", 
            content: `Tu es un développeur expert qui génère du code ${language} moderne et fonctionnel.` 
          },
          { 
            role: "user", 
            content: existingCode ? `${prompt}\n\nCode existant:\n${existingCode}` : prompt 
          }
        ],
        stream: true,
        temperature: 0.7,
        max_tokens: 4000
      });

      return stream;
    }, `xAI code generation (${language})`);
  }

  // Test de connectivité simple
  async testConnection(): Promise<boolean> {
    try {
      await this.executeWithRetry(async () => {
        const response = await xai.chat.completions.create({
          model: "grok-2-1212",
          messages: [{ role: "user", content: "test" }],
          max_tokens: 5,
          temperature: 0.1,
        });

        if (!response.choices || response.choices.length === 0) {
          throw new Error('Réponse xAI invalide');
        }

        return response;
      }, 'xAI connection test');

      return true;
    } catch (error) {
      return false;
    }
  }

  updateConfig(newConfig: Partial<RetryConfig>): void {
    this.config = { ...this.config, ...newConfig };
    console.log('🔧 Configuration retry xAI mise à jour:', this.config);
  }
}

export const xaiRetryManager = XAIRetryManager.getInstance();