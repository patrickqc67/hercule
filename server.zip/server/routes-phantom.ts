// Routes API pour CodePhantom - Intégration avancée
import { Router } from 'express';
import { PhantomIntegration } from './phantom-integration';
import { storage } from './storage';

const router = Router();

// Instance globale de PhantomIntegration
let phantomInstance: PhantomIntegration | null = null;

// Initialisation de PhantomIntegration avec streaming
function initializePhantom(onMessage: (message: any) => void): PhantomIntegration {
  if (!phantomInstance) {
    phantomInstance = new PhantomIntegration(onMessage);
  }
  return phantomInstance;
}

// Route de génération avancée avec CodePhantom
router.post('/api/phantom/generate', async (req, res) => {
  try {
    const { prompt, language, projectId, existingCode = '', mode = 'advanced' } = req.body;

    if (!prompt || !projectId) {
      return res.status(400).json({ message: 'Prompt et projectId requis' });
    }

    // Configuration du streaming SSE
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Cache-Control'
    });

    let messageId = 0;
    
    const phantom = initializePhantom((message) => {
      const sseMessage = {
        id: ++messageId,
        type: message.type,
        data: {
          content: message.content,
          filename: message.filename,
          language: message.language,
          step: message.step,
          metadata: message.metadata
        },
        timestamp: Date.now()
      };
      
      res.write(`data: ${JSON.stringify(sseMessage)}\n\n`);
    });

    // Configuration du modèle et style de code si fournis
    if (req.body.aiModel) {
      phantom.setAIModels(req.body.aiModel, req.body.fallbackModels || []);
    }
    
    if (req.body.codeStyle) {
      phantom.setCodeStyle(req.body.codeStyle);
    }

    let result: string;
    
    if (mode === 'debug' && req.body.errorLogs) {
      // Mode debug avec logs d'erreur
      result = await phantom.debugWithLogs(
        req.body.errorLogs,
        projectId,
        req.body.environment || 'development'
      );
    } else {
      // Mode génération avancée standard
      result = await phantom.generateAdvanced(
        prompt,
        language || 'javascript',
        projectId,
        existingCode
      );
    }

    // Message final de completion
    res.write(`data: ${JSON.stringify({
      id: ++messageId,
      type: 'complete',
      data: {
        content: result,
        success: true
      },
      timestamp: Date.now()
    })}\n\n`);

    res.end();

  } catch (error) {
    console.error('Erreur CodePhantom:', error);
    
    const errorMessage = {
      id: Date.now(),
      type: 'error',
      data: {
        content: `Erreur CodePhantom: ${error}`,
        success: false
      },
      timestamp: Date.now()
    };
    
    res.write(`data: ${JSON.stringify(errorMessage)}\n\n`);
    res.end();
  }
});

// Route d'annulation de génération
router.post('/api/phantom/cancel', (req, res) => {
  try {
    if (phantomInstance) {
      phantomInstance.cancelGeneration();
    }
    res.json({ success: true, message: 'Génération annulée' });
  } catch (error) {
    res.status(500).json({ success: false, message: String(error) });
  }
});

// Route de configuration CodePhantom
router.post('/api/phantom/config', (req, res) => {
  try {
    const { aiModel, fallbackModels, codeStyle } = req.body;
    
    if (!phantomInstance) {
      return res.status(400).json({ message: 'CodePhantom non initialisé' });
    }

    if (aiModel) {
      phantomInstance.setAIModels(aiModel, fallbackModels || []);
    }
    
    if (codeStyle) {
      phantomInstance.setCodeStyle(codeStyle);
    }

    res.json({ success: true, message: 'Configuration mise à jour' });
  } catch (error) {
    res.status(500).json({ success: false, message: String(error) });
  }
});

// Route de statut CodePhantom
router.get('/api/phantom/status', (req, res) => {
  res.json({
    initialized: !!phantomInstance,
    features: {
      multiFileAnalysis: true,
      crossFileIssueDetection: true,
      autoDocumentation: true,
      intelligentDebugging: true,
      autoFix: true,
      multiModelSupport: true,
      streamingCancellation: true
    },
    version: '2.0.0'
  });
});

// Route d'analyse de projet complète
router.post('/api/phantom/analyze-project', async (req, res) => {
  try {
    const { projectId } = req.body;
    
    if (!projectId) {
      return res.status(400).json({ message: 'Project ID requis' });
    }

    // Récupération de tous les fichiers du projet
    const files = await storage.getFilesByProjectId(projectId);
    
    // Analyse statistique du projet
    const analysis = {
      totalFiles: files.length,
      languages: Array.from(new Set(files.map(f => detectLanguage(f.name)))),
      totalLines: files.reduce((sum, f) => sum + (f.content?.split('\n').length || 0), 0),
      frameworks: detectFrameworksInProject(files),
      dependencies: extractProjectDependencies(files),
      issuesDetected: await analyzeProjectIssues(files),
      codeQuality: calculateCodeQuality(files),
      suggestions: generateProjectSuggestions(files)
    };

    res.json({
      success: true,
      analysis,
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Erreur analyse projet:', error);
    res.status(500).json({ success: false, message: String(error) });
  }
});

// Fonctions utilitaires pour l'analyse de projet
function detectLanguage(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase();
  const langMap: Record<string, string> = {
    'js': 'JavaScript',
    'ts': 'TypeScript',
    'py': 'Python',
    'html': 'HTML',
    'css': 'CSS',
    'php': 'PHP',
    'java': 'Java'
  };
  return langMap[ext || ''] || 'Unknown';
}

function detectFrameworksInProject(files: any[]): string[] {
  const frameworks = new Set<string>();
  
  files.forEach(file => {
    const content = file.content || '';
    
    if (content.includes('import React') || content.includes('from "react"')) {
      frameworks.add('React');
    }
    if (content.includes('import Vue') || content.includes('@vue')) {
      frameworks.add('Vue.js');
    }
    if (content.includes('express') || content.includes('app.get')) {
      frameworks.add('Express.js');
    }
    if (content.includes('django') || content.includes('Flask')) {
      frameworks.add(content.includes('django') ? 'Django' : 'Flask');
    }
  });
  
  return Array.from(frameworks);
}

function extractProjectDependencies(files: any[]): string[] {
  const dependencies = new Set<string>();
  
  files.forEach(file => {
    const content = file.content || '';
    
    // Extract npm dependencies
    const importMatches = content.match(/import.*from ['"]([^'"]+)['"]/g) || [];
    const requireMatches = content.match(/require\(['"]([^'"]+)['"]\)/g) || [];
    
    [...importMatches, ...requireMatches].forEach(match => {
      const dep = match.match(/['"]([^'"]+)['"]/)?.[1];
      if (dep && !dep.startsWith('.') && !dep.startsWith('/')) {
        dependencies.add(dep);
      }
    });
  });
  
  return Array.from(dependencies);
}

async function analyzeProjectIssues(files: any[]): Promise<string[]> {
  const issues: string[] = [];
  
  files.forEach(file => {
    const content = file.content || '';
    
    // Détection d'erreurs courantes
    if (content.includes('console.log') && process.env.NODE_ENV === 'production') {
      issues.push(`Console.log détecté dans ${file.name} (production)`);
    }
    
    // Vérification des accolades
    const openBraces = (content.match(/\{/g) || []).length;
    const closeBraces = (content.match(/\}/g) || []).length;
    if (openBraces !== closeBraces) {
      issues.push(`Accolades non équilibrées dans ${file.name}`);
    }
    
    // Vérification des imports manquants
    if (content.includes('React') && !content.includes('import React')) {
      issues.push(`Import React manquant dans ${file.name}`);
    }
  });
  
  return issues;
}

function calculateCodeQuality(files: any[]): number {
  let qualityScore = 100;
  
  files.forEach(file => {
    const content = file.content || '';
    const lines = content.split('\n');
    
    // Pénalités pour mauvaises pratiques
    if (content.includes('var ')) qualityScore -= 5;
    if (content.includes('console.log')) qualityScore -= 3;
    if (lines.length > 500) qualityScore -= 10; // Fichier trop long
    
    // Bonus pour bonnes pratiques
    if (content.includes('const ') || content.includes('let ')) qualityScore += 2;
    if (content.includes('// ') || content.includes('/* ')) qualityScore += 3; // Commentaires
  });
  
  return Math.max(0, Math.min(100, qualityScore));
}

function generateProjectSuggestions(files: any[]): string[] {
  const suggestions: string[] = [];
  
  const hasTests = files.some(f => f.name.includes('test') || f.name.includes('spec'));
  if (!hasTests) {
    suggestions.push('Ajouter des tests unitaires');
  }
  
  const hasReadme = files.some(f => f.name.toLowerCase().includes('readme'));
  if (!hasReadme) {
    suggestions.push('Créer un fichier README.md');
  }
  
  const hasTypeScript = files.some(f => f.name.endsWith('.ts'));
  const hasJavaScript = files.some(f => f.name.endsWith('.js'));
  if (hasJavaScript && !hasTypeScript) {
    suggestions.push('Considérer la migration vers TypeScript');
  }
  
  return suggestions;
}

export default router;