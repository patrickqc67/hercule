import OpenAI from "openai";

// Fonction pour analyser et enrichir les prompts utilisateur
function analyzeAndEnhancePrompt(userPrompt: string, language: string): string {
  const prompt = userPrompt.toLowerCase();
  
  // Détecter les mots-clés pour les systèmes de rendez-vous/booking
  const appointmentKeywords = [
    'rendez-vous', 'rdv', 'appointment', 'booking', 'réservation',
    'créneau', 'planning', 'calendrier', 'désistement', 'annulation',
    'remplacement', 'liste d\'attente', 'disponibilité'
  ];
  
  const isAppointmentSystem = appointmentKeywords.some(keyword => 
    prompt.includes(keyword) || prompt.includes(keyword.replace(/'/g, ''))
  );
  
  if (isAppointmentSystem) {
    return `${userPrompt}

SPECIFIC REQUIREMENTS FOR APPOINTMENT/BOOKING SYSTEM:
- Create a complete appointment management system
- Include data structures for appointments, clients, and time slots
- Build user interface for viewing available appointments
- Implement functionality for booking appointments
- Add system for handling cancellations and allowing replacements
- Include forms for client information and appointment selection
- Show appointment status (available, booked, cancelled)
- Allow clients to take slots from cancelled appointments
- Include proper date/time handling and validation`;
  }
  
  // Détecter d'autres types de systèmes complexes
  const ecommerceKeywords = ['boutique', 'shop', 'store', 'panier', 'cart', 'produit', 'product'];
  const isEcommerce = ecommerceKeywords.some(keyword => prompt.includes(keyword));
  
  if (isEcommerce) {
    return `${userPrompt}

SPECIFIC REQUIREMENTS FOR E-COMMERCE SYSTEM:
- Create a complete online store interface
- Include product catalog with images and descriptions
- Implement shopping cart functionality
- Add product categories and search
- Include checkout process and forms`;
  }
  
  return userPrompt;
}
import { ChatCompletionMessageParam } from "openai/resources/chat/completions";
import fs from 'fs';
import path from 'path';

// Initialisation conditionnelle d'OpenAI
let openai: OpenAI | null = null;

function initializeOpenAI(): OpenAI | null {
  if (!openai && process.env.OPENAI_API_KEY) {
    openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY
    });
  }
  return openai;
}

// Function to analyze code and identify potential issues
export async function analyzeCode(code: string, language: string, projectContext: string = "") {
  try {
    const client = initializeOpenAI();
    if (!client) {
      return {
        error: "OpenAI API key not configured. Please set OPENAI_API_KEY in your environment variables.",
        needsApiKey: true
      };
    }
    let systemPrompt = `You are an expert programmer in ${language} with deep knowledge of software architecture, design patterns, and best practices.
Analyze the following code to provide a thorough technical assessment. Consider:

1. Code quality, readability and maintainability
2. Performance considerations and algorithmic complexity
3. Security vulnerabilities and potential edge cases
4. Architecture patterns and design principles
5. Technical debt and refactoring opportunities
6. Testing and validation requirements
7. Standards compliance and best practices for ${language}

Provide your analysis in JSON format with the following enhanced structure:
{
  "issues": [
    {
      "line": number,
      "issue": "detailed technical description of the issue",
      "severity": "error|warning|info",
      "impact": "high|medium|low",
      "suggestion": "detailed technical suggested fix with code example when applicable",
      "category": "security|performance|maintainability|functionality|architecture"
    }
  ],
  "architecture_analysis": {
    "patterns_used": ["list of identified design patterns or architectural approaches"],
    "pattern_opportunities": ["list of suggested design patterns that could improve the code"],
    "modularity_score": number (1-10),
    "cohesion_score": number (1-10),
    "coupling_assessment": "brief technical assessment"
  },
  "performance_analysis": {
    "algorithmic_complexity": "Big O notation assessment",
    "bottlenecks": ["list of identified performance bottlenecks"],
    "optimization_suggestions": ["list of specific performance improvements"]
  },
  "security_assessment": {
    "vulnerabilities": ["list of potential security issues"],
    "risk_level": "high|medium|low",
    "remediation_steps": ["list of security improvements"]
  },
  "summary": "detailed technical summary of the code quality",
  "improvement_suggestions": ["array of prioritized suggestions with technical rationale"]
}`;

    // Construire les messages
    let messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: systemPrompt
      }
    ];
    
    // Ajouter le contexte du projet s'il est fourni
    if (projectContext) {
      messages.push({
        role: "system",
        content: `Project context for this analysis: ${projectContext}`
      });
    }
    
    // Ajouter le code à analyser
    messages.push({
      role: "user",
      content: code
    });

    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.3, // Prioritiser la précision pour l'analyse
      max_tokens: 3000, // Permettre une analyse détaillée
      response_format: { type: "json_object" }
    });

    const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
    
    // Assurer que tous les champs attendus sont présents, même si vides
    const defaultAnalysis = {
      issues: [],
      architecture_analysis: {
        patterns_used: [],
        pattern_opportunities: [],
        modularity_score: 0,
        cohesion_score: 0,
        coupling_assessment: ""
      },
      performance_analysis: {
        algorithmic_complexity: "",
        bottlenecks: [],
        optimization_suggestions: []
      },
      security_assessment: {
        vulnerabilities: [],
        risk_level: "low",
        remediation_steps: []
      },
      summary: "",
      improvement_suggestions: []
    };
    
    return { ...defaultAnalysis, ...analysisResult };
  } catch (error) {
    console.error("Error analyzing code:", error);
    throw new Error("Failed to analyze code: " + (error as Error).message);
  }
}

// Function to generate code based on a prompt
export async function generateCode(prompt: string, language: string, existingCode: string = "", context: string = "", agent?: string) {
  try {
    const client = initializeOpenAI();
    if (!client) {
      return {
        error: "OpenAI API key not configured. Please set OPENAI_API_KEY in your environment variables.",
        needsApiKey: true
      };
    }
    console.log(`Génération de code avec ${agent || 'default'} pour le langage:`, language);
    
    // Personnaliser le prompt système en fonction de l'agent sélectionné
    let systemPrompt = "";
    
    switch (agent) {
      case "github":
        systemPrompt = `Tu es GitHub Codespaces, un assistant IA de programmation qui aide à la génération de code. Réponds TOUJOURS en français.
Génère du code ${language} propre et maintenable en suivant les standards de l'industrie et les meilleures pratiques.`;
        break;
      case "openai":
        systemPrompt = `Tu es ChatGPT, le modèle de langage d'OpenAI. Réponds TOUJOURS en français. Tu dois analyser minutieusement les demandes des utilisateurs avant de générer du code.

PROCESSUS D'ANALYSE:
1. Analyser la demande utilisateur pour comprendre la fonctionnalité requise
2. Identifier les exigences métier spécifiques et les flux utilisateur
3. Déterminer les structures de données et composants nécessaires
4. Planifier l'approche d'implémentation

PROCESSUS DE GÉNÉRATION:
Génère du code ${language} clair et bien structuré qui:
- Implémente exactement la fonctionnalité demandée par l'utilisateur
- Suit les meilleures pratiques et conventions modernes
- Inclut une gestion appropriée des données et de l'interaction utilisateur
- Traite le cas d'usage spécifique décrit

Pour les applications métier comme les systèmes de rendez-vous ou plateformes de réservation:
- Crée des modèles de données appropriés pour le domaine
- Construit des interfaces utilisateur pour les parcours principaux
- Implémente la logique métier spécifique demandée
- Inclut une validation de formulaire et gestion d'état appropriée

Concentre-toi toujours sur la résolution du problème réel décrit, pas sur la création de modèles génériques.`;
        break;
      case "anthropic":
        systemPrompt = `Tu es Claude, l'assistant IA d'Anthropic. Réponds TOUJOURS en français. Tu dois analyser minutieusement les demandes utilisateur avant de générer du code.

EXIGENCES D'ANALYSE:
1. Examiner attentivement ce que l'utilisateur demande
2. Identifier la logique métier spécifique et les fonctionnalités nécessaires
3. Décomposer les exigences complexes en fonctionnalités implémentables
4. Considérer l'expérience utilisateur et le flux de travail

EXIGENCES DE GÉNÉRATION:
Génère du code ${language} propre et bien structuré qui:
- Implémente directement la fonctionnalité demandée
- Suit les meilleures pratiques et standards modernes
- Inclut une gestion appropriée des données et interactions utilisateur
- Se concentre sur la résolution du problème réel décrit

Pour les demandes concernant les systèmes de réservation, gestion de rendez-vous, ou applications métier similaires:
- Inclut des structures de données pour gérer les entités principales
- Crée des interfaces utilisateur pour les flux de travail principaux
- Implémente la logique métier spécifique demandée
- Ajoute une gestion appropriée des formulaires et de l'état

Concentre-toi sur la création de solutions fonctionnelles et maintenables qui répondent aux exigences réelles de l'utilisateur, pas sur des modèles génériques.`;
        break;
      case "gemini":
        systemPrompt = `Tu es Gemini, l'assistant IA de Google. Réponds TOUJOURS en français. Tu dois analyser de manière exhaustive les demandes utilisateur avant de générer du code.

MÉTHODOLOGIE D'ANALYSE:
1. Examiner la demande utilisateur pour comprendre la fonctionnalité prévue
2. Identifier les exigences métier spécifiques et les besoins utilisateur
3. Décomposer les demandes complexes en composants implémentables
4. Considérer le flux de travail complet et l'expérience utilisateur

MÉTHODOLOGIE DE GÉNÉRATION:
Génère du code ${language} clair et efficace qui:
- Traite directement la fonctionnalité décrite dans la demande
- Suit les pratiques de développement et patterns modernes
- Implémente une gestion appropriée des données et logique métier
- Crée des interfaces utilisateur fonctionnelles pour les cas d'usage spécifiés

Pour les applications complexes comme la gestion de rendez-vous ou systèmes de réservation:
- Conçoit des structures de données appropriées pour le domaine métier
- Crée des interfaces utilisateur qui supportent les flux de travail requis
- Implémente les règles métier spécifiques et la logique demandée
- Inclut une validation et gestion d'erreur appropriée

Génère toujours du code qui résout le problème réel décrit, pas des exemples génériques.`;
        break;
      case "replit":
        systemPrompt = `Tu es l'Agent Replit, un assistant IA de programmation intelligent. Réponds TOUJOURS en français. Avant de générer du code, tu dois d'abord analyser et comprendre complètement la demande de l'utilisateur.

PHASE D'ANALYSE:
1. Lis attentivement la demande utilisateur et identifie la fonctionnalité principale nécessaire
2. Décompose les exigences complexes en fonctionnalités spécifiques
3. Considère la logique métier et le flux de travail utilisateur
4. Détermine quels composants, fonctions ou systèmes sont nécessaires

PHASE DE GÉNÉRATION:
Seulement après avoir compris les exigences, génère du code ${language} propre et fonctionnel qui:
- Implémente la fonctionnalité spécifique demandée
- Suit les pratiques de développement modernes et conventions
- Inclut une structure et organisation appropriée
- Se concentre sur les exigences métier réelles, pas sur des modèles génériques

Pour les demandes complexes comme "système de gestion de rendez-vous" ou "système de réservation", analyse quelles fonctionnalités spécifiques sont nécessaires:
- Gestion des données (rendez-vous, clients, créneaux horaires)
- Interface utilisateur pour visualiser et gérer les rendez-vous
- Logique pour gérer les annulations et remplacements
- Formulaires pour réserver et reprogrammer
- Suivi de statut et notifications

IMPORTANT: Génère du code qui répond directement aux besoins spécifiques de l'utilisateur, pas des pages d'accueil génériques ou des modèles.`;
        break;
      default:
        systemPrompt = `Tu es un programmeur expert en ${language} avec une compréhension approfondie de l'architecture logicielle, des modèles de conception et des meilleures pratiques. Réponds TOUJOURS en français.`;
    }
    
    // Ajout des instructions communes pour tous les agents
    systemPrompt += `
Generate clean, efficient, and well-commented code based on the user's request. Use modern development standards and follow these guidelines:

1. Write code that is optimized for performance and maintainability
2. Include appropriate error handling and edge case management
3. Follow industry-standard naming conventions and formatting for ${language}
4. Structure your code with a focus on reusability and modularity
5. Include JSDoc/documentation comments for functions and complex logic
6. Consider security implications of the code you generate
7. When appropriate, use design patterns (Factory, Observer, etc.) and explain them in comments
8. Optimize algorithmic complexity where relevant`;



    // Analyser et enrichir la demande de l'utilisateur
    const enhancedPrompt = analyzeAndEnhancePrompt(prompt, language);
    
    systemPrompt += `\n\nIMPORTANT: Analyze the user's request thoroughly and implement the specific functionality they are asking for. Do not generate generic templates or welcome pages.

Return only the functional code that addresses their actual requirements.`;
    

    // Construire les messages en fonction du contexte disponible
    let messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: systemPrompt
      }
    ];
    
    // Ajouter le contexte s'il est fourni
    if (context) {
      messages.push({
        role: "system",
        content: `Additional context for this request: ${context}`
      });
    }
    
    // Ajouter le code existant s'il est fourni
    if (existingCode) {
      messages.push({
        role: "system",
        content: `The following code already exists in the project and should be considered or extended as appropriate:\n\n\`\`\`${language}\n${existingCode}\n\`\`\``
      });
    }
    
    // Ajouter la demande de l'utilisateur enrichie
    messages.push({
      role: "user",
      content: enhancedPrompt
    });

    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.7, // Équilibre entre créativité et précision
      max_tokens: 4000  // Permettre des réponses plus longues pour du code complexe
    });

    console.log("Réponse reçue de l'API OpenAI");
    
    // Analyser la réponse pour extraire les détails de l'implémentation
    const generatedCode = response.choices[0].message.content || "";
    
    return { 
      code: generatedCode,
      language: language
    };
  } catch (error) {
    console.error("Error generating code:", error);
    throw new Error("Failed to generate code: " + (error as Error).message);
  }
}

// Function to fix code based on errors
// Fonction pour générer du code avec une architecture plus complexe
export async function generateComplexArchitecture(prompt: string, language: string, requirements: string, existingCode: string = "") {
  try {
    const client = initializeOpenAI();
    if (!client) {
      return {
        error: "OpenAI API key not configured. Please set OPENAI_API_KEY in your environment variables.",
        needsApiKey: true
      };
    }
    console.log("Génération d'architecture complexe pour le langage:", language);
    
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are an expert software architect with deep expertise in ${language} and modern software design principles.
        
Your task is to create a sophisticated, well-architected solution based on the user's requirements.

Follow these advanced architectural principles:
1. Apply the appropriate architectural pattern (MVC, MVVM, Clean Architecture, Hexagonal, etc.) based on the requirements
2. Design with SOLID principles and design patterns appropriate for ${language}
3. Create a modular, extensible architecture that supports future growth
4. Include proper separation of concerns and clear layer boundaries
5. Ensure testability at all levels (unit, integration, e2e)
6. Implement effective error handling and logging strategies
7. Consider performance, security, and scalability in your design
8. Provide abstractions and dependency injection where appropriate

Your solution should be accompanied by:
1. A high-level architecture diagram in ASCII/text format
2. Implementation of key components/modules with detailed comments explaining design decisions
3. Explanation of patterns and principles applied in code comments
4. File structure organization for the entire solution
5. Interface/contract definitions
6. Dependency management approach

Generate production-quality code with proper documentation, error handling, and test considerations.`
      }
    ];
    
    // Ajouter les exigences spécifiques
    messages.push({
      role: "system",
      content: `Specific requirements for this architecture:\n${requirements}`
    });
    
    // Ajouter le code existant s'il est fourni
    if (existingCode) {
      messages.push({
        role: "system",
        content: `The following code already exists and should be integrated into your architecture:\n\n\`\`\`${language}\n${existingCode}\n\`\`\``
      });
    }
    
    // Ajouter la demande principale
    messages.push({
      role: "user",
      content: prompt
    });
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.5, // Équilibre entre créativité architecturale et rigueur
      max_tokens: 4000  // Solution complète nécessitant plus d'espace
    });
    
    return {
      code: response.choices[0].message.content || "",
      language: language
    };
  } catch (error) {
    console.error("Error generating complex architecture:", error);
    throw new Error("Failed to generate complex architecture: " + (error as Error).message);
  }
}

export async function fixCode(code: string, language: string, error: string) {
  try {
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `Tu es un programmeur expert en ${language} avec une compréhension approfondie des modèles d'erreurs et des techniques de débogage. Réponds TOUJOURS en français.
Corrige le code suivant qui contient une erreur. Le message d'erreur est : "${error}".

Directives pour ta correction :
1. Identifie la cause racine de l'erreur, pas seulement les symptômes
2. Applique la correction la plus efficace et maintenable
3. Assure-toi que la correction n'introduit pas de nouveaux bugs
4. Suis les meilleures pratiques pour ${language}
5. Effectue des changements minimaux pour corriger le problème
6. Considère les cas limites qui pourraient déclencher des erreurs similaires
7. Maintiens le style de code et l'architecture d'origine

Retourne uniquement le code corrigé avec des commentaires en français.`
      },
      {
        role: "user",
        content: code
      }
    ];
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.4  // Un peu de créativité, mais priorité à la précision
    });

    return { 
      code: response.choices[0].message.content || "",
      language: language
    };
  } catch (error) {
    console.error("Error fixing code:", error);
    throw new Error("Failed to fix code");
  }
}

// Fonction pour générer des tests unitaires automatiquement
export async function generateTests(code: string, language: string, testFramework: string = "") {
  try {
    // Déterminer le framework de test par défaut selon le langage si non spécifié
    if (!testFramework) {
      const testFrameworks: Record<string, string> = {
        "javascript": "jest",
        "typescript": "jest",
        "python": "pytest",
        "java": "junit",
        "csharp": "xunit",
        "ruby": "rspec",
        "go": "testing",
        "php": "phpunit",
        "rust": "cargo test"
      };
      testFramework = testFrameworks[language] || "jest";
    }
    
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are an expert software tester with deep knowledge of ${language} and the ${testFramework} testing framework.
Generate comprehensive unit tests for the following code.

Guidelines for your test suite:
1. Cover all functions, methods, and classes in the provided code
2. Include tests for both normal operation and edge cases
3. Test error handling and input validation
4. Properly use mocking where appropriate for external dependencies
5. Follow test best practices for ${language} and ${testFramework}
6. Include setup and teardown as needed
7. Create descriptive test names that indicate what's being tested
8. Add comments explaining testing strategy for complex tests

Return only the test code without additional explanation outside of code comments.`
      },
      {
        role: "user",
        content: code
      }
    ];
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.4,
      max_tokens: 3000
    });

    return { 
      code: response.choices[0].message.content || "",
      language: language,
      testFramework: testFramework
    };
  } catch (error) {
    console.error("Error generating tests:", error);
    throw new Error("Failed to generate tests: " + (error as Error).message);
  }
}

// Fonction pour optimiser les performances du code
export async function optimizeCode(code: string, language: string, optimizationGoal: string = "general") {
  try {
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are an expert performance engineer specializing in ${language} optimization.
Analyze and optimize the following code for ${optimizationGoal} performance.

Guidelines for your optimization:
1. Identify and address performance bottlenecks
2. Use language-specific optimizations appropriate for ${language}
3. Consider algorithmic complexity improvements
4. Optimize memory usage and resource allocation
5. Ensure the optimized code maintains the same functionality
6. Add comments explaining optimization techniques used
7. Avoid premature optimization that sacrifices code readability
8. Consider multi-threading/async where appropriate

Return the optimized code with comments explaining key optimizations.`
      },
      {
        role: "user",
        content: code
      }
    ];
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.3,
      max_tokens: 3000
    });

    return { 
      code: response.choices[0].message.content || "",
      language: language
    };
  } catch (error) {
    console.error("Error optimizing code:", error);
    throw new Error("Failed to optimize code: " + (error as Error).message);
  }
}

// Fonction pour générer de la documentation technique
export async function generateDocumentation(code: string, language: string, format: string = "markdown") {
  try {
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are an expert technical documentation writer specializing in ${language}.
Create comprehensive documentation for the following code in ${format} format.

Guidelines for your documentation:
1. Provide an overview of what the code does
2. Document all classes, functions, and methods
3. Explain parameters, return values, and exceptions/errors
4. Include usage examples for key functionality
5. Document any dependencies or requirements
6. Maintain a clear, professional documentation style
7. Include a table of contents for larger documentation
8. For APIs, include request/response examples if applicable

Return only the documentation in ${format} format.`
      },
      {
        role: "user",
        content: code
      }
    ];
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.5,
      max_tokens: 3000
    });

    return { 
      documentation: response.choices[0].message.content || "",
      format: format
    };
  } catch (error) {
    console.error("Error generating documentation:", error);
    throw new Error("Failed to generate documentation: " + (error as Error).message);
  }
}

// Fonction pour expliquer le code de manière pédagogique
export async function explainCode(code: string, language: string, expertiseLevel: string = "intermediate") {
  try {
    const messages: ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `You are an expert programming educator specializing in ${language}.
Explain the following code to a ${expertiseLevel}-level programmer.

Guidelines for your explanation:
1. Break down complex concepts into understandable parts
2. Explain the logic and flow of the code
3. Highlight important programming patterns and techniques used
4. Point out any non-obvious aspects of the implementation
5. Include insights about why certain approaches were taken
6. Adapt your explanation to the ${expertiseLevel} level
7. Use analogies or visualizations where helpful
8. Focus on teaching rather than just describing

Provide a clear, educational explanation of the code.`
      },
      {
        role: "user",
        content: code
      }
    ];
    
    const response = await (client as OpenAI).chat.completions.create({
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      model: "gpt-4o",
      messages,
      temperature: 0.6,
      max_tokens: 2500
    });

    return { 
      explanation: response.choices[0].message.content || "",
      language: language
    };
  } catch (error) {
    console.error("Error explaining code:", error);
    throw new Error("Failed to explain code: " + (error as Error).message);
  }
}
