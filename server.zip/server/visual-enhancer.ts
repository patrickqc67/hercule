import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface VisualTheme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
  font: string;
  style: string;
}

interface VisualEnhancement {
  theme: VisualTheme;
  cssVariables: string;
  imagePrompts: string[];
  designDirection: string;
}

export class VisualEnhancer {
  private static themes: Record<string, VisualTheme> = {
    'ultra-modern': {
      primary: '#6366f1',
      secondary: '#8b5cf6',
      accent: '#f59e0b',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      text: '#1f2937',
      font: 'Inter, system-ui, sans-serif',
      style: 'glassmorphism avec animations 3D'
    },
    'minimal': {
      primary: '#111827',
      secondary: '#6b7280',
      accent: '#3b82f6',
      background: '#ffffff',
      text: '#111827',
      font: 'Helvetica Neue, Arial, sans-serif',
      style: 'minimaliste épuré'
    },
    'luxury': {
      primary: '#d4af37',
      secondary: '#2d3748',
      accent: '#c53030',
      background: 'linear-gradient(45deg, #1a202c, #2d3748)',
      text: '#f7fafc',
      font: 'Playfair Display, serif',
      style: 'luxueux avec dorures'
    },
    'dark': {
      primary: '#10b981',
      secondary: '#6366f1',
      accent: '#f59e0b',
      background: 'linear-gradient(135deg, #0f172a, #1e293b)',
      text: '#f1f5f9',
      font: 'Poppins, sans-serif',
      style: 'sombre cyberpunk'
    },
    'colorful': {
      primary: '#ec4899',
      secondary: '#8b5cf6',
      accent: '#f59e0b',
      background: 'linear-gradient(135deg, #ff6b6b, #4ecdc4, #45b7d1)',
      text: '#1f2937',
      font: 'Nunito, sans-serif',
      style: 'vibrant multicolore'
    }
  };

  private static detectDomainFromPrompt(prompt: string): string {
    const lowerPrompt = prompt.toLowerCase();
    
    if (lowerPrompt.includes('boutique') || lowerPrompt.includes('shop') || lowerPrompt.includes('ecommerce')) {
      return 'ecommerce';
    }
    if (lowerPrompt.includes('restaurant') || lowerPrompt.includes('nourriture') || lowerPrompt.includes('food')) {
      return 'restaurant';
    }
    if (lowerPrompt.includes('portfolio') || lowerPrompt.includes('cv') || lowerPrompt.includes('professionnel')) {
      return 'portfolio';
    }
    if (lowerPrompt.includes('blog') || lowerPrompt.includes('article') || lowerPrompt.includes('news')) {
      return 'blog';
    }
    if (lowerPrompt.includes('agence') || lowerPrompt.includes('entreprise') || lowerPrompt.includes('corporate')) {
      return 'corporate';
    }
    if (lowerPrompt.includes('jeu') || lowerPrompt.includes('game') || lowerPrompt.includes('gaming')) {
      return 'gaming';
    }
    
    return 'general';
  }

  private static getImagePromptsForDomain(domain: string, specificItem?: string): string[] {
    const prompts: Record<string, string[]> = {
      'ecommerce': [
        'produit moderne sur fond neutre, style e-commerce professionnel',
        'packaging élégant pour boutique en ligne',
        'interface utilisateur de panier d\'achat moderne'
      ],
      'restaurant': [
        'plat gastronomique artistique sur assiette élégante',
        'intérieur de restaurant moderne et chaleureux',
        'ingrédients frais disposés artistiquement'
      ],
      'portfolio': [
        'espace de travail créatif moderne avec ordinateur',
        'design graphique abstrait professionnel',
        'bureau d\'architecte ou designer minimaliste'
      ],
      'corporate': [
        'équipe professionnelle en réunion moderne',
        'bureau moderne avec vue panoramique',
        'graphiques de performance d\'entreprise stylisés'
      ],
      'gaming': [
        'interface de jeu futuriste néon',
        'manette de jeu sur fond technologique',
        'écran gaming avec effets lumineux'
      ],
      'general': [
        'design moderne et élégant',
        'interface utilisateur innovante',
        'composition graphique harmonieuse'
      ]
    };

    let domainPrompts = prompts[domain] || prompts['general'];
    
    if (specificItem) {
      domainPrompts = domainPrompts.map(prompt => 
        prompt.replace(/produit|plat|design/, specificItem)
      );
    }
    
    return domainPrompts;
  }

  public static async enhanceDesign(
    prompt: string, 
    designStyle: string = 'ultra-modern',
    language: string = 'html'
  ): Promise<VisualEnhancement> {
    const domain = this.detectDomainFromPrompt(prompt);
    const theme = this.themes[designStyle] || this.themes['ultra-modern'];
    
    // Détecter l'item spécifique mentionné dans le prompt
    const specificItem = this.extractSpecificItem(prompt);
    
    const imagePrompts = this.getImagePromptsForDomain(domain, specificItem);
    
    const cssVariables = this.generateCSSVariables(theme);
    
    const designDirection = this.generateDesignDirection(domain, theme, specificItem);
    
    return {
      theme,
      cssVariables,
      imagePrompts,
      designDirection
    };
  }

  private static extractSpecificItem(prompt: string): string | undefined {
    const lowerPrompt = prompt.toLowerCase();
    
    // Extraction d'items spécifiques
    if (lowerPrompt.includes('poisson')) return 'poisson tropical';
    if (lowerPrompt.includes('vêtement') || lowerPrompt.includes('clothing')) return 'vêtement stylé';
    if (lowerPrompt.includes('chaussure')) return 'chaussure tendance';
    if (lowerPrompt.includes('bijou')) return 'bijou élégant';
    if (lowerPrompt.includes('livre')) return 'livre moderne';
    if (lowerPrompt.includes('café') || lowerPrompt.includes('coffee')) return 'café artisanal';
    
    return undefined;
  }

  private static generateCSSVariables(theme: VisualTheme): string {
    return `
:root {
  --color-primary: ${theme.primary};
  --color-secondary: ${theme.secondary};
  --color-accent: ${theme.accent};
  --color-text: ${theme.text};
  --font-primary: ${theme.font};
  --background: ${theme.background};
  
  /* Design avancé */
  --shadow-soft: 0 4px 20px rgba(0, 0, 0, 0.1);
  --shadow-strong: 0 8px 40px rgba(0, 0, 0, 0.2);
  --border-radius: 12px;
  --border-radius-large: 20px;
  --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  /* Glassmorphism */
  --glass-bg: rgba(255, 255, 255, 0.1);
  --glass-border: rgba(255, 255, 255, 0.2);
  --backdrop-blur: blur(20px);
}

/* Animations modernes */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes scaleHover {
  from { transform: scale(1); }
  to { transform: scale(1.05); }
}

@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}

/* Classes utilitaires modernes */
.glassmorphism {
  background: var(--glass-bg);
  backdrop-filter: var(--backdrop-blur);
  border: 1px solid var(--glass-border);
  border-radius: var(--border-radius);
}

.card-modern {
  background: white;
  border-radius: var(--border-radius-large);
  box-shadow: var(--shadow-soft);
  transition: var(--transition);
  overflow: hidden;
}

.card-modern:hover {
  transform: translateY(-5px);
  box-shadow: var(--shadow-strong);
}

.button-primary {
  background: linear-gradient(135deg, var(--color-primary), var(--color-secondary));
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: var(--border-radius);
  font-weight: 600;
  cursor: pointer;
  transition: var(--transition);
  position: relative;
  overflow: hidden;
}

.button-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(99, 102, 241, 0.4);
}

.text-gradient {
  background: linear-gradient(135deg, var(--color-primary), var(--color-accent));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
`;
  }

  private static generateDesignDirection(domain: string, theme: VisualTheme, specificItem?: string): string {
    const directions: Record<string, string> = {
      'ecommerce': `Interface e-commerce ${theme.style} avec cartes produits élégantes, navigation intuitive et checkout optimisé. Focus sur la conversion avec des CTA attractifs.`,
      'restaurant': `Design gastronomique ${theme.style} avec mise en valeur des plats, ambiance chaleureuse et réservation en ligne fluide.`,
      'portfolio': `Portfolio ${theme.style} avec présentation créative des projets, navigation fluide et mise en valeur des compétences.`,
      'corporate': `Site corporate ${theme.style} avec design professionnel, sections services clairement structurées et contact optimisé.`,
      'gaming': `Interface gaming ${theme.style} avec effets visuels immersifs, animations dynamiques et expérience utilisateur engageante.`,
      'general': `Design moderne ${theme.style} avec interface utilisateur intuitive et expérience optimisée.`
    };

    let direction = directions[domain] || directions['general'];
    
    if (specificItem) {
      direction += ` Mise en valeur spéciale pour : ${specificItem}.`;
    }
    
    return direction;
  }

  public static async generateContextualImages(
    prompt: string,
    imagePrompts: string[],
    count: number = 3
  ): Promise<string[]> {
    if (!process.env.OPENAI_API_KEY) {
      return this.getFallbackImages(prompt, count);
    }

    try {
      const images: string[] = [];
      
      for (let i = 0; i < Math.min(count, imagePrompts.length); i++) {
        const response = await openai.images.generate({
          prompt: imagePrompts[i],
          size: "512x512",
          n: 1,
          quality: "standard"
        });
        
        if (response.data && response.data[0]?.url) {
          images.push(response.data[0].url);
        }
      }
      
      return images;
    } catch (error) {
      console.error('Erreur génération images:', error);
      return this.getFallbackImages(prompt, count);
    }
  }

  public static getFallbackImages(prompt: string, count: number): string[] {
    const lowerPrompt = prompt.toLowerCase();
    
    // Images spécifiques selon le contenu du prompt
    let specificUrls: string[] = [];
    
    if (lowerPrompt.includes('outil') && lowerPrompt.includes('mecanique')) {
      specificUrls = [
        'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1581092335397-9583eb92d232?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1541753866388-0b3c701627d3?w=512&h=512&fit=crop&auto=format'
      ];
    } else if (lowerPrompt.includes('bonbon') || lowerPrompt.includes('candy')) {
      specificUrls = [
        'https://images.unsplash.com/photo-1571506165871-ee72a35836b0?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1587736804726-8b6b6e3d3d5a?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=512&h=512&fit=crop&auto=format'
      ];
    } else if (lowerPrompt.includes('crayon') || lowerPrompt.includes('pencil')) {
      specificUrls = [
        'https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1587033411391-5d9e51cce126?w=512&h=512&fit=crop&auto=format',
        'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=512&h=512&fit=crop&auto=format'
      ];
    }
    
    const domain = this.detectDomainFromPrompt(prompt);
    const baseUrls: Record<string, string[]> = {
      'ecommerce': specificUrls.length > 0 ? specificUrls : [
        'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=512&h=512&fit=crop'
      ],
      'restaurant': [
        'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=512&h=512&fit=crop'
      ],
      'portfolio': [
        'https://images.unsplash.com/photo-1486312338219-ce68e2c6b696?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=512&h=512&fit=crop'
      ],
      'general': [
        'https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=512&h=512&fit=crop',
        'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=512&h=512&fit=crop'
      ]
    };
    
    const urls = baseUrls[domain] || baseUrls['general'];
    return urls.slice(0, count);
  }

  public static injectVisualEnhancements(
    htmlCode: string,
    enhancement: VisualEnhancement,
    images: string[] = []
  ): string {
    let enhancedCode = htmlCode;
    
    // Injecter les variables CSS dans le head
    if (enhancedCode.includes('<head>')) {
      const styleTag = `<style>${enhancement.cssVariables}</style>`;
      enhancedCode = enhancedCode.replace('</head>', `${styleTag}\n</head>`);
    }
    
    // Remplacer les placeholders d'images par les vraies images
    if (images.length > 0) {
      images.forEach((imageUrl, index) => {
        const placeholders = [
          'https://via.placeholder.com/300',
          'https://via.placeholder.com/400', 
          'https://via.placeholder.com/500',
          'images/gant1.jpg',
          'images/gant2.jpg',
          'images/gant3.jpg',
          'images/product1.jpg',
          'images/product2.jpg',
          'images/product3.jpg',
          `https://source.unsplash.com/featured/?product,modern`,
          `placeholder-image-${index + 1}`,
          'style="background-image: url(\'images/gant1.jpg\');"',
          'style="background-image: url(\'images/gant2.jpg\');"'
        ];
        
        placeholders.forEach(placeholder => {
          if (placeholder.includes('background-image')) {
            enhancedCode = enhancedCode.replace(placeholder, `style="background-image: url('${imageUrl}');"`);
          } else {
            enhancedCode = enhancedCode.replace(new RegExp(placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), imageUrl);
          }
        });
      });
    }
    
    return enhancedCode;
  }
}