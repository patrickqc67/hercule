import { storage } from './storage';

// Templates de projets artistiques et complexes
const modernWebTemplates = {
  business: {
    html: `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entreprise Moderne</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="hero-section">
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <h2>ENTREPRISE</h2>
                </div>
                <ul class="nav-menu">
                    <li><a href="#accueil">Accueil</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#apropos">À propos</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </nav>
        
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">Transformez votre vision en réalité</h1>
                <p class="hero-description">Solutions innovantes pour votre entreprise avec une approche créative et moderne</p>
                <div class="hero-buttons">
                    <button class="btn-primary">Commencer</button>
                    <button class="btn-secondary">En savoir plus</button>
                </div>
            </div>
            <div class="hero-visual">
                <div class="floating-card card-1"></div>
                <div class="floating-card card-2"></div>
                <div class="floating-card card-3"></div>
            </div>
        </div>
    </header>

    <section class="services-section" id="services">
        <div class="container">
            <h2 class="section-title">Nos Services</h2>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">🚀</div>
                    <h3>Innovation</h3>
                    <p>Solutions créatives et innovantes pour votre entreprise</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">⚡</div>
                    <h3>Performance</h3>
                    <p>Optimisation et performance maximale de vos projets</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">🎯</div>
                    <h3>Stratégie</h3>
                    <p>Stratégies sur mesure pour atteindre vos objectifs</p>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section" id="apropos">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>À propos de nous</h2>
                    <p>Nous sommes une équipe passionnée qui transforme les idées en réalité digitale.</p>
                    <div class="stats">
                        <div class="stat">
                            <span class="stat-number">500+</span>
                            <span class="stat-label">Projets réalisés</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">98%</span>
                            <span class="stat-label">Satisfaction client</span>
                        </div>
                    </div>
                </div>
                <div class="about-visual">
                    <div class="visual-element"></div>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer" id="contact">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>contact@entreprise.com</p>
                    <p>+33 1 23 45 67 89</p>
                </div>
                <div class="footer-section">
                    <h3>Suivez-nous</h3>
                    <div class="social-links">
                        <a href="#">LinkedIn</a>
                        <a href="#">Twitter</a>
                        <a href="#">Instagram</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="script.js"></script>
</body>
</html>`,

    css: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', sans-serif;
    line-height: 1.6;
    color: #333;
    overflow-x: hidden;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Navigation */
.navbar {
    position: fixed;
    top: 0;
    width: 100%;
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    z-index: 1000;
    padding: 1rem 0;
    transition: all 0.3s ease;
}

.nav-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo h2 {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: 700;
}

.nav-menu {
    display: flex;
    list-style: none;
    gap: 2rem;
}

.nav-menu a {
    text-decoration: none;
    color: #333;
    font-weight: 500;
    transition: color 0.3s ease;
}

.nav-menu a:hover {
    color: #667eea;
}

.hamburger {
    display: none;
    flex-direction: column;
    cursor: pointer;
}

.hamburger span {
    width: 25px;
    height: 3px;
    background: #333;
    margin: 3px 0;
    transition: 0.3s;
}

/* Hero Section */
.hero-section {
    min-height: 100vh;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    flex-direction: column;
    position: relative;
    overflow: hidden;
}

.hero-content {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    margin-top: 80px;
}

.hero-text {
    flex: 1;
    color: white;
    max-width: 600px;
}

.hero-title {
    font-size: 3.5rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    line-height: 1.2;
}

.hero-description {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
}

.btn-primary, .btn-secondary {
    padding: 1rem 2rem;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 1rem;
}

.btn-primary {
    background: white;
    color: #667eea;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.btn-secondary {
    background: transparent;
    color: white;
    border: 2px solid white;
}

.btn-secondary:hover {
    background: white;
    color: #667eea;
}

/* Hero Visual */
.hero-visual {
    flex: 1;
    position: relative;
    height: 500px;
}

.floating-card {
    position: absolute;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 20px;
    animation: float 6s ease-in-out infinite;
}

.card-1 {
    width: 200px;
    height: 250px;
    top: 50px;
    right: 100px;
    animation-delay: 0s;
}

.card-2 {
    width: 150px;
    height: 200px;
    top: 200px;
    right: 300px;
    animation-delay: 2s;
}

.card-3 {
    width: 180px;
    height: 220px;
    top: 100px;
    right: 50px;
    animation-delay: 4s;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-20px) rotate(2deg); }
}

/* Services Section */
.services-section {
    padding: 100px 0;
    background: #f8fafc;
}

.section-title {
    text-align: center;
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 3rem;
    color: #1a202c;
}

.services-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 3rem;
}

.service-card {
    background: white;
    padding: 2.5rem;
    border-radius: 20px;
    text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
    border: 1px solid #e2e8f0;
}

.service-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.15);
}

.service-icon {
    font-size: 3rem;
    margin-bottom: 1.5rem;
}

.service-card h3 {
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 1rem;
    color: #1a202c;
}

.service-card p {
    color: #64748b;
    line-height: 1.6;
}

/* About Section */
.about-section {
    padding: 100px 0;
    background: white;
}

.about-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
}

.about-text h2 {
    font-size: 2.5rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    color: #1a202c;
}

.about-text p {
    font-size: 1.1rem;
    color: #64748b;
    margin-bottom: 2rem;
}

.stats {
    display: flex;
    gap: 3rem;
}

.stat {
    display: flex;
    flex-direction: column;
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #667eea;
}

.stat-label {
    color: #64748b;
    font-weight: 500;
}

.about-visual {
    position: relative;
    height: 400px;
}

.visual-element {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 20px;
    position: relative;
    overflow: hidden;
}

.visual-element::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: repeating-linear-gradient(
        45deg,
        transparent,
        transparent 10px,
        rgba(255,255,255,0.1) 10px,
        rgba(255,255,255,0.1) 20px
    );
    animation: slide 20s linear infinite;
}

@keyframes slide {
    0% { transform: translate(-50%, -50%) rotate(0deg); }
    100% { transform: translate(-50%, -50%) rotate(360deg); }
}

/* Footer */
.footer {
    background: #1a202c;
    color: white;
    padding: 3rem 0;
}

.footer-content {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
}

.footer-section h3 {
    margin-bottom: 1rem;
    font-weight: 600;
}

.footer-section p {
    margin-bottom: 0.5rem;
    color: #a0aec0;
}

.social-links {
    display: flex;
    gap: 1rem;
}

.social-links a {
    color: #a0aec0;
    text-decoration: none;
    transition: color 0.3s ease;
}

.social-links a:hover {
    color: #667eea;
}

/* Responsive */
@media (max-width: 768px) {
    .hamburger {
        display: flex;
    }
    
    .nav-menu {
        display: none;
    }
    
    .hero-content {
        flex-direction: column;
        text-align: center;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .about-content {
        grid-template-columns: 1fr;
    }
    
    .hero-visual {
        height: 300px;
        margin-top: 2rem;
    }
    
    .stats {
        justify-content: center;
    }
}`,

    js: `// Animation des éléments au scroll
function animateOnScroll() {
    const elements = document.querySelectorAll('.service-card, .about-text, .stats');
    
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
}

// Initialisation des animations
document.addEventListener('DOMContentLoaded', function() {
    // Style initial pour les éléments animés
    const animatedElements = document.querySelectorAll('.service-card, .about-text, .stats');
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'all 0.6s ease';
    });
    
    // Navigation mobile
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
    }
    
    // Smooth scroll pour les liens
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Animation des stats au scroll
    const stats = document.querySelectorAll('.stat-number');
    const animateStats = () => {
        stats.forEach(stat => {
            const target = parseInt(stat.textContent);
            const increment = target / 100;
            let current = 0;
            
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    stat.textContent = target + (stat.textContent.includes('%') ? '%' : '+');
                    clearInterval(timer);
                } else {
                    stat.textContent = Math.ceil(current) + (stat.textContent.includes('%') ? '%' : '+');
                }
            }, 20);
        });
    };
    
    // Observer pour les animations au scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                
                if (entry.target.classList.contains('stats')) {
                    animateStats();
                }
            }
        });
    });
    
    animatedElements.forEach(element => {
        observer.observe(element);
    });
});

// Effet parallax pour le hero
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const rate = scrolled * -0.5;
    
    const heroVisual = document.querySelector('.hero-visual');
    if (heroVisual) {
        heroVisual.style.transform = \`translateY(\${rate}px)\`;
    }
    
    // Changement de style de la navbar au scroll
    const navbar = document.querySelector('.navbar');
    if (scrolled > 50) {
        navbar.style.background = 'rgba(255, 255, 255, 0.98)';
        navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
    } else {
        navbar.style.background = 'rgba(255, 255, 255, 0.95)';
        navbar.style.boxShadow = 'none';
    }
});

// Effet de typing pour le titre
function typeWriter(element, text, speed = 100) {
    let i = 0;
    element.innerHTML = '';
    
    function type() {
        if (i < text.length) {
            element.innerHTML += text.charAt(i);
            i++;
            setTimeout(type, speed);
        }
    }
    
    type();
}

// Démarrer l'effet de typing après le chargement
window.addEventListener('load', () => {
    const heroTitle = document.querySelector('.hero-title');
    const originalText = heroTitle.textContent;
    typeWriter(heroTitle, originalText, 80);
});`
  },

  portfolio: {
    html: `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio Créatif</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
</head>
<body>
    <div class="cursor"></div>
    <div class="cursor-follower"></div>
    
    <nav class="nav">
        <div class="nav-brand">Portfolio</div>
        <div class="nav-links">
            <a href="#home" class="nav-link active">Accueil</a>
            <a href="#about" class="nav-link">À propos</a>
            <a href="#work" class="nav-link">Projets</a>
            <a href="#contact" class="nav-link">Contact</a>
        </div>
        <div class="nav-toggle">
            <span></span>
            <span></span>
        </div>
    </nav>

    <main>
        <section id="home" class="hero">
            <div class="hero-content">
                <div class="hero-text">
                    <h1 class="hero-title">
                        <span class="title-line">Créatif</span>
                        <span class="title-line">Designer</span>
                        <span class="title-line">Développeur</span>
                    </h1>
                    <p class="hero-subtitle">Je crée des expériences digitales uniques et mémorables</p>
                </div>
                <div class="hero-visual">
                    <div class="visual-grid">
                        <div class="grid-item item-1"></div>
                        <div class="grid-item item-2"></div>
                        <div class="grid-item item-3"></div>
                        <div class="grid-item item-4"></div>
                    </div>
                </div>
            </div>
            <div class="scroll-indicator">
                <span>Découvrir</span>
                <div class="scroll-line"></div>
            </div>
        </section>

        <section id="about" class="about">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title">À propos</h2>
                    <div class="section-line"></div>
                </div>
                <div class="about-content">
                    <div class="about-text">
                        <p class="about-intro">Passionné par l'art numérique et l'innovation, je transforme les idées en expériences visuelles captivantes.</p>
                        <div class="skills">
                            <div class="skill-category">
                                <h3>Design</h3>
                                <div class="skill-list">
                                    <span class="skill-tag">UI/UX</span>
                                    <span class="skill-tag">Branding</span>
                                    <span class="skill-tag">Motion</span>
                                </div>
                            </div>
                            <div class="skill-category">
                                <h3>Développement</h3>
                                <div class="skill-list">
                                    <span class="skill-tag">React</span>
                                    <span class="skill-tag">Node.js</span>
                                    <span class="skill-tag">Three.js</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="about-image">
                        <div class="image-container">
                            <div class="image-overlay"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="work" class="work">
            <div class="container">
                <div class="section-header">
                    <h2 class="section-title">Projets sélectionnés</h2>
                    <div class="section-line"></div>
                </div>
                <div class="projects-grid">
                    <article class="project-card" data-project="1">
                        <div class="project-image">
                            <div class="project-overlay">
                                <h3>E-commerce Moderne</h3>
                                <p>Design & Développement</p>
                                <button class="project-btn">Voir le projet</button>
                            </div>
                        </div>
                    </article>
                    <article class="project-card" data-project="2">
                        <div class="project-image">
                            <div class="project-overlay">
                                <h3>Application Mobile</h3>
                                <p>UI/UX Design</p>
                                <button class="project-btn">Voir le projet</button>
                            </div>
                        </div>
                    </article>
                    <article class="project-card" data-project="3">
                        <div class="project-image">
                            <div class="project-overlay">
                                <h3>Site Vitrine</h3>
                                <p>Développement Web</p>
                                <button class="project-btn">Voir le projet</button>
                            </div>
                        </div>
                    </article>
                    <article class="project-card" data-project="4">
                        <div class="project-image">
                            <div class="project-overlay">
                                <h3>Identité Visuelle</h3>
                                <p>Branding</p>
                                <button class="project-btn">Voir le projet</button>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <section id="contact" class="contact">
            <div class="container">
                <div class="contact-content">
                    <div class="contact-text">
                        <h2>Discutons de votre projet</h2>
                        <p>Prêt à créer quelque chose d'extraordinaire ensemble ?</p>
                        <div class="contact-info">
                            <div class="contact-item">
                                <span class="contact-label">Email</span>
                                <span class="contact-value">hello@portfolio.com</span>
                            </div>
                            <div class="contact-item">
                                <span class="contact-label">Téléphone</span>
                                <span class="contact-value">+33 6 12 34 56 78</span>
                            </div>
                        </div>
                    </div>
                    <form class="contact-form">
                        <div class="form-group">
                            <input type="text" id="name" required>
                            <label for="name">Nom</label>
                        </div>
                        <div class="form-group">
                            <input type="email" id="email" required>
                            <label for="email">Email</label>
                        </div>
                        <div class="form-group">
                            <textarea id="message" required></textarea>
                            <label for="message">Message</label>
                        </div>
                        <button type="submit" class="submit-btn">
                            <span>Envoyer</span>
                            <div class="btn-arrow">→</div>
                        </button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <script src="script.js"></script>
</body>
</html>`,

    css: `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    font-family: 'Inter', sans-serif;
    background: #0a0a0a;
    color: #ffffff;
    overflow-x: hidden;
    cursor: none;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
}

/* Curseur personnalisé */
.cursor {
    position: fixed;
    width: 20px;
    height: 20px;
    background: #fff;
    border-radius: 50%;
    pointer-events: none;
    z-index: 9999;
    transition: transform 0.1s ease;
    mix-blend-mode: difference;
}

.cursor-follower {
    position: fixed;
    width: 40px;
    height: 40px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    pointer-events: none;
    z-index: 9998;
    transition: all 0.3s ease;
}

/* Navigation */
.nav {
    position: fixed;
    top: 0;
    width: 100%;
    padding: 2rem;
    background: rgba(10, 10, 10, 0.8);
    backdrop-filter: blur(20px);
    z-index: 1000;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.nav-brand {
    font-family: 'Playfair Display', serif;
    font-size: 1.5rem;
    font-weight: 600;
}

.nav-links {
    display: flex;
    gap: 3rem;
}

.nav-link {
    color: #ffffff;
    text-decoration: none;
    font-weight: 300;
    transition: all 0.3s ease;
    position: relative;
}

.nav-link::after {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 0;
    width: 0;
    height: 1px;
    background: #ffffff;
    transition: width 0.3s ease;
}

.nav-link:hover::after,
.nav-link.active::after {
    width: 100%;
}

.nav-toggle {
    display: none;
    flex-direction: column;
    gap: 5px;
    cursor: pointer;
}

.nav-toggle span {
    width: 25px;
    height: 2px;
    background: #ffffff;
    transition: all 0.3s ease;
}

/* Hero Section */
.hero {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    padding: 0 2rem;
}

.hero-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
    max-width: 1200px;
    width: 100%;
}

.hero-title {
    font-family: 'Playfair Display', serif;
    font-size: 4rem;
    font-weight: 700;
    line-height: 1.1;
    margin-bottom: 2rem;
}

.title-line {
    display: block;
    overflow: hidden;
}

.title-line:nth-child(2) {
    color: #666;
}

.hero-subtitle {
    font-size: 1.2rem;
    color: #999;
    font-weight: 300;
}

.hero-visual {
    height: 500px;
    position: relative;
}

.visual-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 1rem;
    height: 100%;
}

.grid-item {
    background: linear-gradient(45deg, #1a1a1a, #333);
    border-radius: 20px;
    transition: all 0.5s ease;
    position: relative;
    overflow: hidden;
}

.grid-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
    transition: left 0.5s ease;
}

.grid-item:hover::before {
    left: 100%;
}

.item-1 { animation-delay: 0.1s; }
.item-2 { animation-delay: 0.2s; }
.item-3 { animation-delay: 0.3s; }
.item-4 { animation-delay: 0.4s; }

.scroll-indicator {
    position: absolute;
    bottom: 2rem;
    left: 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    color: #999;
    font-size: 0.9rem;
}

.scroll-line {
    width: 2px;
    height: 60px;
    background: #333;
    position: relative;
    overflow: hidden;
}

.scroll-line::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 20px;
    background: #fff;
    animation: scroll-animation 2s infinite;
}

@keyframes scroll-animation {
    0% { transform: translateY(-20px); }
    100% { transform: translateY(60px); }
}

/* About Section */
.about {
    padding: 8rem 0;
    background: #111;
}

.section-header {
    text-align: center;
    margin-bottom: 4rem;
}

.section-title {
    font-family: 'Playfair Display', serif;
    font-size: 3rem;
    font-weight: 600;
    margin-bottom: 1rem;
}

.section-line {
    width: 60px;
    height: 2px;
    background: #fff;
    margin: 0 auto;
}

.about-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: center;
}

.about-intro {
    font-size: 1.3rem;
    line-height: 1.6;
    margin-bottom: 3rem;
    color: #ccc;
}

.skills {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.skill-category h3 {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    color: #fff;
}

.skill-list {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}

.skill-tag {
    background: rgba(255, 255, 255, 0.1);
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.9rem;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.about-image {
    height: 400px;
}

.image-container {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #1a1a1a, #333);
    border-radius: 20px;
    position: relative;
    overflow: hidden;
}

.image-overlay {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 80%;
    height: 80%;
    background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
    border-radius: 10px;
}

/* Work Section */
.work {
    padding: 8rem 0;
    background: #0a0a0a;
}

.projects-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 2rem;
}

.project-card {
    aspect-ratio: 4/3;
    border-radius: 20px;
    overflow: hidden;
    position: relative;
    cursor: pointer;
}

.project-image {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #1a1a1a, #333);
    position: relative;
    transition: all 0.5s ease;
}

.project-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: all 0.5s ease;
    text-align: center;
}

.project-card:hover .project-overlay {
    opacity: 1;
}

.project-card:hover .project-image {
    transform: scale(1.1);
}

.project-overlay h3 {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
}

.project-overlay p {
    color: #999;
    margin-bottom: 1.5rem;
}

.project-btn {
    background: transparent;
    border: 1px solid #fff;
    color: #fff;
    padding: 0.8rem 2rem;
    border-radius: 30px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.project-btn:hover {
    background: #fff;
    color: #000;
}

/* Contact Section */
.contact {
    padding: 8rem 0;
    background: #111;
}

.contact-content {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 4rem;
    align-items: start;
}

.contact-text h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.5rem;
    margin-bottom: 1rem;
}

.contact-text p {
    color: #999;
    margin-bottom: 2rem;
}

.contact-info {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.contact-item {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
}

.contact-label {
    font-size: 0.9rem;
    color: #666;
}

.contact-value {
    font-size: 1.1rem;
    color: #fff;
}

.contact-form {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.form-group {
    position: relative;
}

.form-group input,
.form-group textarea {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid #333;
    padding: 1rem 0;
    color: #fff;
    font-size: 1rem;
    outline: none;
    transition: border-color 0.3s ease;
}

.form-group textarea {
    resize: vertical;
    min-height: 120px;
}

.form-group label {
    position: absolute;
    top: 1rem;
    left: 0;
    color: #666;
    pointer-events: none;
    transition: all 0.3s ease;
}

.form-group input:focus,
.form-group textarea:focus {
    border-bottom-color: #fff;
}

.form-group input:focus + label,
.form-group textarea:focus + label,
.form-group input:valid + label,
.form-group textarea:valid + label {
    transform: translateY(-1.5rem);
    font-size: 0.8rem;
    color: #fff;
}

.submit-btn {
    background: #fff;
    color: #000;
    border: none;
    padding: 1rem 2rem;
    border-radius: 30px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    font-weight: 500;
    transition: all 0.3s ease;
    align-self: start;
}

.submit-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 30px rgba(255, 255, 255, 0.2);
}

.btn-arrow {
    transition: transform 0.3s ease;
}

.submit-btn:hover .btn-arrow {
    transform: translateX(5px);
}

/* Responsive */
@media (max-width: 768px) {
    body {
        cursor: auto;
    }
    
    .cursor,
    .cursor-follower {
        display: none;
    }
    
    .nav-links {
        display: none;
    }
    
    .nav-toggle {
        display: flex;
    }
    
    .hero-content {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .hero-title {
        font-size: 2.5rem;
    }
    
    .about-content,
    .contact-content {
        grid-template-columns: 1fr;
    }
    
    .projects-grid {
        grid-template-columns: 1fr;
    }
    
    .section-title {
        font-size: 2rem;
    }
}`,

    js: `// Gestion du curseur personnalisé
const cursor = document.querySelector('.cursor');
const cursorFollower = document.querySelector('.cursor-follower');

document.addEventListener('mousemove', (e) => {
    cursor.style.left = e.clientX + 'px';
    cursor.style.top = e.clientY + 'px';
    
    setTimeout(() => {
        cursorFollower.style.left = e.clientX + 'px';
        cursorFollower.style.top = e.clientY + 'px';
    }, 100);
});

// Effet hover sur les éléments interactifs
const interactiveElements = document.querySelectorAll('a, button, .project-card');

interactiveElements.forEach(el => {
    el.addEventListener('mouseenter', () => {
        cursor.style.transform = 'scale(1.5)';
        cursorFollower.style.transform = 'scale(1.5)';
    });
    
    el.addEventListener('mouseleave', () => {
        cursor.style.transform = 'scale(1)';
        cursorFollower.style.transform = 'scale(1)';
    });
});

// Navigation fluide
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Retirer la classe active de tous les liens
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        // Ajouter la classe active au lien cliqué
        link.classList.add('active');
        
        // Scroll vers la section
        const target = document.querySelector(link.getAttribute('href'));
        target.scrollIntoView({ behavior: 'smooth' });
    });
});

// Animation d'apparition des éléments
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Appliquer l'animation aux éléments
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll('.grid-item, .skill-category, .project-card, .contact-text, .contact-form');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s ease';
        observer.observe(el);
    });
    
    // Animation du titre avec effet de frappe
    const titleLines = document.querySelectorAll('.title-line');
    titleLines.forEach((line, index) => {
        setTimeout(() => {
            line.style.animation = \`slideUp 0.8s ease forwards\`;
        }, index * 200);
    });
});

// Parallax pour les éléments
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    
    // Parallax pour les grid items
    document.querySelectorAll('.grid-item').forEach((item, index) => {
        const speed = 0.5 + (index * 0.1);
        item.style.transform = \`translateY(\${scrolled * speed}px)\`;
    });
    
    // Mise à jour de la navigation active
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');
        
        if (scrolled >= sectionTop && scrolled < sectionTop + sectionHeight) {
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === \`#\${sectionId}\`) {
                    link.classList.add('active');
                }
            });
        }
    });
});

// Animation CSS pour le titre
const style = document.createElement('style');
style.textContent = \`
    @keyframes slideUp {
        from {
            transform: translateY(100%);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    .title-line {
        overflow: hidden;
        display: inline-block;
    }
    
    .title-line::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: #0a0a0a;
        animation: reveal 0.8s ease forwards;
        animation-delay: inherit;
    }
    
    @keyframes reveal {
        from {
            left: 0;
        }
        to {
            left: 100%;
        }
    }
\`;
document.head.appendChild(style);

// Gestion du formulaire
document.querySelector('.contact-form').addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Animation du bouton
    const submitBtn = document.querySelector('.submit-btn');
    const originalText = submitBtn.querySelector('span').textContent;
    
    submitBtn.querySelector('span').textContent = 'Envoyé !';
    submitBtn.style.background = '#4CAF50';
    
    setTimeout(() => {
        submitBtn.querySelector('span').textContent = originalText;
        submitBtn.style.background = '#fff';
        
        // Réinitialiser le formulaire
        document.querySelector('.contact-form').reset();
    }, 2000);
});

// Effet de bruit sur les images de projet
document.querySelectorAll('.project-image').forEach(img => {
    img.addEventListener('mouseenter', () => {
        img.style.filter = 'brightness(1.1) contrast(1.1)';
    });
    
    img.addEventListener('mouseleave', () => {
        img.style.filter = 'none';
    });
});`
  }
};

export async function createAdvancedProject(projectId: number, projectType: string, description: string, language: string) {
  try {
    console.log(`Création d'un projet avancé: ${projectType} pour le projet ${projectId}`);
    
    // Déterminer le template à utiliser
    let template;
    if (description.toLowerCase().includes('portfolio') || description.toLowerCase().includes('créatif')) {
      template = modernWebTemplates.portfolio;
    } else {
      template = modernWebTemplates.business;
    }
    
    // Créer les fichiers
    const files = [
      {
        name: 'index.html',
        content: template.html,
        language: 'html'
      },
      {
        name: 'styles.css',
        content: template.css,
        language: 'css'
      },
      {
        name: 'script.js',
        content: template.js,
        language: 'javascript'
      }
    ];
    
    // Sauvegarder chaque fichier
    for (const file of files) {
      await storage.createFile({
        name: file.name,
        content: file.content,
        language: file.language,
        projectId: projectId
      });
    }
    
    console.log(`✅ Projet avancé créé avec ${files.length} fichiers pour le projet ${projectId}`);
    return true;
    
  } catch (error) {
    console.error('Erreur lors de la création du projet avancé:', error);
    return false;
  }
}

export function getArtisticTemplate(projectType: string, description: string) {
  // Analyser la description pour choisir le bon template
  const desc = description.toLowerCase();
  
  if (desc.includes('portfolio') || desc.includes('créatif') || desc.includes('artiste')) {
    return modernWebTemplates.portfolio;
  } else {
    return modernWebTemplates.business;
  }
}