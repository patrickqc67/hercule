import Anthropic from '@anthropic-ai/sdk';

// the newest Anthropic model is "claude-3-7-sonnet-20250219" which was released after your knowledge cutoff.
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

interface CodeGenerationResult {
  code: string;
  language: string;
}

export async function generateCodeWithAnthropic(
  prompt: string,
  language: string,
  existingCode: string = "",
  context: string = ""
): Promise<CodeGenerationResult> {
  try {
    console.log(`Génération de code avec Anthropic Claude pour le langage ${language}`);
    
    let systemPrompt = `You are Claude, Anthropic's AI assistant. Generate clean, functional ${language} code that follows modern best practices and conventions.

Focus on creating practical, well-structured solutions that meet the user's requirements.`;

    // Construire les messages pour la requête
    let messages = [];

    // Ajouter le contexte si fourni
    if (context) {
      messages.push({
        role: "user",
        content: `Additional context for this request: ${context}\n\nPlease keep this context in mind when generating the code.`
      });
    }

    // Ajouter le code existant s'il est fourni
    if (existingCode) {
      messages.push({
        role: "user",
        content: `The following code already exists in the project and should be considered or extended as appropriate:\n\n\`\`\`${language}\n${existingCode}\n\`\`\``
      });
    }

    // Ajouter la demande de l'utilisateur
    const userPrompt = `I need ${language} code for the following: ${prompt}. Only generate code, do not include explanations or commentary outside of code comments.`;
    
    // Créer la requête à l'API Anthropic
    const response = await anthropic.messages.create({
      model: "claude-3-7-sonnet-20250219",
      max_tokens: 4000,
      system: systemPrompt,
      messages: [
        ...messages.map(msg => ({
          role: msg.role as "user" | "assistant",
          content: msg.content
        })),
        { role: "user", content: userPrompt }
      ],
    });

    // Extraire le code généré
    const content = response.content[0].type === 'text' ? response.content[0].text : '';
    
    // Nettoyer le code (supprimer les délimiteurs de bloc de code Markdown)
    let code = content;
    
    // Si le code est dans un bloc Markdown, l'extraire
    const codeBlockRegex = /```(?:\w+)?\s*([\s\S]+?)\s*```/;
    const match = content.match(codeBlockRegex);
    if (match) {
      code = match[1];
    }

    console.log("Code généré avec succès via Anthropic Claude");
    
    // Renvoyer le résultat
    return {
      code,
      language
    };
  } catch (error: any) {
    console.error("Erreur lors de la génération de code avec Anthropic:", error);
    throw new Error(`Erreur Anthropic: ${error.message || 'Erreur inconnue'}`);
  }
}