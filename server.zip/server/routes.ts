import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
// import { executeCode } from "./code-execution"; // Remplacé par Judge0
import { 
  analyzeCode, 
  generateCode, 
  fixCode, 
  generateComplexArchitecture,
  generateTests,
  optimizeCode,
  generateDocumentation,
  explainCode
} from "./ai";
import { generateCodeWithAnthropic } from "./anthropic";
import OpenAI from 'openai';
import { generateCodeWithOpenAI } from "./openai";
import { generateCodeWithXAI, analyzeCodeWithXAI, fixCodeWithXAI } from "./xai";
import { ReplitAgent } from "./replit-agent";
import { previewServerManager } from "./preview-server-new";
import phantomRoutes from "./routes-phantom";
import { codeExecutor } from "./code-executor";
import { createAdvancedProject } from "./project-generator";
import { z } from "zod";
import { setupAuth, isAuthenticated } from "./auth";
import { WebSocketServer } from "ws";

// Fonction pour parser les chemins de fichiers et séparer le chemin du nom
function parseFilePath(fullPath: string): { fileName: string; filePath: string } {
  if (fullPath.includes('/')) {
    const lastSlashIndex = fullPath.lastIndexOf('/');
    const filePath = fullPath.substring(0, lastSlashIndex + 1); // Inclut le "/" final
    const fileName = fullPath.substring(lastSlashIndex + 1);
    return { fileName, filePath };
  }
  return { fileName: fullPath, filePath: '' };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configuration de l'authentification
  setupAuth(app);

  // Route d'authentification admin temporaire
  app.post('/api/admin-login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // Vérification des identifiants admin temporaires
      if (username === 'admin' && password === 'zigZAG$$$') {
        // Créer une session admin temporaire
        (req.session as any).adminAuthenticated = true;
        (req.session as any).tempAdmin = { username: 'admin', role: 'admin' };
        
        res.json({ 
          success: true, 
          message: 'Connexion administrateur réussie',
          user: { username: 'admin', role: 'admin' }
        });
      } else {
        res.status(401).json({ 
          success: false, 
          message: 'Identifiants administrateur incorrects' 
        });
      }
    } catch (error) {
      console.error('Erreur lors de la connexion admin:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Erreur interne du serveur' 
      });
    }
  });

  // Route pour vérifier l'authentification admin
  app.get('/api/admin/check', async (req, res) => {
    try {
      if ((req.session as any).adminAuthenticated && (req.session as any).tempAdmin) {
        res.json({ 
          authenticated: true, 
          user: (req.session as any).tempAdmin 
        });
      } else {
        res.status(401).json({ authenticated: false });
      }
    } catch (error) {
      res.status(500).json({ authenticated: false, message: 'Erreur serveur' });
    }
  });

  // Middleware pour vérifier l'authentification admin temporaire
  const requireTempAdmin = (req: any, res: any, next: any) => {
    if (req.session.adminAuthenticated && req.session.tempAdmin) {
      return next();
    }
    res.status(401).json({ message: 'Accès administrateur requis' });
  };

  // Project routes avec authentification
  app.get("/api/projects", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any)?.id;
      if (!userId) {
        return res.status(401).json({ message: "Utilisateur non authentifié" });
      }
      
      const projects = await storage.getProjectsByUserId(userId);
      res.json(projects);
    } catch (error) {
      console.error("Erreur lors de la récupération des projets:", error);
      const message = error instanceof Error ? error.message : "Une erreur est survenue";
      res.status(400).json({ message });
    }
  });
  
  // Route pour récupérer un projet spécifique
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const project = await storage.getProject(id);
      
      if (!project) {
        return res.status(404).json({ message: "Projet non trouvé" });
      }
      
      res.json(project);
    } catch (error) {
      console.error("Erreur lors de la récupération du projet:", error);
      const message = error instanceof Error ? error.message : "Une erreur est survenue";
      res.status(400).json({ message });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const { name, description, language } = req.body;
      
      // Validation des données requises
      if (!name || name.trim() === '') {
        return res.status(400).json({ message: "Le nom du projet est requis" });
      }
      
      const projectData = {
        name: name.trim(),
        description: description || '',
        language: language || 'html',
        userId: 5 // Utilisateur test connecté
      };
      
      console.log("Création projet avec données:", projectData);
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      console.error("Erreur création projet:", error);
      const message = error instanceof Error ? error.message : "Une erreur est survenue";
      res.status(400).json({ message });
    }
  });

  // Route d'importation de projet
  app.post("/api/projects/import", async (req, res) => {
    try {
      const { name, description, files, language } = req.body;
      
      // Validation des données requises
      if (!name || name.trim() === '') {
        return res.status(400).json({ message: "Le nom du projet est requis" });
      }
      
      if (!files || !Array.isArray(files)) {
        return res.status(400).json({ message: "Les fichiers du projet sont requis" });
      }
      
      // Créer le projet
      const projectData = {
        name: name.trim(),
        description: description || '',
        language: language || 'html',
        userId: 5 // Utilisateur test connecté
      };
      
      console.log("Importation projet avec données:", projectData);
      const project = await storage.createProject(projectData);
      
      // Créer les fichiers associés
      const createdFiles = [];
      for (let i = 0; i < files.length; i++) {
        const fileData = files[i];
        const file = await storage.createFile({
          name: fileData.name,
          path: fileData.path || '/',
          content: fileData.content || '',
          language: fileData.language || language || 'html',
          projectId: project.id,
          isMain: i === 0 // Le premier fichier est marqué comme principal
        });
        createdFiles.push(file);
      }
      
      res.json({
        project,
        files: createdFiles
      });
      
    } catch (error) {
      console.error("Erreur importation projet:", error);
      const message = error instanceof Error ? error.message : "Une erreur est survenue";
      res.status(400).json({ message });
    }
  });

  // File routes
  app.get("/api/files", async (req, res) => {
    try {
      const projectIdStr = req.query.projectId as string;
      
      if (!projectIdStr) {
        return res.status(400).json({ message: "Project ID requis" });
      }
      
      const projectId = parseInt(projectIdStr);
      
      if (isNaN(projectId)) {
        return res.status(400).json({ message: "Project ID invalide" });
      }
      
      const files = await storage.getFilesByProjectId(projectId);
      res.json(files);
    } catch (error) {
      console.error("Erreur récupération fichiers:", error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  app.post("/api/files", async (req, res) => {
    try {
      const fileData = req.body;
      const file = await storage.createFile(fileData);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  app.put("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const fileData = req.body;
      const file = await storage.updateFile(id, fileData);
      res.json(file);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });
  
  // Route pour supprimer un fichier
  app.delete("/api/files/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteFile(id);
      if (success) {
        res.json({ success: true, message: "Fichier supprimé avec succès" });
      } else {
        res.status(404).json({ success: false, message: "Fichier non trouvé" });
      }
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue lors de la suppression du fichier" });
    }
  });

  // Version routes
  app.get("/api/versions", async (req, res) => {
    try {
      const fileId = parseInt(req.query.fileId as string);
      const versions = await storage.getVersionsByFileId(fileId);
      res.json(versions);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  app.post("/api/versions", async (req, res) => {
    try {
      const versionData = req.body;
      const version = await storage.createVersion(versionData);
      res.json(version);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  // AI route for project planning with real-time steps
  // Route pour que l'agent sauvegarde automatiquement ses fichiers dans le projet
  app.post("/api/ai/save-project-files", async (req, res) => {
    try {
      const { projectId, files } = req.body;
      
      if (!projectId || !files || !Array.isArray(files)) {
        return res.status(400).json({ message: "projectId et files sont requis" });
      }
      
      const savedFiles = [];
      
      for (const fileData of files) {
        const { name, content, language } = fileData;
        
        // Créer le fichier dans la base de données
        const newFile = await storage.createFile({
          name,
          content,
          language: language || 'html',
          projectId: parseInt(projectId)
        });
        
        savedFiles.push(newFile);
      }
      
      res.json({ 
        message: `${savedFiles.length} fichiers sauvegardés avec succès`,
        files: savedFiles 
      });
    } catch (error) {
      console.error("Erreur lors de la sauvegarde des fichiers:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Erreur serveur" });
    }
  });

  // Route supprimée - plus de planification automatique
  // Les agents travaillent directement avec leur propre logique

  // Code execution route - Judge0 intégré directement
  app.post("/api/execute", async (req, res) => {
    try {
      const { code, language, input } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ 
          error: 'Code et langage requis' 
        });
      }

      if (codeExecutor.isLanguageSupported(language)) {
        const result = await codeExecutor.executeCode(code, language, input);
        res.json(result);
      } else {
        res.status(400).json({ 
          error: 'Langage non supporté',
          supportedLanguages: codeExecutor.getSupportedLanguages()
        });
      }
    } catch (error) {
      console.error('Erreur exécution code:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Erreur d\'exécution'
      });
    }
  });

  // Preview server routes (intégré sur le même port)
  app.post("/api/preview/start/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const files = await storage.getFilesByProjectId(projectId);
      
      if (files.length === 0) {
        return res.status(400).json({ message: "Aucun fichier trouvé pour ce projet" });
      }
      
      // Utiliser l'URL de preview intégrée sur le même port (5000)
      const previewUrl = `http://localhost:5000/preview/${projectId}`;
      
      res.json({ previewUrl });
    } catch (error) {
      console.error("Erreur lors du démarrage du serveur de preview:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Erreur serveur" });
    }
  });

  app.post("/api/preview/update/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      // Pas besoin de mise à jour spéciale avec le preview intégré
      res.json({ success: true });
    } catch (error) {
      console.error("Erreur lors de la mise à jour du preview:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Erreur serveur" });
    }
  });

  app.delete("/api/preview/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      // Pas besoin d'arrêt spécial avec le preview intégré
      res.json({ success: true });
    } catch (error) {
      console.error("Erreur lors de l'arrêt du serveur de preview:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Erreur serveur" });
    }
  });

  app.get("/api/preview/url/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const previewUrl = `http://localhost:5000/preview/${projectId}`;
      res.json({ previewUrl });
    } catch (error) {
      console.error("Erreur lors de la récupération de l'URL de preview:", error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Erreur serveur" });
    }
  });

  // Route pour servir le preview intégré
  app.get("/preview/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const files = await storage.getFilesByProjectId(projectId);
      
      // Chercher le fichier index.html ou le premier fichier HTML
      let htmlFile = files.find(f => f.name === 'index.html');
      if (!htmlFile) {
        htmlFile = files.find(f => f.name.endsWith('.html'));
      }
      
      if (!htmlFile) {
        return res.status(404).send(`
          <html>
            <head><title>Preview - Projet ${projectId}</title></head>
            <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
              <h1>🔍 Aucun fichier HTML trouvé</h1>
              <p>Ce projet ne contient pas de fichier HTML à prévisualiser.</p>
              <p>Créez un fichier index.html pour voir le preview.</p>
            </body>
          </html>
        `);
      }
      
      // Retourner le contenu HTML avec les autres fichiers injectés
      let htmlContent = htmlFile.content;
      
      // Nettoyer le contenu s'il contient des blocs de code
      if (htmlContent.includes('```html')) {
        htmlContent = htmlContent.replace(/```html\s*\n?/, '').replace(/\n?```$/, '');
      } else if (htmlContent.includes('```')) {
        htmlContent = htmlContent.replace(/```[a-z]*\s*\n?/, '').replace(/\n?```$/, '');
      }
      
      // Injecter les fichiers CSS et JS dans le HTML
      const cssFiles = files.filter(f => f.name.endsWith('.css'));
      const jsFiles = files.filter(f => f.name.endsWith('.js'));
      
      let cssInject = '';
      cssFiles.forEach(file => {
        let cssContent = file.content;
        if (cssContent.includes('```css')) {
          cssContent = cssContent.replace(/```css\s*\n?/, '').replace(/\n?```$/, '');
        } else if (cssContent.includes('```')) {
          cssContent = cssContent.replace(/```[a-z]*\s*\n?/, '').replace(/\n?```$/, '');
        }
        cssInject += `<style>${cssContent}</style>\n`;
      });
      
      let jsInject = '';
      jsFiles.forEach(file => {
        let jsContent = file.content;
        if (jsContent.includes('```javascript') || jsContent.includes('```js')) {
          jsContent = jsContent.replace(/```(javascript|js)\s*\n?/, '').replace(/\n?```$/, '');
        } else if (jsContent.includes('```')) {
          jsContent = jsContent.replace(/```[a-z]*\s*\n?/, '').replace(/\n?```$/, '');
        }
        jsInject += `<script>${jsContent}</script>\n`;
      });
      
      // Injecter dans le HTML
      if (htmlContent.includes('</head>')) {
        htmlContent = htmlContent.replace('</head>', `${cssInject}</head>`);
      } else if (cssInject) {
        htmlContent = `<head>${cssInject}</head>` + htmlContent;
      }
      
      if (htmlContent.includes('</body>')) {
        htmlContent = htmlContent.replace('</body>', `${jsInject}</body>`);
      } else if (jsInject) {
        htmlContent = htmlContent + jsInject;
      }
      
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(htmlContent.trim());
    } catch (error) {
      console.error("Erreur du serveur de preview:", error);
      res.status(500).send(`
        <html>
          <head><title>Erreur Preview</title></head>
          <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
            <h1>❌ Erreur du serveur de preview</h1>
            <p>Une erreur est survenue lors du chargement du preview.</p>
            <pre style="background: #f5f5f5; padding: 20px; border-radius: 5px;">${error instanceof Error ? error.message : 'Erreur inconnue'}</pre>
          </body>
        </html>
      `);
    }
  });

  // AI routes
  app.post("/api/ai/analyze", async (req, res) => {
    try {
      const { code, language, projectContext, agent } = req.body;
      let analysis;
      
      if (agent === 'replit') {
        const { analyzeCodeWithXAI } = await import('./xai');
        analysis = await analyzeCodeWithXAI(code, language, projectContext);
      } else if (agent === 'chatgpt') {
        const { analyzeCodeWithOpenAI } = await import('./openai');
        analysis = await analyzeCodeWithOpenAI(code, language, projectContext);
      } else {
        analysis = await analyzeCode(code, language, projectContext);
      }
      
      res.json(analysis);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  app.post("/api/ai/generate", async (req, res) => {
    try {
      const { prompt, language, existingCode, context, agent } = req.body;
      console.log(`Génération de code avec ${agent || 'default'} pour le langage: ${language}`);
      
      let result;
      
      // Utiliser l'API appropriée en fonction de l'agent sélectionné
      if (agent === 'codephantom') {
        // Utiliser CodePhantom avec analyse multi-fichier
        const { PhantomIntegration } = await import('./phantom-integration');
        const phantom = new PhantomIntegration((message) => {
          // Messages de streaming gérés par SSE
        });
        
        // Récupérer tous les fichiers du projet pour l'analyse
        const files = req.body.projectId ? await storage.getFilesByProjectId(req.body.projectId) : [];
        
        result = await phantom.generateAdvanced(prompt, language, req.body.projectId || 0, {
          existingCode,
          context,
          files
        });
      } else if (agent === 'anthropic') {
        // Utiliser l'API Anthropic Claude
        result = await generateCodeWithAnthropic(prompt, language, existingCode, context);
      } else if (agent === 'replit') {
        // Utiliser l'API xAI Grok pour l'agent Replit
        result = await generateCodeWithXAI(prompt, language, existingCode, context);
      } else if (agent === 'chatgpt') {
        // Utiliser l'API OpenAI ChatGPT
        const { generateCodeWithOpenAI } = await import('./openai');
        result = await generateCodeWithOpenAI(prompt, language, existingCode, context);
      } else {
        // Utiliser l'API OpenAI par défaut pour les autres agents
        result = await generateCode(prompt, language, existingCode, context, agent);
      }
      



      // Créer automatiquement plusieurs fichiers si le code contient une structure complète
      const autoCreateFiles = async (codeResponse: string, projectId: number, isModification = false) => {
        console.log("Auto-création - Analyse du code reçu, longueur:", codeResponse.length);
        console.log("Mode modification:", isModification);
        
        // Si c'est un fichier HTML complet, on l'analyse pour extraire CSS et JS
        if (codeResponse.includes('<!DOCTYPE html') || codeResponse.includes('<html')) {
          console.log("Auto-création - Détection d'un fichier HTML complet, extraction des parties...");
          
          const existingFiles = await storage.getFilesByProjectId(projectId);
          
          // Si c'est une modification, on met à jour directement le fichier HTML principal
          if (isModification && existingFiles.length > 0) {
            const mainHtmlFile = existingFiles.find(f => f.name === 'index.html' || f.name.endsWith('.html'));
            if (mainHtmlFile) {
              await storage.updateFile(mainHtmlFile.id, { content: codeResponse });
              console.log(`Modification - Fichier HTML mis à jour: ${mainHtmlFile.name}`);
              return true;
            }
          }
          
          // Sinon, procéder à l'extraction normale
          // Extraire le CSS inline
          const cssMatch = codeResponse.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
          const cssContent = cssMatch ? cssMatch[1].trim() : '';
          
          // Extraire le JavaScript inline
          const jsMatch = codeResponse.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
          const jsContent = jsMatch ? jsMatch[1].trim() : '';
          
          // Créer le HTML principal sans les styles et scripts inline
          let htmlContent = codeResponse;
          if (cssContent) {
            htmlContent = htmlContent.replace(/<style[^>]*>[\s\S]*?<\/style>/i, 
              '    <link rel="stylesheet" href="styles.css">');
          }
          if (jsContent) {
            htmlContent = htmlContent.replace(/<script[^>]*>[\s\S]*?<\/script>/i, 
              '    <script src="script.js"></script>');
          }
          
          const extractedFiles = [
            { name: 'index.html', content: htmlContent.trim(), language: 'html' }
          ];
          
          if (cssContent && cssContent.length > 50) {
            extractedFiles.push({ name: 'styles.css', content: cssContent, language: 'css' });
            console.log("Auto-création - CSS extrait, longueur:", cssContent.length);
          }
          
          if (jsContent && jsContent.length > 20) {
            extractedFiles.push({ name: 'script.js', content: jsContent, language: 'javascript' });
            console.log("Auto-création - JavaScript extrait, longueur:", jsContent.length);
          }
          
          if (extractedFiles.length > 0) {
            console.log(`Auto-création - Traitement de ${extractedFiles.length} fichier(s) séparé(s)`);
            for (const file of extractedFiles) {
              try {
                const existingFile = existingFiles.find(f => f.name === file.name);
                
                if (existingFile) {
                  await storage.updateFile(existingFile.id, { content: file.content });
                  console.log(`Fichier mis à jour: ${file.name}`);
                } else {
                  // Analyser le nom pour séparer le chemin du nom de fichier
                  const { fileName, filePath } = parseFilePath(file.name);
                  await storage.createFile({
                    name: fileName,
                    path: filePath,
                    content: file.content,
                    language: file.language,
                    projectId: projectId
                  });
                  console.log(`Nouveau fichier créé: ${fileName}`);
                }
              } catch (error) {
                console.error(`Erreur traitement fichier ${file.name}:`, error);
              }
            }
            return true;
          }
        }
        
        // Patterns pour codes avec délimiteurs markdown
        const filePatterns = [
          { pattern: /```html\n([\s\S]*?)```/gi, name: 'index.html', language: 'html' },
          { pattern: /```css\n([\s\S]*?)```/gi, name: 'styles.css', language: 'css' },
          { pattern: /```javascript\n([\s\S]*?)```/gi, name: 'script.js', language: 'javascript' },
          { pattern: /```js\n([\s\S]*?)```/gi, name: 'app.js', language: 'javascript' },
          { pattern: /```json\n([\s\S]*?)```/gi, name: 'package.json', language: 'json' },
          { pattern: /```jsx\n([\s\S]*?)```/gi, name: 'App.jsx', language: 'javascript' },
          { pattern: /```tsx\n([\s\S]*?)```/gi, name: 'App.tsx', language: 'typescript' }
        ];
        
        const extractedFiles: { name: string; content: string; language: string; path?: string }[] = [];
        
        filePatterns.forEach(({ pattern, name, language }) => {
          let match;
          while ((match = pattern.exec(codeResponse)) !== null) {
            const content = match[1].trim();
            if (content.length > 50) {
              const { fileName, filePath } = parseFilePath(name);
              extractedFiles.push({ 
                name: fileName, 
                path: filePath,
                content, 
                language 
              });
            }
          }
        });
        
        if (extractedFiles.length > 0) {
          console.log(`Auto-création - Traitement de ${extractedFiles.length} fichier(s)`);
          for (const file of extractedFiles) {
            try {
              const existingFiles = await storage.getFilesByProjectId(projectId);
              const existingFile = existingFiles.find(f => f.name === file.name);
              
              if (existingFile) {
                await storage.updateFile(existingFile.id, { content: file.content });
                console.log(`Fichier mis à jour: ${file.name}`);
              } else {
                await storage.createFile({
                  name: file.name,
                  content: file.content,
                  language: file.language,
                  projectId: projectId
                });
                console.log(`Nouveau fichier créé: ${file.name}`);
              }
            } catch (error) {
              console.error(`Erreur traitement fichier ${file.name}:`, error);
            }
          }
          return true;
        }
        return false;
      };

      // Extraire le projectId de la session ou de l'en-tête
      const projectId = req.body.projectId || (req as any).session?.activeProjectId;
      console.log("ProjectId détecté:", projectId, "Type:", typeof projectId);
      const generatedCode = typeof result === 'string' ? result : result.code;
      console.log("Code généré contient:", generatedCode ? "Oui" : "Non");
      
      if (projectId && generatedCode) {
        console.log("Tentative de création automatique de fichiers...");
        const filesCreated = await autoCreateFiles(generatedCode, parseInt(projectId));
        console.log("Fichiers créés automatiquement:", filesCreated);
      } else {
        console.log("Pas de création automatique - projectId:", projectId, "code:", !!generatedCode);
      }

      // Post-traitement pour le HTML
      if (language === "html") {
        let processedCode = generatedCode;
        
        // Nettoyer le code de la syntaxe Markdown
        processedCode = processedCode.replace(/```html\s*/, '').replace(/\s*```\s*$/, '');
        
        // Vérifier si le HTML contient un <style> complet ou fait référence à des feuilles de style externes
        if (!processedCode.includes('<style>') || processedCode.includes('<link rel="stylesheet"') || processedCode.includes('<link href=')) {
          console.log("Détection de liens CSS externes ou absence de style, application du post-traitement...");
          
          // Extraire le contenu du corps et le script JavaScript s'il existe
          let bodyContent = "";
          let scriptContent = "";
          
          // Extraire le script
          const scriptMatch = processedCode.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
          if (scriptMatch && scriptMatch[0]) {
            scriptContent = scriptMatch[0];
          }
          
          // Extraire le corps
          const bodyMatch = processedCode.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
          
          if (bodyMatch && bodyMatch[1]) {
            bodyContent = bodyMatch[1].trim();
            
            // Si le script a été trouvé dans le bodyContent, le supprimer pour l'ajouter manuellement à la fin
            if (scriptContent && bodyContent.includes(scriptContent)) {
              bodyContent = bodyContent.replace(scriptContent, '');
            }
          } else {
            // Si pas de balise body, prendre tout le contenu
            bodyContent = processedCode.includes('<html') ? 
              processedCode.replace(/<html[^>]*>|<\/html>|<!DOCTYPE[^>]*>|<head>[\s\S]*?<\/head>|<body[^>]*>|<\/body>/gi, '') : 
              processedCode;
              
            // Si le script a été trouvé dans le bodyContent, le supprimer pour l'ajouter manuellement à la fin
            if (scriptContent && bodyContent.includes(scriptContent)) {
              bodyContent = bodyContent.replace(scriptContent, '');
            }
          }
          
          // Créer un nouveau HTML avec des styles directement inspirés de l'exemple fourni
          processedCode = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${prompt.length > 30 ? prompt.substring(0, 30) + '...' : prompt}</title>
    <style>
        /* Minimal CSS reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background: #333;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }

        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        nav ul li {
            margin: 0 1rem;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 1rem;
        }

        .product {
            border: 1px solid #ccc;
            background: #fff;
            margin-bottom: 1rem;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .product img {
            max-width: 150px;
            margin-right: 1rem;
        }

        .product-info {
            flex: 1;
        }

        .product-price {
            font-size: 1.2rem;
            font-weight: bold;
        }

        footer {
            background: #333;
            color: #fff;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        
        /* Styles additionnels pour le produit de beauté */
        main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        section {
            margin-bottom: 30px;
        }
        
        .product-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            text-align: center;
            cursor: pointer;
            border-radius: 4px;
        }
        
        button:hover {
            background-color: #45a049;
        }
        
        h2 {
            margin-bottom: 20px;
        }
        
        h3 {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    ${bodyContent}
</body>
</html>`;

          // Retourner le code traité
          if (typeof result === 'string') {
            return res.json({ code: processedCode });
          } else {
            result.code = processedCode;
          }
        }
      }
      
      // Retourner le résultat final
      if (typeof result === 'string') {
        res.json({ code: result });
      } else {
        res.json(result);
      }
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  // Route pour le streaming de l'agent Replit
  // Fonction pour détecter automatiquement le meilleur langage
  function detectOptimalLanguage(prompt: string): string {
    const lowerPrompt = prompt.toLowerCase();
    
    // Site web/interface utilisateur - Priorisation maximale pour HTML
    if (lowerPrompt.includes('site') || lowerPrompt.includes('page') || 
        lowerPrompt.includes('boutique') || lowerPrompt.includes('html') ||
        lowerPrompt.includes('interface') || lowerPrompt.includes('frontend') ||
        lowerPrompt.includes('landing') || lowerPrompt.includes('design') ||
        lowerPrompt.includes('moderne') || lowerPrompt.includes('portfolio') ||
        lowerPrompt.includes('blog') || lowerPrompt.includes('dashboard') ||
        lowerPrompt.includes('fitness') || lowerPrompt.includes('hero') ||
        lowerPrompt.includes('section') || lowerPrompt.includes('responsive') ||
        lowerPrompt.includes('web') || lowerPrompt.includes('css')) {
      return 'html';
    }
    
    // API/Backend
    if (lowerPrompt.includes('api') || lowerPrompt.includes('serveur') || 
        lowerPrompt.includes('backend') || lowerPrompt.includes('base de données')) {
      return 'python'; // Flask/FastAPI par défaut
    }
    
    // Applications de bureau
    if (lowerPrompt.includes('application') || lowerPrompt.includes('desktop') ||
        lowerPrompt.includes('gui')) {
      return 'python'; // Tkinter/PyQt
    }
    
    // Analyse de données
    if (lowerPrompt.includes('données') || lowerPrompt.includes('analyse') ||
        lowerPrompt.includes('graphique') || lowerPrompt.includes('statistique')) {
      return 'python'; // pandas/matplotlib
    }
    
    // Jeux
    if (lowerPrompt.includes('jeu') || lowerPrompt.includes('game')) {
      return 'javascript'; // Phaser.js ou Python pygame
    }
    
    // Mobile
    if (lowerPrompt.includes('mobile') || lowerPrompt.includes('android') ||
        lowerPrompt.includes('ios')) {
      return 'javascript'; // React Native
    }
    
    // Scripts/automation
    if (lowerPrompt.includes('script') || lowerPrompt.includes('automatiser') ||
        lowerPrompt.includes('automation')) {
      return 'python';
    }
    
    // Par défaut: HTML pour les demandes générales
    return 'html';
  }

  app.post("/api/ai/generate-streaming", async (req, res) => {
    try {
      const { prompt, language, existingCode, context, agent, designStyle = 'ultra-modern', theme, template } = req.body;
      
      // Détection automatique du langage si non spécifié ou si 'auto'
      const finalLanguage = (!language || language === 'auto' || language === 'html') ? 
                           detectOptimalLanguage(prompt) : language;
      
      // Détecter si c'est une modification ou un nouveau projet
      const isModification = existingCode && existingCode.trim().length > 0;
      console.log(`Agent autonome: ${prompt.substring(0, 50)}... → Langage: ${finalLanguage}, Modification: ${isModification}`);
      
      if (agent !== 'replit' && agent !== 'codephantom') {
        return res.status(400).json({ message: "Le streaming n'est pas supporté pour cet agent" });
      }

      // Configuration des headers pour le streaming
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Cache-Control'
      });

      let result;
      
      if (agent === 'codephantom') {
        // Utiliser CodePhantom avec streaming avancé
        const { PhantomIntegration } = await import('./phantom-integration');
        const phantom = new PhantomIntegration((message) => {
          res.write(`data: ${JSON.stringify(message)}\n\n`);
        });
        
        // Récupérer tous les fichiers du projet pour l'analyse
        const files = req.body.projectId ? await storage.getFilesByProjectId(req.body.projectId) : [];
        
        result = await phantom.generateAdvanced(prompt, finalLanguage, req.body.projectId || 0, {
          existingCode,
          context,
          files
        });
      } else {
        // Agent Replit avec streaming standard
        const replitAgent = new ReplitAgent((message) => {
          res.write(`data: ${JSON.stringify(message)}\n\n`);
        });

        // Configurer le style de design et thème avant la génération
        if (designStyle) {
          replitAgent.setDesignStyle(designStyle);
        }
        if (theme) {
          replitAgent.setTheme(theme);
        }
        if (template) {
          replitAgent.setTemplate(template);
        }

        result = await replitAgent.generateCode(prompt, finalLanguage, existingCode);
      }
      
      // Créer automatiquement plusieurs fichiers si le code contient une structure complète
      const projectId = req.body.projectId;
      console.log("Streaming - ProjectId détecté:", projectId);
      console.log("Streaming - Type de result:", typeof result, result);
      
      if (projectId && result) {
        console.log("Streaming - Tentative de création automatique de fichiers...");
        const autoCreateFiles = async (codeResponse: string, projectId: number, isModification = false) => {
          console.log("Streaming - Analyse du code reçu, longueur:", codeResponse.length);
          console.log("Streaming - Mode modification:", isModification);
          console.log("Streaming - Extrait du code:", codeResponse.substring(0, 500));
          
          // Si c'est un fichier HTML complet, on l'analyse pour extraire CSS et JS
          if (codeResponse.includes('<!DOCTYPE html') || codeResponse.includes('<html')) {
            console.log("Streaming - Détection d'un fichier HTML complet, extraction des parties...");
            
            // Extraire uniquement le code HTML, pas les explications
            const htmlMatch = codeResponse.match(/```html\s*([\s\S]*?)\s*```|<!DOCTYPE html[\s\S]*?<\/html>/i);
            const pureHtmlCode = htmlMatch ? (htmlMatch[1] || htmlMatch[0]).trim() : codeResponse;
            
            // Extraire le CSS inline
            const cssMatch = pureHtmlCode.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
            const cssContent = cssMatch ? cssMatch[1].trim() : '';
            
            // Extraire le JavaScript inline
            const jsMatch = pureHtmlCode.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
            const jsContent = jsMatch ? jsMatch[1].trim() : '';
            
            // Créer le HTML principal sans les styles et scripts inline
            let htmlContent = pureHtmlCode;
            if (cssContent) {
              htmlContent = htmlContent.replace(/<style[^>]*>[\s\S]*?<\/style>/i, 
                '    <link rel="stylesheet" href="styles.css">');
            }
            if (jsContent) {
              htmlContent = htmlContent.replace(/<script[^>]*>[\s\S]*?<\/script>/i, 
                '    <script src="script.js"></script>');
            }
            
            const extractedFiles = [
              { name: 'index.html', content: htmlContent.trim(), language: 'html' }
            ];
            
            if (cssContent && cssContent.length > 50) {
              extractedFiles.push({ name: 'styles.css', content: cssContent, language: 'css' });
              console.log("Streaming - CSS extrait, longueur:", cssContent.length);
            }
            
            if (jsContent && jsContent.length > 20) {
              extractedFiles.push({ name: 'script.js', content: jsContent, language: 'javascript' });
              console.log("Streaming - JavaScript extrait, longueur:", jsContent.length);
            }
            
            if (extractedFiles.length > 1) {
              console.log(`Streaming - Création de ${extractedFiles.length} fichiers séparés`);
              for (const file of extractedFiles) {
                try {
                  const existingFiles = await storage.getFilesByProjectId(projectId);
                  const existingFile = existingFiles.find(f => f.name === file.name);
                  
                  if (existingFile) {
                    await storage.updateFile(existingFile.id, { content: file.content });
                    console.log(`Streaming - Fichier mis à jour: ${file.name}`);
                  } else {
                    await storage.createFile({
                      name: file.name,
                      content: file.content,
                      language: file.language,
                      projectId: projectId
                    });
                    console.log(`Streaming - Nouveau fichier créé: ${file.name}`);
                  }
                } catch (error) {
                  console.error(`Streaming - Erreur création fichier ${file.name}:`, error);
                }
              }
              return true;
            }
          }
          
          // Fonction pour détecter le nom de fichier intelligent basé sur le contenu
          const getSmartFilename = (content: string, language: string, existingFiles: string[]): string => {
            const lowerContent = content.toLowerCase();
            
            // Structure organisée par dossiers comme Replit.com
            if (language === 'html') {
              // Pages spécifiques identifiées par contenu
              if (lowerContent.includes('admin') || lowerContent.includes('administration')) {
                return 'admin.html';
              }
              if (lowerContent.includes('membre') || lowerContent.includes('member') || lowerContent.includes('profil')) {
                return 'member.html';
              }
              if (lowerContent.includes('contact') || lowerContent.includes('contactez')) {
                return 'contact.html';
              }
              if (lowerContent.includes('boutique') || (lowerContent.includes('produit') && !lowerContent.includes('accueil'))) {
                return 'boutique.html';
              }
              if (lowerContent.includes('portfolio')) {
                return 'portfolio.html';
              }
              if (lowerContent.includes('rejoindre') || lowerContent.includes('communau')) {
                return 'rejoindre.html';
              }
              if (lowerContent.includes('panier') || lowerContent.includes('cart')) {
                return 'panier.html';
              }
              if (lowerContent.includes('calendrier') || lowerContent.includes('rendez-vous')) {
                return 'calendrier.html';
              }
              
              // Si c'est le fichier principal ou contient "accueil"
              if (lowerContent.includes('accueil') || lowerContent.includes('bienvenue') || !existingFiles.includes('index.html')) {
                return 'index.html';
              }
              
              // Nom par défaut pour pages supplémentaires
              return `pages/page${existingFiles.filter(f => f.includes('page')).length + 1}.html`;
            }
            
            // Structure pour autres types de fichiers - niveau racine
            if (language === 'css') {
              if (lowerContent.includes('bootstrap') || lowerContent.includes('framework')) {
                return 'framework.css';
              }
              return existingFiles.includes('styles.css') ? 'custom.css' : 'styles.css';
            }
            
            if (language === 'javascript') {
              if (lowerContent.includes('jquery') || lowerContent.includes('$')) {
                return 'jquery.js';
              }
              if (lowerContent.includes('app') || lowerContent.includes('application')) {
                return 'app.js';
              }
              return existingFiles.includes('script.js') ? 'main.js' : 'script.js';
            }
            
            if (language === 'json') {
              if (lowerContent.includes('package') || lowerContent.includes('dependencies')) {
                return 'package.json';
              }
              return 'config.json';
            }
            
            if (language === 'python') {
              if (lowerContent.includes('app') || lowerContent.includes('flask') || lowerContent.includes('django')) {
                return 'app.py';
              }
              return 'main.py';
            }
            
            return `file.${language}`;
          };

          // Patterns améliorés pour détecter tous les types de fichiers
          const filePatterns = [
            // Patterns avec noms explicites
            { pattern: /```html:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'html' },
            { pattern: /```css:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'css' },
            { pattern: /```javascript:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'javascript' },
            { pattern: /```js:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'javascript' },
            { pattern: /```python:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'python' },
            { pattern: /```json:([^\n\r]+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'json' },
            
            // Patterns standards avec nommage intelligent
            { pattern: /```html\n([\s\S]*?)```/gi, name: null, language: 'html' },
            { pattern: /```css\n([\s\S]*?)```/gi, name: null, language: 'css' },
            { pattern: /```javascript\n([\s\S]*?)```/gi, name: null, language: 'javascript' },
            { pattern: /```js\n([\s\S]*?)```/gi, name: null, language: 'javascript' },
            { pattern: /```python\n([\s\S]*?)```/gi, name: null, language: 'python' },
            { pattern: /```py\n([\s\S]*?)```/gi, name: null, language: 'python' },
            { pattern: /```json\n([\s\S]*?)```/gi, name: null, language: 'json' },
            { pattern: /```jsx\n([\s\S]*?)```/gi, name: null, language: 'javascript' },
            { pattern: /```tsx\n([\s\S]*?)```/gi, name: null, language: 'typescript' },
            
            // Patterns pour détecter les titres de fichiers dans le texte
            { pattern: /#### `([^`]+)`\s*```(\w+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'auto' },
            { pattern: /### `([^`]+)`\s*```(\w+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'auto' },
            { pattern: /## `([^`]+)`\s*```(\w+)\n([\s\S]*?)```/gi, nameFromMatch: true, language: 'auto' }
          ];
          
          // Obtenir les fichiers existants pour éviter les doublons
          const existingFiles = await storage.getFilesByProjectId(projectId);
          const existingFileNames = existingFiles.map(f => f.name);
          
          const extractedFiles: { name: string; content: string; language: string }[] = [];
          const processedContents = new Set<string>(); // Pour éviter les doublons de contenu
          
          filePatterns.forEach((pattern: any) => {
            let match;
            while ((match = pattern.pattern.exec(codeResponse)) !== null) {
              let content: string;
              let fileName: string;
              let detectedLanguage: string;
              
              if (pattern.nameFromMatch) {
                if (pattern.language === 'auto') {
                  fileName = match[1].trim();
                  detectedLanguage = match[2] || 'text';
                  content = match[3].trim();
                } else {
                  fileName = match[1].trim();
                  content = match[2].trim();
                  detectedLanguage = pattern.language;
                }
              } else {
                content = match[1].trim();
                detectedLanguage = pattern.language;
                // Generate smart filename based on content and language
                const baseFilename = `file.${detectedLanguage}`;
                fileName = existingFileNames.includes(baseFilename) ? 
                  `file${existingFileNames.length + 1}.${detectedLanguage}` : baseFilename;
              }
              
              // Éviter les doublons de contenu
              const contentHash = content.substring(0, 100);
              if (content.length > 50 && !processedContents.has(contentHash)) {
                processedContents.add(contentHash);
                extractedFiles.push({ name: fileName, content, language: detectedLanguage });
              }
            }
          });
          
          if (extractedFiles.length > 1) {
            console.log(`Streaming - Création automatique de ${extractedFiles.length} fichiers`);
            for (const file of extractedFiles) {
              try {
                const existingFiles = await storage.getFilesByProjectId(projectId);
                const existingFile = existingFiles.find(f => f.name === file.name);
                
                if (existingFile) {
                  await storage.updateFile(existingFile.id, { content: file.content });
                  console.log(`Streaming - Fichier mis à jour: ${file.name}`);
                } else {
                  await storage.createFile({
                    name: file.name,
                    content: file.content,
                    language: file.language,
                    projectId: projectId
                  });
                  console.log(`Streaming - Nouveau fichier créé avec structure: ${file.name}`);
                  existingFileNames.push(file.name);
                }
              } catch (error) {
                console.error(`Streaming - Erreur création fichier ${file.name}:`, error);
              }
            }
            return true;
          }
          return false;
        };
        
        const codeContent = typeof result === 'string' ? result : result;
        if (codeContent) {
          await autoCreateFiles(codeContent, parseInt(projectId), isModification);
        }
      }
      
      // Envoyer le signal de fin avec message complete
      res.write(`data: ${JSON.stringify({ type: 'complete', content: 'Génération terminée' })}\n\n`);
      res.write(`data: [DONE]\n\n`);
      res.end();
      
    } catch (error) {
      res.write(`data: ${JSON.stringify({ type: 'error', content: error instanceof Error ? error.message : "Une erreur est survenue" })}\n\n`);
      res.end();
    }
  });
  
  // Route pour l'analyse de code via le système d'aide IA
  app.post("/api/ai/analyze-code", async (req, res) => {
    try {
      const { code, agent, language } = req.body;
      
      if (!code || !agent) {
        return res.status(400).json({ 
          message: "Code et agent requis" 
        });
      }
      
      // Détecter le langage si pas spécifié
      const detectedLanguage = language === 'auto-detect' ? detectOptimalLanguage(code) : language;
      
      // Utiliser l'agent approprié pour l'analyse
      let analysisResult;
      
      switch (agent) {
        case 'claude':
          try {
            analysisResult = await generateCodeWithAnthropic(
              `Analysez ce code ${detectedLanguage} et fournissez des suggestions d'amélioration, des corrections d'erreurs potentielles et des optimisations:\n\n${code}`,
              detectedLanguage
            );
            analysisResult = analysisResult.code || analysisResult;
          } catch {
            analysisResult = await analyzeCode(code, detectedLanguage, "Analyse par Claude");
          }
          break;
        case 'chatgpt':
          try {
            analysisResult = await generateCodeWithOpenAI(
              `Analysez ce code ${detectedLanguage} et fournissez des suggestions d'amélioration, des corrections d'erreurs potentielles et des optimisations:\n\n${code}`,
              detectedLanguage
            );
            analysisResult = analysisResult.code || analysisResult;
          } catch {
            analysisResult = await analyzeCode(code, detectedLanguage, "Analyse par ChatGPT");
          }
          break;
        case 'replit':
        case 'copilot':
        default:
          analysisResult = await analyzeCode(code, detectedLanguage, "Analyse complète du code");
          break;
      }
      
      res.json({
        analysis: analysisResult,
        agent: agent,
        language: detectedLanguage
      });
      
    } catch (error) {
      console.error('Erreur analyse de code:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Erreur d'analyse" 
      });
    }
  });

  // Route pour suggérer à l'agent en cours
  app.post("/api/ai/suggest-to-current-agent", async (req, res) => {
    try {
      const { suggestions, suggestingAgent } = req.body;
      
      if (!suggestions || !suggestingAgent) {
        return res.status(400).json({ error: 'Suggestions et agent suggérant requis' });
      }
      
      // L'agent en cours analyse les suggestions et donne son opinion
      const prompt = `Voici des suggestions d'amélioration proposées par ${suggestingAgent}:

${suggestions}

En tant qu'assistant de développement principal, analysez ces suggestions et donnez votre opinion. Indiquez:
1. Quelles suggestions sont pertinentes et pourquoi
2. Quelles suggestions pourraient être améliorées ou modifiées
3. Vos propres recommandations supplémentaires
4. Demandez si l'utilisateur souhaite appliquer ces suggestions

Soyez constructif et proposez des améliorations concrètes.`;

      // Utiliser l'agent principal pour analyser les suggestions
      const response = await generateCode(prompt, 'javascript', '', 'Analyse de suggestions', 'replit');
      
      res.json({ response });
    } catch (error) {
      console.error('Erreur lors de l\'analyse des suggestions:', error);
      res.status(500).json({ error: 'Erreur interne du serveur' });
    }
  });

  app.post("/api/ai/generate-complex", async (req, res) => {
    try {
      const { prompt, language, requirements, existingCode } = req.body;
      
      // Validation des entrées
      if (!prompt || !language || !requirements) {
        return res.status(400).json({ 
          message: "Les champs 'prompt', 'language' et 'requirements' sont obligatoires" 
        });
      }
      
      const result = await generateComplexArchitecture(
        prompt,
        language,
        requirements,
        existingCode || ""
      );
      
      res.json(result);
    } catch (error) {
      console.error("Erreur lors de la génération d'architecture complexe:", error);
      res.status(500).json({ 
        message: "Erreur lors de la génération d'architecture complexe", 
        error: error instanceof Error ? error.message : "Erreur inconnue"
      });
    }
  });

  app.post("/api/ai/fix", async (req, res) => {
    try {
      const { code, language, error: errorMsg, agent } = req.body;
      let fixedCode;
      
      if (agent === 'replit') {
        fixedCode = await fixCodeWithXAI(code, language, errorMsg);
      } else {
        fixedCode = await fixCode(code, language, errorMsg);
      }
      
      res.json(fixedCode);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });
  
  // Nouvelles routes pour les fonctionnalités d'IA avancées
  
  app.post("/api/ai/tests", async (req, res) => {
    try {
      const { code, language, testFramework } = req.body;
      const tests = await generateTests(code, language, testFramework);
      res.json(tests);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });
  
  app.post("/api/ai/optimize", async (req, res) => {
    try {
      const { code, language, optimizationGoal } = req.body;
      const optimized = await optimizeCode(code, language, optimizationGoal || "general");
      res.json(optimized);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });
  
  app.post("/api/ai/document", async (req, res) => {
    try {
      const { code, language, format } = req.body;
      const documentation = await generateDocumentation(code, language, format || "markdown");
      res.json(documentation);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });
  
  app.post("/api/ai/explain", async (req, res) => {
    try {
      const { code, language, expertiseLevel } = req.body;
      const explanation = await explainCode(code, language, expertiseLevel || "intermediate");
      res.json(explanation);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Une erreur est survenue" });
    }
  });

  // Route d'analyse de code pour les agents d'aide IA
  app.post("/api/ai/analyze-code", async (req, res) => {
    try {
      const { code, agent, language } = req.body;
      
      if (!code || !agent) {
        return res.status(400).json({ 
          message: "Code et agent requis" 
        });
      }
      
      // Détecter le langage si pas spécifié
      const detectedLanguage = language === 'auto-detect' ? detectOptimalLanguage(code) : language;
      
      // Utiliser l'agent approprié pour l'analyse
      let analysisResult;
      
      switch (agent) {
        case 'claude':
          try {
            analysisResult = await generateCodeWithAnthropic(
              `Analysez ce code ${detectedLanguage} et fournissez des suggestions d'amélioration, des corrections d'erreurs potentielles et des optimisations:\n\n${code}`,
              detectedLanguage
            );
            analysisResult = analysisResult.code || analysisResult;
          } catch {
            analysisResult = await analyzeCode(code, detectedLanguage, "Analyse par Claude");
          }
          break;
        case 'chatgpt':
          try {
            const { analyzeCodeWithOpenAI } = await import('./openai');
            analysisResult = await analyzeCodeWithOpenAI(code, detectedLanguage, "Analyse contextuelle en français");
          } catch (error) {
            console.error("Erreur analyse ChatGPT:", error);
            analysisResult = await analyzeCode(code, detectedLanguage, "Analyse par ChatGPT");
          }
          break;
        case 'replit':
          try {
            analysisResult = await analyzeCodeWithXAI(code, detectedLanguage, "Analyse Replit");
          } catch {
            analysisResult = await analyzeCode(code, detectedLanguage, "Analyse par Agent Replit");
          }
          break;
        default:
          analysisResult = await analyzeCode(code, detectedLanguage, "Analyse générale");
          break;
      }
      
      res.json({ 
        analysis: analysisResult,
        agent: agent,
        language: detectedLanguage
      });
      
    } catch (error) {
      console.error("Erreur lors de l'analyse de code:", error);
      res.status(500).json({ 
        message: "Erreur lors de l'analyse", 
        error: error instanceof Error ? error.message : "Erreur inconnue"
      });
    }
  });

  const httpServer = createServer(app);
  
  // Ajout d'un serveur WebSocket pour les notifications temps réel
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  wss.on('connection', (ws) => {
    console.log('Client WebSocket connecté');
    
    // Envoyer un message de bienvenue
    ws.send(JSON.stringify({
      type: 'connection',
      message: 'Connecté au serveur WebSocket'
    }));
    
    // Écouter les messages du client
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        console.log('Message reçu:', data);
        
        // Traitement des différents types de messages
        if (data.type === 'ping') {
          ws.send(JSON.stringify({
            type: 'pong',
            timestamp: Date.now()
          }));
        }
      } catch (error) {
        console.error('Erreur de traitement du message WebSocket:', error);
      }
    });
    
    // Gestion de la déconnexion
    ws.on('close', () => {
      console.log('Client WebSocket déconnecté');
    });
  });

  // Fonction pour générer automatiquement les 25 pages web
  async function generate25PagesProject(projectId: number) {
    try {
      console.log(`Génération des 25 pages pour le projet ${projectId}...`);
      
      const animals = [
        'Lion', 'Éléphant', 'Tigre', 'Girafe', 'Zèbre', 'Panda', 'Koala', 'Kangourou', 'Pingouin', 'Dauphin',
        'Ours', 'Loup', 'Renard', 'Cerf', 'Lapin', 'Chat', 'Chien', 'Oiseau', 'Poisson', 'Tortue',
        'Singe', 'Hippopotame', 'Rhinocéros', 'Crocodile', 'Serpent'
      ];

      // Page principale avec navigation
      const indexHTML = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>25 Pages d'Animaux</title>
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); margin: 0; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; text-align: center; }
        h1 { color: white; margin-bottom: 30px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; margin-top: 20px; }
        .page-link { background: white; padding: 20px; border-radius: 10px; text-decoration: none; color: #333; box-shadow: 0 4px 8px rgba(0,0,0,0.1); transition: transform 0.3s; }
        .page-link:hover { transform: translateY(-5px); }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎉 25 Pages d'Animaux 🎉</h1>
        <div class="grid">
            ${animals.map((animal, index) => `
                <a href="page${index + 1}.html" class="page-link">
                    <h3>Page ${index + 1}</h3>
                    <p>${animal}</p>
                </a>
            `).join('')}
        </div>
    </div>
</body>
</html>`;

      // Créer la page principale
      await storage.createFile({
        name: 'index.html',
        content: indexHTML,
        language: 'html',
        projectId: projectId
      });

      // Créer les 25 pages individuelles
      for (let i = 0; i < 25; i++) {
        const pageNumber = i + 1;
        const animal = animals[i];
        
        const pageHTML = `<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page ${pageNumber} - ${animal}</title>
    <style>
        body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); margin: 0; padding: 20px; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { text-align: center; background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        h1 { color: #333; margin-bottom: 20px; }
        .animal-button { background: linear-gradient(45deg, #FF6B6B, #4ECDC4); color: white; border: none; padding: 20px 40px; font-size: 18px; border-radius: 50px; cursor: pointer; transition: all 0.3s; margin: 20px; }
        .animal-button:hover { transform: scale(1.1); box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
        .animal-emoji { font-size: 60px; margin: 20px 0; }
        .navigation { margin-top: 30px; }
        .nav-button { background: #667eea; color: white; border: none; padding: 10px 20px; margin: 5px; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Page ${pageNumber}</h1>
        <div class="animal-emoji" id="animalEmoji">🦁</div>
        <button class="animal-button" onclick="showAnimal()">${animal}</button>
        <div class="navigation">
            <a href="index.html" class="nav-button">🏠 Accueil</a>
            ${pageNumber > 1 ? `<a href="page${pageNumber - 1}.html" class="nav-button">⬅️ Page ${pageNumber - 1}</a>` : ''}
            ${pageNumber < 25 ? `<a href="page${pageNumber + 1}.html" class="nav-button">Page ${pageNumber + 1} ➡️</a>` : ''}
        </div>
    </div>

    <script>
        const animalEmojis = {
            'Lion': '🦁', 'Éléphant': '🐘', 'Tigre': '🐅', 'Girafe': '🦒', 'Zèbre': '🦓',
            'Panda': '🐼', 'Koala': '🐨', 'Kangourou': '🦘', 'Pingouin': '🐧', 'Dauphin': '🐬',
            'Ours': '🐻', 'Loup': '🐺', 'Renard': '🦊', 'Cerf': '🦌', 'Lapin': '🐰',
            'Chat': '🐱', 'Chien': '🐶', 'Oiseau': '🐦', 'Poisson': '🐠', 'Tortue': '🐢',
            'Singe': '🐵', 'Hippopotame': '🦛', 'Rhinocéros': '🦏', 'Crocodile': '🐊', 'Serpent': '🐍'
        };

        function showAnimal() {
            const emoji = animalEmojis['${animal}'] || '🦁';
            document.getElementById('animalEmoji').textContent = emoji;
            
            // Animation amusante
            const button = event.target;
            button.style.transform = 'scale(0.95)';
            setTimeout(() => {
                button.style.transform = 'scale(1)';
            }, 150);
            
            // Message amusant
            setTimeout(() => {
                alert('🎉 Vous avez cliqué sur ${animal} ! 🎉');
            }, 200);
        }

        // Initialiser l'emoji au chargement
        window.onload = function() {
            const emoji = animalEmojis['${animal}'] || '🦁';
            document.getElementById('animalEmoji').textContent = emoji;
        };
    </script>
</body>
</html>`;

        await storage.createFile({
          name: `page${pageNumber}.html`,
          content: pageHTML,
          language: 'html',
          projectId: projectId
        });
      }

      console.log(`✅ 26 fichiers créés avec succès pour le projet ${projectId}!`);
      return true;
    } catch (error) {
      console.error("Erreur lors de la génération des pages:", error);
      return false;
    }
  }

  // Routes d'exécution de code avec Judge0
  app.post("/api/execute", async (req, res) => {
    try {
      const { code, language, input } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ 
          error: 'Code et langage requis' 
        });
      }

      if (codeExecutor.isLanguageSupported(language)) {
        const result = await codeExecutor.executeCode(code, language, input);
        res.json(result);
      } else {
        res.status(400).json({ 
          error: 'Langage non supporté',
          supportedLanguages: codeExecutor.getSupportedLanguages()
        });
      }
    } catch (error) {
      console.error('Erreur exécution code:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Erreur d\'exécution'
      });
    }
  });

  // Route pour exécuter un fichier spécifique d'un projet
  app.post("/api/execute-file/:projectId", async (req, res) => {
    try {
      const projectId = parseInt(req.params.projectId);
      const { filename, input } = req.body;
      
      if (!filename) {
        return res.status(400).json({ error: 'Nom de fichier requis' });
      }

      const files = await storage.getFilesByProjectId(projectId);
      const file = files.find(f => f.name === filename);
      
      if (!file) {
        return res.status(404).json({ error: 'Fichier non trouvé' });
      }

      const language = file.language || 'text';
      
      if (codeExecutor.isLanguageSupported(language)) {
        const result = await codeExecutor.executeCode(file.content, language, input);
        res.json(result);
      } else {
        res.status(400).json({ 
          error: 'Langage non supporté',
          supportedLanguages: codeExecutor.getSupportedLanguages()
        });
      }
    } catch (error) {
      console.error('Erreur exécution fichier:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Erreur d\'exécution'
      });
    }
  });

  // Route pour obtenir les langages supportés
  app.get("/api/supported-languages", (req, res) => {
    res.json({
      languages: codeExecutor.getSupportedLanguages(),
      total: codeExecutor.getSupportedLanguages().length
    });
  });

  // Routes pour les nouvelles fonctionnalités Replit Agent (conseils ChatGPT)
  
  // Route pour génération ciblée sur un seul fichier
  app.post("/api/replit/generate-single-file", async (req, res) => {
    try {
      const { filename, prompt, existingCode } = req.body;
      
      if (!filename || !prompt) {
        return res.status(400).json({ message: "Filename et prompt requis" });
      }

      const replitAgent = new ReplitAgent((message) => {
        // Log pour debug mais pas de streaming ici
        console.log(`[${message.type}] ${message.content.substring(0, 100)}...`);
      });

      const result = await replitAgent.generateSingleFile(filename, prompt, existingCode);
      res.json({ content: result, filename });
    } catch (error) {
      console.error('Erreur génération fichier unique:', error);
      res.status(500).json({ message: error instanceof Error ? error.message : 'Erreur génération' });
    }
  });

  // Route pour obtenir l'historique des fichiers
  app.get("/api/replit/file-history", async (req, res) => {
    try {
      const { filename } = req.query;
      
      const replitAgent = new ReplitAgent(() => {});
      const history = replitAgent.getFileHistory(filename as string);
      
      res.json({ history });
    } catch (error) {
      console.error('Erreur récupération historique:', error);
      res.status(500).json({ message: 'Erreur récupération historique' });
    }
  });

  // Route pour restaurer depuis l'historique
  app.post("/api/replit/restore-from-history", async (req, res) => {
    try {
      const { filename, timestamp } = req.body;
      
      if (!filename || !timestamp) {
        return res.status(400).json({ message: "Filename et timestamp requis" });
      }

      const replitAgent = new ReplitAgent(() => {});
      const content = replitAgent.restoreFromHistory(filename, timestamp);
      
      if (content) {
        res.json({ content, filename, restored: true });
      } else {
        res.status(404).json({ message: "Version non trouvée" });
      }
    } catch (error) {
      console.error('Erreur restauration historique:', error);
      res.status(500).json({ message: 'Erreur restauration' });
    }
  });

  // Route pour analyser les erreurs dans le code
  app.post("/api/replit/analyze-errors", async (req, res) => {
    try {
      const { code, prompt } = req.body;
      
      if (!code) {
        return res.status(400).json({ message: "Code requis pour analyse" });
      }

      const replitAgent = new ReplitAgent(() => {});
      // Utiliser la nouvelle méthode publique (recommandation ChatGPT finale)
      const errors = replitAgent.analyzeCodeErrors(code);
      
      res.json({ 
        errors,
        hasErrors: errors.length > 0,
        codeLength: code.length
      });
    } catch (error) {
      console.error('Erreur analyse erreurs:', error);
      res.status(500).json({ message: 'Erreur analyse' });
    }
  });

  // Route pour test de la console interactive (recommandation ChatGPT finale)
  app.post("/api/replit/test-console", async (req, res) => {
    try {
      const { message, level } = req.body;
      
      const replitAgent = new ReplitAgent((msg) => {
        // Rediriger vers WebSocket console
        consoleWss.clients.forEach((client) => {
          if (client.readyState === client.OPEN) {
            client.send(JSON.stringify(msg));
          }
        });
      });

      replitAgent.sendConsoleMessage(message || 'Test console message', level || 'log');
      
      res.json({ 
        success: true,
        message: 'Message envoyé à la console',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Erreur test console:', error);
      res.status(500).json({ message: 'Erreur test console' });
    }
  });

  // Route pour personnaliser le ton de l'agent (suggestion ChatGPT finale)
  app.post("/api/replit/set-tone", async (req, res) => {
    try {
      const { tone } = req.body;
      
      if (!['natural', 'technical', 'friendly'].includes(tone)) {
        return res.status(400).json({ 
          message: "Ton invalide. Utiliser: natural, technical, ou friendly" 
        });
      }

      const replitAgent = new ReplitAgent(() => {});
      replitAgent.setTone(tone);
      
      res.json({ 
        success: true,
        tone: tone,
        message: `Ton de l'agent défini sur: ${tone}`,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Erreur définition ton:', error);
      res.status(500).json({ message: 'Erreur définition ton' });
    }
  });

  // Route pour obtenir toutes les fonctionnalités disponibles (bilan final)
  app.get("/api/replit/features", async (req, res) => {
    try {
      res.json({
        features: [
          "Streaming token-par-token en temps réel",
          "Analyse automatique des erreurs de code",
          "Console interactive avec capture des logs",
          "Génération ciblée sur fichiers individuels", 
          "Historique des versions avec restauration",
          "Fallback intelligent vers OpenAI",
          "Personnalisation du ton (natural/technical/friendly)",
          "Capture dynamique des erreurs JavaScript",
          "Messages pédagogiques et explicatifs",
          "Parsing intelligent de fichiers multiples"
        ],
        routes: [
          "POST /api/replit/generate-single-file",
          "GET /api/replit/file-history",
          "POST /api/replit/restore-from-history", 
          "POST /api/replit/analyze-errors",
          "POST /api/replit/test-console",
          "POST /api/replit/set-tone",
          "GET /api/replit/features"
        ],
        status: "Agent Replit 100% conforme à Replit.com",
        version: "1.0 - Complet"
      });
    } catch (error) {
      console.error('Erreur récupération fonctionnalités:', error);
      res.status(500).json({ message: 'Erreur récupération fonctionnalités' });
    }
  });

  // WebSocket pour console interactive - port dynamique
  const consoleWss = new WebSocketServer({ 
    port: 0, // Port automatique pour éviter les conflits
    path: '/console'
  });

  consoleWss.on('connection', (ws) => {
    console.log('Console WebSocket connectée');
    
    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'console') {
          // Rediffuser les messages console à tous les clients connectés
          consoleWss.clients.forEach((client) => {
            if (client.readyState === client.OPEN) {
              client.send(JSON.stringify({
                type: 'console',
                level: message.level,
                content: message.content,
                timestamp: message.timestamp || new Date().toISOString()
              }));
            }
          });
        }
      } catch (error) {
        console.error('Erreur WebSocket console:', error);
      }
    });

    ws.on('close', () => {
      console.log('Console WebSocket déconnectée');
    });
  });

  // Intégration des routes CodePhantom
  app.use(phantomRoutes);

  return httpServer;
}
