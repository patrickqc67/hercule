// Surveillance de la santé de l'API xAI
import OpenAI from "openai";

const xai = new OpenAI({ 
  baseURL: "https://api.x.ai/v1", 
  apiKey: process.env.XAI_API_KEY 
});

interface XAIHealthStatus {
  isHealthy: boolean;
  lastCheck: Date;
  errorDetails?: string;
  statusCode?: number;
}

class XAIHealthMonitor {
  private static instance: XAIHealthMonitor;
  private healthStatus: XAIHealthStatus = {
    isHealthy: false,
    lastCheck: new Date()
  };
  private checkInterval: NodeJS.Timeout | null = null;

  static getInstance(): XAIHealthMonitor {
    if (!XAIHealthMonitor.instance) {
      XAIHealthMonitor.instance = new XAIHealthMonitor();
    }
    return XAIHealthMonitor.instance;
  }

  async checkHealth(): Promise<XAIHealthStatus> {
    try {
      const response = await xai.chat.completions.create({
        model: "grok-2-1212",
        messages: [{ role: "user", content: "test" }],
        max_tokens: 5,
        temperature: 0.1,
      });

      this.healthStatus = {
        isHealthy: true,
        lastCheck: new Date()
      };

      console.log("✅ xAI API est disponible");
    } catch (error: any) {
      this.healthStatus = {
        isHealthy: false,
        lastCheck: new Date(),
        errorDetails: error.message || "Erreur inconnue",
        statusCode: error.status || 0
      };

      if (error.status === 500) {
        console.log("❌ xAI API indisponible (erreur serveur 500)");
      } else if (error.status === 401) {
        console.log("❌ xAI API : problème d'authentification");
      } else if (error.status === 429) {
        console.log("❌ xAI API : limite de taux atteinte");
      } else {
        console.log("❌ xAI API indisponible:", error.message);
      }
    }

    return this.healthStatus;
  }

  getStatus(): XAIHealthStatus {
    return this.healthStatus;
  }

  startMonitoring(intervalMinutes: number = 5): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }

    // Vérification initiale
    this.checkHealth();

    // Vérifications périodiques
    this.checkInterval = setInterval(() => {
      this.checkHealth();
    }, intervalMinutes * 60 * 1000);

    console.log(`🔍 Surveillance xAI démarrée (vérification toutes les ${intervalMinutes} minutes)`);
  }

  stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      console.log("⏹️ Surveillance xAI arrêtée");
    }
  }
}

export const xaiHealthMonitor = XAIHealthMonitor.getInstance();