// Stratégie de production: OpenAI principal + xAI bonus
import { generateCodeWithOpenAI } from './openai';

interface GenerationResult {
  code: string;
  provider: string;
  wasBonus: boolean;
}

class ProductionAIStrategy {
  private static instance: ProductionAIStrategy;
  
  static getInstance(): ProductionAIStrategy {
    if (!ProductionAIStrategy.instance) {
      ProductionAIStrategy.instance = new ProductionAIStrategy();
    }
    return ProductionAIStrategy.instance;
  }

  async generateCode(
    prompt: string,
    language: string = 'html',
    existingCode: string = ''
  ): Promise<GenerationResult> {
    
    // OpenAI comme moteur principal de production
    const enhancedPrompt = existingCode 
      ? `${prompt}\n\nCode existant à améliorer:\n${existingCode}`
      : prompt;
      
    const result = await generateCodeWithOpenAI(enhancedPrompt, language, existingCode);
    
    let code: string;
    if (typeof result === 'string') {
      code = result;
    } else if (result && typeof result === 'object' && 'code' in result) {
      code = String(result.code || "");
    } else {
      code = String(result || "");
    }

    return {
      code,
      provider: 'OpenAI',
      wasBonus: false
    };
  }

  getSystemStatus(): { primary: string; reliability: string } {
    return {
      primary: 'OpenAI GPT-4',
      reliability: 'Production-ready'
    };
  }
}

export const productionAI = ProductionAIStrategy.getInstance();