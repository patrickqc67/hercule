// Test diagnostic direct xAI pour confirmer le problème infrastructure

export async function testXAIDirect() {
  try {
    console.log('🔍 Test direct xAI avec fetch...');
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000);
    
    const response = await fetch('https://api.x.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.XAI_API_KEY}`,
        'Content-Type': 'application/json',
        'User-Agent': 'CodePhantom/1.0'
      },
      body: JSON.stringify({
        model: 'grok-2-1212',
        messages: [{ role: 'user', content: 'Hello world!' }],
        max_tokens: 10
      }),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);

    const data = await response.json();
    
    console.log('📊 Résultat test direct xAI:');
    console.log('Status:', response.status);
    console.log('Headers:', Object.fromEntries(response.headers.entries()));
    console.log('Data:', data);
    
    if (response.status === 500) {
      console.log('🔴 Confirmé: erreur infrastructure xAI (500)');
      return { success: false, error: 'infrastructure', status: 500 };
    }
    
    if (response.ok && data.choices) {
      console.log('✅ xAI fonctionne correctement');
      return { success: true, response: data };
    }
    
    return { success: false, error: 'unknown', status: response.status, data };
    
  } catch (error: any) {
    console.error('❌ Erreur test direct xAI:', {
      message: error.message,
      code: error.code,
      type: error.type
    });
    
    return { 
      success: false, 
      error: 'network', 
      message: error.message 
    };
  }
}

// Test périodique automatique
export class XAIHealthMonitor {
  private interval: NodeJS.Timeout | null = null;
  private isHealthy = false;
  private lastCheck = new Date();
  
  async checkHealth(): Promise<boolean> {
    const result = await testXAIDirect();
    this.isHealthy = result.success;
    this.lastCheck = new Date();
    
    if (result.success) {
      console.log('🟢 xAI redevient opérationnel');
    } else {
      console.log('🔴 xAI toujours indisponible:', result.error);
    }
    
    return this.isHealthy;
  }
  
  startMonitoring(intervalMinutes = 5) {
    if (this.interval) clearInterval(this.interval);
    
    // Test initial
    this.checkHealth();
    
    // Tests périodiques
    this.interval = setInterval(() => {
      this.checkHealth();
    }, intervalMinutes * 60 * 1000);
    
    console.log(`🔄 Surveillance xAI démarrée (${intervalMinutes}min)`);
  }
  
  stopMonitoring() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
      console.log('⏹️ Surveillance xAI arrêtée');
    }
  }
  
  getStatus() {
    return {
      isHealthy: this.isHealthy,
      lastCheck: this.lastCheck
    };
  }
}

export const xaiMonitor = new XAIHealthMonitor();