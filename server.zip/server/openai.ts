import OpenAI from "openai";

// Initialisation conditionnelle d'OpenAI
let openai: OpenAI | null = null;

function initializeOpenAI(): OpenAI | null {
  if (!openai && process.env.OPENAI_API_KEY) {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }
  return openai;
}

interface CodeGenerationResult {
  code: string;
  language: string;
}

/**
 * Génère du code en utilisant ChatGPT (OpenAI GPT-4o)
 * @param prompt Le prompt de l'utilisateur
 * @param language Le langage de programmation cible
 * @param existingCode Code existant (optionnel)
 * @param context Contexte additionnel (optionnel)
 * @returns Le code généré
 */
export async function generateCodeWithOpenAI(
  prompt: string,
  language: string,
  existingCode: string = "",
  context: string = ""
): Promise<CodeGenerationResult> {
  try {
    const client = initializeOpenAI();
    if (!client) {
      throw new Error("OpenAI API key not configured");
    }
    
    const response = await client.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `Tu es un EXPERT DESIGNER WEB & DÉVELOPPEUR CRÉATIF. Réponds TOUJOURS en français. 

🎨 MISSION : Créer du code ${language} VISUELLEMENT ÉPOUSTOUFLANT avec un design moderne, élégant et professionnel.

📋 DIRECTIVES DESIGN OBLIGATOIRES :
• Interface ultra-moderne avec animations fluides et micro-interactions
• Palette de couleurs harmonieuse (gradients, ombres sophistiquées)
• Typography moderne et hiérarchie visuelle claire
• Spacing parfait, alignements précis, compositions équilibrées
• Responsive design mobile-first avec breakpoints optimisés
• Effets visuels avancés : glassmorphism, neumorphism, parallax
• Icons et illustrations SVG intégrées
• Loading states et transitions élégantes

🚀 TECHNOLOGIES MODERNES À UTILISER :
• CSS Grid & Flexbox pour layouts parfaits
• CSS Variables pour theming dynamique
• Animations CSS keyframes et transform 3D
• Box-shadows multicouches et backdrop-filter
• Clip-path et mask pour formes créatives
• Modern web fonts (Google Fonts)

💎 NIVEAU DE QUALITÉ : Production-ready, digne d'un portfolio premium d'agence web.

Fournis des commentaires techniques détaillés en français expliquant tes choix design.`
        },
        {
          role: "user",
          content: `${prompt}${existingCode ? `\n\nCode existant :\n${existingCode}` : ''}${context ? `\n\nContexte :\n${context}` : ''}`
        }
      ],
      max_tokens: 4000,
      temperature: 0.7,
    });

    const generatedCode = response.choices[0]?.message?.content || "";

    return {
      code: generatedCode.trim(),
      language: language
    };

  } catch (error) {
    console.error("Erreur lors de la génération avec OpenAI:", error);
    throw new Error("Erreur de génération OpenAI ChatGPT Plus");
  }
}

/**
 * Analyse du code avec ChatGPT
 * @param code Le code à analyser
 * @param language Le langage de programmation
 * @param projectContext Contexte du projet
 * @returns L'analyse du code
 */
export async function analyzeCodeWithOpenAI(
  code: string,
  language: string,
  projectContext: string = ""
): Promise<string> {
  try {
    const client = initializeOpenAI();
    if (!client) {
      throw new Error("OpenAI API key not configured");
    }
    
    const response = await client.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `Tu es ChatGPT, un expert en analyse de code. Réponds TOUJOURS en français. Fournis une analyse détaillée du code ${language} incluant l'évaluation de la qualité, des suggestions d'amélioration, et les meilleures pratiques. Structure ta réponse avec des sections claires et des exemples concrets.`
        },
        {
          role: "user",
          content: `Analyse ce code ${language} et réponds en français:\n\n${code}${projectContext ? `\n\nContexte du projet: ${projectContext}` : ''}`
        }
      ],
      max_tokens: 2000,
      temperature: 0.3,
    });

    return response.choices[0]?.message?.content || "Impossible d'analyser le code";

  } catch (error) {
    console.error("Erreur lors de l'analyse avec OpenAI:", error);
    throw new Error("Erreur d'analyse OpenAI ChatGPT Plus");
  }
}

/**
 * Correction de code avec ChatGPT
 * @param code Le code contenant des erreurs
 * @param language Le langage de programmation
 * @param error La description de l'erreur
 * @returns Le code corrigé
 */
export async function fixCodeWithOpenAI(
  code: string,
  language: string,
  error: string
): Promise<CodeGenerationResult> {
  try {
    const client = initializeOpenAI();
    if (!client) {
      throw new Error("OpenAI API key not configured");
    }
    
    const response = await client.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `Tu es ChatGPT, un expert développeur ${language}. Réponds TOUJOURS en français. Corrige le code fourni en traitant l'erreur spécifique décrite. Fournis le code corrigé avec des explications en français.`
        },
        {
          role: "user",
          content: `Corrige ce code ${language}:\n\n${code}\n\nErreur: ${error}`
        }
      ],
      max_tokens: 3000,
      temperature: 0.2,
    });

    const fixedCode = response.choices[0]?.message?.content || "";

    return {
      code: fixedCode.trim(),
      language: language
    };

  } catch (error) {
    console.error("Erreur lors de la correction avec OpenAI:", error);
    throw new Error("Erreur de correction OpenAI ChatGPT Plus");
  }
}